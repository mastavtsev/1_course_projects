﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

/// <summary>
/// Основной класс программы.
/// Ввод и вывод данных. Генерация случайных чисел.
/// Проверка на ошибки ввода. 
/// </summary>
class Bulls_and_Cows
{
    /// <summary>
    /// Генерирует случайное число.
    /// </summary>
    /// <param name="num_dig">Количество цифр в числе.</param>
    /// <returns></returns>
    private static string Rand(int num_dig)
    {
        // Список с цифрами для генерации числа.
        List<char> arr = new() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        // Вспомогательные переменные.
        char a;
        string s = "";
        bool f = true;

        for (int i = 0; i < num_dig; i++)
        {
            if (f)
            {
                a = arr[new Random().Next(1, arr.Count)];
                s += a;
                arr.Remove(a);
                f = false;
            }
            else
            {
                a = arr[new Random().Next(0, arr.Count)];
                s += a;
                arr.Remove(a);
            }
        }
        return s;
    }

    /// <summary>
    /// Проверяет число на повторение цифр.
    /// </summary>
    /// <param name="str">Введённое значение.</param>
    /// <returns>Возвращает логическое значение true при отсутствии повторений.
    /// Возвращает логическое значение false при их наличии.</returns>
    private static bool Rep(string str)
    {
        // Вспомогательный массив.
        char[] arr;
        // Логическая переменная. 
        bool f = true;

        // Вспомогательный массив.
        arr = str.ToCharArray();
        for (int i = 0; i < str.Length; i++)
        {
            // Переменная, которой присваивается значение i-ого
            // элемента в строке str.
            string str1 = arr[i].ToString();
            f = 1 == Regex.Matches(str, str1).Count;
            if (!f) { break; }
        }
        return f;
    }

    /// <summary>
    /// Проверяет данные, введённые в методе Input_targ(), на корректность .
    /// </summary>
    /// <param name="targ_bulls_count">Количество цифр в числе.</param>
    /// <param name="str">Введённое значение.</param>
    private static void Mistakes_In(int targ_bulls_count, string str)
    {
        Console.ForegroundColor = ConsoleColor.Red;

        bool ind = ulong.TryParse(str, out ulong num);

        if (str == "F" || str == "Com" || str == "R")
        {
            Console.ResetColor();
            Dop_Command(str);
            return;
        }
        if (num > 10)
        {
            Console.WriteLine("Ошибка: Число не может превышать 10. \n");
            Console.ResetColor();
            return;
        }
        if (str.Length > 0 && str[0] == '-')
        {
            Console.WriteLine("Ошибка: Недопустим ввод отрицательных чисел. \n");
            Console.ResetColor();
            return;
        }
        if (!ind)
        {
            Console.WriteLine("Ошибка: Не является числом или значение слишком велико. \n");
            Console.ResetColor();
            return;
        }
        if (str.Length > 0 && str[0] == '0')
        {
            Console.WriteLine("Ошибка: Число не может начинаться с нуля. \n");
            Console.ResetColor();
            return;
        }

        Console.ResetColor();
    }

    /// <summary>
    /// Проверяет данные, введённые в методе Game(), на корректность .
    /// </summary>
    /// <param name="targ_bulls_count">Количество цифр в числе.</param>
    /// <param name="str">Введённое значение.</param>
    private static void Mistakes_G(int targ_bulls_count, string str)
    {
        Console.ForegroundColor = ConsoleColor.Red;

        if (str == "F" || str == "Com" || str == "R")
        {
            Console.ResetColor();
            Dop_Command(str);
            return;
        }
        if (str.Length > 0 && str[0] == '-')
        {
            Console.WriteLine("Ошибка: Недопустим ввод отрицательных чисел. \n");
            Console.ResetColor();
            return;
        }
        if (!ulong.TryParse(str, out ulong _))
        {
            Console.WriteLine("Ошибка: Не является числом или значение слишком велико. \n");
            Console.ResetColor();
            return;
        }
        if (str.Length < targ_bulls_count)
        {
            Console.WriteLine("Ошибка: Количество символов недостаточно. \n ");
            Console.ResetColor();
            return;
        }
        if (str.Length > targ_bulls_count)
        {
            Console.WriteLine("Ошибка: Превышено количество символов. \n");
            Console.ResetColor();
            return;
        }
        if (!Rep(str))
        {
            Console.WriteLine("Ошибка: Цифры должы быть различны. \n");
            Console.ResetColor();
            return;
        }
        if (str.Length > 0 && str[0] == '0')
        {
            Console.WriteLine("Ошибка: Число не может начинаться с нуля. \n");
            Console.ResetColor();
            return;
        }

        Console.ResetColor();
    }

    /// <summary>
    /// Осуществляет ввод желаемого количества цифр.
    /// </summary>
    /// <returns></returns>
    private static int Input_targ()
    {
        // Количество цифр в числе.
        int targ_bulls_count;
        // Введённое значение.
        string str;

        do
        {
            Console.Write(
                "Для того чтобы компьютер задумал число, введите желаемое количество цифр " +
                "(знаков) в числе, от 1 до 10: ");
            str = Console.ReadLine();
            Mistakes_In(0, str);

        } while (
            !int.TryParse(str, out targ_bulls_count) || targ_bulls_count <= 0
            || targ_bulls_count > 10 || (str.Length > 0 && str[0] == '0'));
        return targ_bulls_count;
    }

    /// <summary>
    /// Осуществляет взаимодействие с игроком.
    /// Осуществляет вызов вспомогательных методов программы. 
    /// </summary>
    /// <param name="targ_bulls_count">Количество цифр в числе.</param>
    /// <param name="curr_bulls_count">Настоящие количество "быков".</param>
    /// <param name="curr_cows_count">Настоящие количество "коров".</param>
    /// <param name="random_num">Число, сгенерированное компьютером.</param>
    /// <param name="str">Введённое значение.</param>
    /// <param name="u_num">Введённое пользователем число.</param>
    private static void Game(int targ_bulls_count, out int curr_bulls_count,
            out int curr_cows_count, ulong random_num, out string str, out ulong u_num)
    {

        do
        {
            do
            {
                Console.Write($"Введите ваше {targ_bulls_count} значное число: ");
                str = Console.ReadLine();

                Mistakes_G(targ_bulls_count, str);

            } while (!ulong.TryParse(str, out u_num) || str.Length < targ_bulls_count
                || str.Length > targ_bulls_count || Rep(str) == false || (str.Length > 0 && str[0] == '0'));

            Game_pos(out curr_bulls_count, out curr_cows_count, random_num, u_num);

        } while (curr_bulls_count != targ_bulls_count);

        WIN();
    }

    /// <summary>
    /// Отображает в консоли количество "быков" и "коров".
    /// </summary>
    /// <param name="curr_bulls_count">Настоящие количество "быков".</param>
    /// <param name="curr_cows_count">Настоящие количесвто "коров".</param>
    /// <param name="random_num"></param>
    /// <param name="u_num"></param>
    private static void Game_pos(out int curr_bulls_count, out int curr_cows_count, ulong random_num, ulong u_num)
    {
        Counter(u_num, random_num, out curr_bulls_count, out curr_cows_count);
        Console.WriteLine($"Количество быков: {curr_bulls_count}, количество коров {curr_cows_count}");
        Console.WriteLine();
    }

    /// <summary>
    /// Подсчитывает количество "быков" и "коров".
    /// </summary>
    /// <param name="num">Число, введённое игроком.</param>
    /// <param name="r_num">Число, сгенерированное компьютером.</param>
    /// <param name="bulls">Количество "быков".</param>
    /// <param name="cows">Количество "коров".</param>
    static void Counter(ulong num, ulong r_num, out int bulls, out int cows)
    {
        cows = 0;
        bulls = 0;
        // Вспомогательный массив.
        char[] arr;
        arr = (num.ToString()).ToCharArray();

        // Подсчёт коров.
        for (int i = 0; i < (num.ToString()).Length; i++)
        {
            if (
                (r_num.ToString()).Contains(arr[i])
                && r_num.ToString()[i] != num.ToString()[i]) { cows++; }
        }

        //Подсчёт быков.
        for (int i = 0; i < num.ToString().Length; i++) { if (r_num.ToString()[i] == num.ToString()[i]) { bulls++; } }

    }

    /// <summary>
    /// Осуществляет приветствие пользователя.
    /// Показывает правила игры.
    /// </summary>
    private static void Greeting()
    {
        Console.WriteLine(
            "Здравствуй, дорогой игрок!\n" +
            "Приветствую тебя в логической игре 'Быки и Коровы'!\n" +
            "Давай познакомимся с её правилами.\n");
        Rules();
        Console.WriteLine(
            "Важно отметить, что тебе также доступны специальные команды. \n" +
            "Для их просмотра введи Com, с большой буквы, в строку ввода\n");
    }

    /// <summary>
    /// Правила игры "Быки и коровы".
    /// </summary>
    private static void Rules()
    {
        Console.WriteLine(
            "'Быки и Коровы' — логическая игра, в ходе которой за несколько попыток \n" +
            "игрок должен определить, какое число задумал компьютер.\n" +
            "После каждой попытки компьютер выдаёт результат, указывая число отгаданных цифр, стоящих \n" +
            "на своих местах (число быков) и число отгаданных цифр, стоящих не на своих местах (число коров).\n");
        Console.WriteLine("Стоит отметить, что число, задуманное компьютером, не содержит повторяющихся цифр. \n" +
            "Поэтому игрок должен вводить число с различными цифрами от 0 до 9. Количество цифр в числе\n" +
            "не может превышать 10. Также недопустим ввод нечисловых символов. \n" +
            "Нельзя вводить символы, начиная с нуля. Количество цифр в числе не может превышать количества,\n" +
            "предварительно введённого игроком.\n");
    }

    /// <summary>
    /// Отображает и осуществляет дополнительные команды.
    /// </summary>
    /// <param name="str">Введёное значение.</param>
    private static void Dop_Command(string str)
    {
        switch (str)
        {
            case "Com":
                Console.WriteLine(
                    "Com - вывод списка команд. \n" +
                    "F - завершение игры досрочно. \n" +
                    "R - открытие правил игры. \n");
                return;
            case "F":
                Finish();
                return;
            case "R":
                Rules();
                return;
            default: break;
        }
    }

    /// <summary>
    /// Выводит в консоль поздравление игрока.
    /// </summary>
    private static void WIN()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Поздравляю с победой!");
        Console.ResetColor();
        Console.WriteLine();
        Console.WriteLine("Для продолжения игры нажмите Enter. \n" +
                          "Для выхода нажмите любую другую клавишу.\n");
    }

    /// <summary>
    /// Выводит в консоль прощание с игроком.
    /// </summary>
    private static void Finish()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine();
        Console.WriteLine("До свидания!\n" +
                          "Буду ждать твоего скорого возвращения в игру!");
        Console.ResetColor();
        Environment.Exit(0);

    }

    /// <summary>
    /// Инициализирует основные переменные. 
    /// Осуществляет повторение игры.
    /// </summary>
    static void Main()
    {
        // Блок описания основных переменных.
        // Количество цифр в числе.
        int targ_bulls_count;
        // Настоящие количество быков и коров.
        int curr_bulls_count, curr_cows_count;
        // Число, сгенерированное компьютером.
        ulong random_num;
        //Служебная переменная для считывания значений.
        string str;
        // Число, введённое пользователем.
        ulong u_num;

        Console.Title = "Игра: 'Быки и Коровы'";

        // Переменная для определения нажатой клавиши на клавиатуре.
        ConsoleKeyInfo info;

        Greeting();

        do
        {
            targ_bulls_count = Input_targ();

            // Подбор случайного числа.
            ulong.TryParse(Rand(targ_bulls_count), out random_num);

            Game(targ_bulls_count, out curr_bulls_count, out curr_cows_count, random_num, out str, out u_num);

            info = Console.ReadKey();
            Console.Clear();

        } while (info.Key == ConsoleKey.Enter);

        Finish();
    }
}
