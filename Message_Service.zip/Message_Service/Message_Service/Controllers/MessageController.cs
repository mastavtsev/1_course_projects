﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Message_Service.Models;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Runtime.Serialization.Json;

namespace Message_Service.Controllers
{
    /// <summary>
    /// Класс, реализующий логику работу приложения MessageController.
    /// </summary>
    public class MessageController : Controller
    {

        //private static List<User> users;
        //private static List<MessageClass> messages;
        private static Random rnd = new Random();


        /// <summary>
        /// Обобщённый метод для десериализации данных из Json файла.
        /// </summary>
        /// <typeparam name="T">Тип для десериализации.</typeparam>
        /// <param name="path">Путь к фалу.</param>
        /// <returns>Список с десериализованными данными.</returns>
        private List<T> ReadJSONData<T>(string path)
        {
            if (System.IO.File.Exists(path))
            {
                using var fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                var formatter = new DataContractJsonSerializer(typeof(T[]));
                return ((T[])formatter.ReadObject(fs)).ToList();
            }
            else
            {
                return new List<T>();
            }
        }

        /// <summary>
        /// Обобщённый метод для сериализации данных в Json файл.
        /// </summary>
        /// <typeparam name="T">Тип для сериализации.</typeparam>
        /// <param name="path">Путь к файлу.</param>
        /// <param name="obj">Объек для сериализации.</param>
        private void WriteJSONData<T>(string path, T obj)
        {
            List<T> objList = ReadJSONData<T>(path);
            objList.Add(obj);

            if (obj is User)
            {
                objList.Sort();
            }

            using var bas = new FileStream(path, FileMode.OpenOrCreate);
            DataContractJsonSerializer format = new DataContractJsonSerializer(typeof(T[]));
            format.WriteObject(bas, objList.ToArray());
        }


        /// <summary>
        /// Случайная генерация случайного количества пользователей и сообщений.
        /// 
        /// Если во время генерации происходит исключение, то возвращается 
        /// BadRequest с сообщением об ошибке.
        /// </summary>
        /// <returns>Объект IActionResult</returns>
        [HttpPost("create-random-users-messages")]
        public IActionResult CreateUser()
        {
            try
            {
                GetRandomUsers();
                GetRandomMessages();
                return Ok("Списки сформированны.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Создание уникального пользователя.
        /// 
        /// Если пользователь с данным идентификатором уже существует возвращается
        /// BadRequest - 400 недопустимый запрос.
        /// </summary>
        /// <param name="email">Идентификатор пользователя,
        /// которым является email.</param>
        /// <param name="userName">Имя пользователя.</param>
        /// <returns>Объект IActionResult.</returns>
        [HttpPost("create-user")]
        public IActionResult CreateUser([FromQuery][Required] string email, [Required] string userName)
        {
            List<User> users = ReadJSONData<User>("UserJson.json");
            var result = users.Where(x => x.Email == email).ToList();
            if (result.Count != 0)
            { return BadRequest(new { Message = $"Пользователь с Email = {email} уже существует." }); }

            User user = new User() { Email = email, UserName = userName };
            //users.Add(user);
            WriteJSONData("UserJson.json", user);

            return Ok(user);
        }

        /// <summary>
        /// Создание сообщения.
        /// </summary>
        /// <param name="emailSender">Идентификатор отправителя.</param>
        /// <param name="emailReceiver">Идентификатор получателя.</param>
        /// <param name="subject">Тема письма.</param>
        /// <param name="messageText">Текст письма.</param>
        /// <returns>Объект IActionResult.</returns>
        [HttpPost("create-message")]
        public IActionResult CreateMessage([FromQuery][Required] string emailSender,
            [Required] string emailReceiver, string subject, [Required] string messageText)
        {
            List<User> users = ReadJSONData<User>("UserJson.json");
            var result = users.Where(x => x.Email == emailSender).ToList();
            if (result.Count == 0)
            { return NotFound(new { Message = $"Пользователь с Email = {emailSender} не существует." }); }

            result = users.Where(x => x.Email == emailReceiver).ToList();
            if (result.Count == 0)
            { return NotFound(new { Message = $"Пользователь с Email = {emailReceiver} не существует." }); }

            MessageClass message = new MessageClass()
            {
                SenderId = emailSender,
                ReceiverId = emailReceiver,
                Subject = subject,
                Message = messageText
            };


            WriteJSONData("MessagesJson.json", message);

            return Ok(message);

        }

        /// <summary>
        /// Получение пользователя по его идентификатору.
        /// </summary>
        /// <param name="email">Идентификатор пользователя.</param>
        /// <returns>Объект IActionResult.</returns>
        [HttpGet("get-user-by-id")]
        public IActionResult GetUserById([FromQuery][Required] string email)
        {
            List<User> users = ReadJSONData<User>("UserJson.json");
            var result = users.Where(x => x.Email == email).ToList();
            if (result.Count == 0)
            { return NotFound(new { Message = $"Пользователь с Email = {email} не найден" }); }
            return Ok(result.First());
        }

        /// <summary>
        /// Получение пользователей. Если оба входных параметра равны нулю, 
        /// то возвращается список всех пользователей. 
        /// В противном случае данные проверяются на корректность и возвращается 
        /// список, сформированный согласно входным параметрам.
        /// </summary>
        /// <param name="Limit"></param>
        /// <param name="Offset"></param>
        /// <returns></returns>
        [HttpGet("get-all-users")]
        public IActionResult GetAllUsers([FromQuery] int Limit, int Offset)
        {
            if (Offset == 0 && Limit == 0)
                return Ok(ReadJSONData<User>("UserJson.json"));

            if (Offset < 0)
                return BadRequest("Значение Offset не может быть отрицательным.");

            if (Limit <= 0)
                return BadRequest("Значение Limit не может быть неположительным.");

            List<User> users = ReadJSONData<User>("UserJson.json");

            List<User> newListOfUsers = new();

            for (int i = 0; i < users.Count; i++)
            {
                if (newListOfUsers.Count < Limit && i >= Offset)
                    newListOfUsers.Add(users[i]);
            }

            return Ok(newListOfUsers);
        }

        /// <summary>
        /// Получения всех сообщений, которые отправлялись
        /// определённым пользователем.
        /// </summary>
        /// <param name="email">Идентификатор пользователя.</param>
        /// <returns>Объект IActionResult.</returns>
        [HttpGet("get-messages-by-SenderId")]
        public IActionResult GetMessagesBySenderId([FromQuery][Required] string email)
        {
            List<MessageClass> messages = ReadJSONData<MessageClass>("MessagesJson.json");
            var result = messages.Where(x => x.SenderId == email).ToList();
            if (result.Count == 0)
            { return NotFound(new { Message = $"Сообщений от пользователя с Email = {email} не найдено" }); }
            return Ok(result);
        }


        /// <summary>
        /// Получение всех сообщений, которые были получены 
        /// определённым пользователем. 
        /// </summary>
        /// <param name="email"></param>
        /// <returns>Объект IActionResult.</returns>
        [HttpGet("get-messages-by-ReceiverId")]
        public IActionResult GetMessagesByReceiverId([FromQuery][Required] string email)
        {
            List<MessageClass> messages = ReadJSONData<MessageClass>("MessagesJson.json");
            var result = messages.Where(x => x.ReceiverId == email).ToList();
            ////var result = messages;
            if (result.Count == 0)
            { return NotFound(new { Message = $"Сообщений для пользователя с Email = {email} не найдено" }); }
            return Ok(result);
        }

        /// <summary>
        /// Получения сообщений по идентификаторам 
        /// отправителя и получателя.
        /// </summary>
        /// <param name="emailSender">Индентификатор отправителя.</param>
        /// <param name="emailReceiver">Индентификатор получателя.</param>
        /// <returns>Объект IActionResult</returns>
        [HttpGet("get-messages-by-SenderId-and-ReceiverId")]
        public IActionResult GetMessagesByReceiverAndSenderId([FromQuery][Required] string emailSender, [Required] string emailReceiver)
        {
            List<MessageClass> messages = ReadJSONData<MessageClass>("MessagesJson.json");
            var result = messages.Where(x => x.ReceiverId == emailReceiver && x.SenderId == emailSender).ToList();
            if (result.Count == 0)
            {
                return NotFound(new
                {
                    Message = $"Сообщений с отправителем {emailSender}" +
                        $" и получателем {emailReceiver} не найдено."
                });
            }
            return Ok(result);
        }

        /// <summary>
        /// Генерация пользователя со случайным именем
        /// и идентификатором.
        /// </summary>
        private void GetRandomUsers()
        {
            List<string> generatedEmails = new();
            try
            {
                int usersNumber = rnd.Next(5, 26);
                for (int i = 0; i < usersNumber; i++)
                {
                    string email;

                    // Обеспечения уникальности генерируемой почты -
                    // повторяем генерацияю до тех пор, пока не получаем
                    // уникальное значение.
                    do
                    {
                        email = GetRandomString(rnd.Next(5, 16)) + "@edu.hse.ru";
                    } while (generatedEmails.Contains(email));

                    generatedEmails.Add(email);
                    string userName = GetRandomString(rnd.Next(5, 16));

                    var user = new User()
                    {
                        UserName = userName,
                        Email = email
                    };

                    WriteJSONData("UserJson.json", user);

                }
            }
            catch (Exception)
            {

                throw;
            }



        }

        /// <summary>
        /// Генерация сообщения со случаным заголовком и текстом, 
        /// идентификаторы получателя и отправителя берутся из соответствующего
        /// Json файла.
        /// </summary>
        private void GetRandomMessages()
        {
            try
            {
                List<MessageClass> messagesList = new List<MessageClass>();
                int messagesNumber = rnd.Next(5, 26);
                List<User> users = ReadJSONData<User>("UserJson.json");
                for (int i = 0; i < messagesNumber; i++)
                {
                    string subject = GetRandomString(rnd.Next(10, 31));
                    string message = GetRandomString(rnd.Next(30, 101));

                    // Человек может отправить письмо самому себе - допустимый сценарий.
                    var messageItem = new MessageClass()
                    {
                        Subject = subject,
                        Message = message,
                        SenderId = users[rnd.Next(users.Count)].Email,
                        ReceiverId = users[rnd.Next(users.Count)].Email
                    };
                    WriteJSONData("MessagesJson.json", messageItem);
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// Метод для получения случайного имени, сообщения
        /// или части email-a.
        /// </summary>
        /// /// <param name="length">Длина необходимой строки.</param>
        /// <returns>Строка - имя, cообщение или email.</returns>
        private static string GetRandomString(int length)
        {

            // Используется целочисленное значение сиволов - char.
            // Используется генератор случайного числа - 0 или 1, 
            // для определения очередного символа в наименовании -
            // латинская заглавная буква или цифра.
            // A = 65,  Z = 90, a = 97, z = 122
            var sb = new StringBuilder();
            for (int i = 0; i < length; i++)
            {
                if (rnd.Next(0, 2) == 0)
                    sb.Append((char)(rnd.Next(65, 91)));
                else
                    sb.Append((char)(rnd.Next(97, 123)));
            }

            return sb.ToString();
        }


    }
}
