﻿//using Microsoft.AspNetCore.Mvc;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Message_Service.Models;
//using System.Text;
//using System.ComponentModel.DataAnnotations;
//using System.IO;
//using System.Runtime.Serialization.Json;

//namespace Message_Service.Controllers
//{
//    public class MessageController : Controller
//    {
//        private static List<User> users = new List<User>();
//        private static List<MessageClass> messages = new List<MessageClass>();
//        private static Random rnd = new Random();


//        private List<T> ReadJSONData<T>(string path)
//        {
//            using var fs = new FileStream(path, FileMode.Open, FileAccess.Read);
//            var formatter = new DataContractJsonSerializer(typeof(T[]));
//            return ((T[])formatter.ReadObject(fs)).ToList();
//        }

//        private void WriteJSONData<T>(string path)
//        {
//            using var bas = new FileStream(path, FileMode.OpenOrCreate);
//            DataContractJsonSerializer format = new DataContractJsonSerializer(typeof(T));
//            format.WriteObject(bas, this);
//        }


//        [HttpPost("create-random-users-messages")]
//        public IActionResult CreateUser()
//        {
//            try
//            {
//                GetRandomUsers();
//                GetRandomMessages();
//                return Ok("Списки сформированны.");
//            }
//            catch (Exception ex)
//            {
//                return NotFound(ex.Message);
//            }
//        }

//        [HttpPost("create-user")]
//        public IActionResult CreateUser([FromQuery][Required] string email, [Required] string userName)
//        {
//            var result = users.Where(x => x.Email == email).ToList();
//            if (result.Count != 0)
//            { return NotFound(new { Message = $"Пользователь с Email = {email} уже существует." }); }

//            User user = new User() { Email = email, UserName = userName };
//            users.Add(user);

//            return Ok(user);
//        }

//        [HttpPost("create-message")]
//        public IActionResult CreateMessage([FromQuery][Required] string emailSender,
//            [Required] string emailReceiver, string subject, [Required] string messageText)
//        {
//            var result = users.Where(x => x.Email == emailSender).ToList();
//            if (result.Count == 0)
//            { return NotFound(new { Message = $"Пользователь с Email = {emailSender} не существует." }); }

//            result = users.Where(x => x.Email == emailReceiver).ToList();
//            if (result.Count == 0)
//            { return NotFound(new { Message = $"Пользователь с Email = {emailReceiver} не существует." }); }

//            MessageClass message = new MessageClass()
//            {
//                SenderId = emailSender,
//                ReceiverId = emailReceiver,
//                Subject = subject,
//                Message = messageText
//            };

//            messages.Add(message);

//            return Ok(message);

//        }

//        [HttpGet("get-user-by-id")]
//        public IActionResult GetUserById([FromQuery] string email)
//        {
//            var result = users.Where(x => x.Email == email).ToList();
//            if (result.Count == 0)
//            { return NotFound(new { Message = $"Пользователь с Email = {email} не найден" }); }
//            return Ok(result.First());
//        }

//        [HttpGet("get-all-users")]
//        public IActionResult GetAllUsers() => Ok(users);

//        [HttpGet("get-messages-by-SenderId")]
//        public IActionResult GetMessagesBySenderId([FromQuery] string email)
//        {
//            var result = messages.Where(x => x.SenderId == email).ToList();
//            if (result.Count == 0)
//            { return NotFound(new { Message = $"Сообщений от пользователя с Email = {email} не найдено" }); }
//            return Ok(result);
//        }

//        [HttpGet("get-messages-by-ReceiverId")]
//        public IActionResult GetMessagesByReceiverId([FromQuery] string email)
//        {
//            var result = messages.Where(x => x.ReceiverId == email).ToList();
//            //var result = messages;
//            if (result.Count == 0)
//            { return NotFound(new { Message = $"Сообщений для пользователя с Email = {email} не найдено" }); }
//            return Ok(result);
//        }

//        [HttpGet("get-messages-by-SenderId-and-ReceiverId")]
//        public IActionResult GetMessagesByReceiverAndSenderId([FromQuery] string emailSender, string emailReceiver)
//        {
//            var result = messages.Where(x => x.ReceiverId == emailReceiver && x.SenderId == emailSender).ToList();
//            if (result.Count == 0)
//            {
//                return NotFound(new
//                {
//                    Message = $"Сообщений с отправителем {emailSender}" +
//              $" и получателем {emailReceiver} не найдено."
//                });
//            }
//            return Ok(result);
//        }


//        private void GetRandomUsers()
//        {
//            try
//            {
//                List<User> usersList = new List<User>();
//                int usersNumber = rnd.Next(5, 26);
//                for (int i = 0; i < usersNumber; i++)
//                {
//                    string email = GetRandomString(rnd.Next(5, 16)) + "@edu.hse.ru";
//                    string userName = GetRandomString(rnd.Next(5, 16));

//                    var user = new User()
//                    {
//                        UserName = userName,
//                        Email = email // !!!!!!!!!!!!!! Почта должна быть уникальной! !!!!!!!!!!!!!!!!!!!!
//                    };

//                    users.Add(user);
//                }
//            }
//            catch (Exception)
//            {

//                throw;
//            }



//        }

//        private void GetRandomMessages()
//        {
//            try
//            {
//                List<MessageClass> messagesList = new List<MessageClass>();
//                int messagesNumber = rnd.Next(5, 26);
//                for (int i = 0; i < messagesNumber; i++)
//                {
//                    string subject = GetRandomString(rnd.Next(10, 31));
//                    string message = GetRandomString(rnd.Next(30, 101));

//                    // Человек может отправить письмо самому себе - допустимый сценарий.
//                    var messageItem = new MessageClass()
//                    {
//                        Subject = subject,
//                        Message = message,
//                        SenderId = users[rnd.Next(users.Count)].Email,
//                        ReceiverId = users[rnd.Next(users.Count)].Email
//                    };

//                    messages.Add(messageItem);
//                }
//            }
//            catch (Exception)
//            {

//                throw;
//            }

//        }

//        /// <summary>
//        /// Метод для получения случайного имени, сообщения
//        /// или части email-a.
//        /// </summary>
//        /// /// <param name="length">Длина необходимой строки.</param>
//        /// <returns>Строка - имя, cообщение или email.</returns>
//        private static string GetRandomString(int length)
//        {

//            // Используется целочисленное значение сиволов - char.
//            // Используется генератор случайного числа - 0 или 1, 
//            // для определения очередного символа в наименовании -
//            // латинская заглавная буква или цифра.
//            // A = 65,  Z = 90, a = 97, z = 122
//            var sb = new StringBuilder();
//            for (int i = 0; i < length; i++)
//            {
//                if (rnd.Next(0, 2) == 0)
//                    sb.Append((char)(rnd.Next(65, 91)));
//                else
//                    sb.Append((char)(rnd.Next(97, 123)));
//            }

//            return sb.ToString();
//        }


//    }
//}
