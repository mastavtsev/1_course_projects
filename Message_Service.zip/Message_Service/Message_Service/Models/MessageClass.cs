﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ComponentModel.DataAnnotations;

namespace Message_Service.Models
{
    /// <summary>
    /// Класс, описывающий тип - Сообщение.
    /// </summary>
    [DataContract]
    public class MessageClass
    {
        // Идентификатор отпрвителя.
        [Required]
        [DataMember]
        public string SenderId { get; set; }

        // Идентификатор получателя.
        [Required]
        [DataMember]
        public string ReceiverId { get; set; }

        // Тема сообщения.
        [DataMember]
        public string Subject { get; set; }

        // Текст сообщения.
        [Required]
        [DataMember]
        public string Message { get; set; }


    }
}
