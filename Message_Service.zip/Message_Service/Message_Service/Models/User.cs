﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;


namespace Message_Service.Models
{
    /// <summary>
    /// Класс, описывающий тип - Пользователь.
    /// </summary>
    [DataContract]
    public class User: IComparable<User>
    {
        /// <summary>
        /// Имя пользователя.
        /// </summary>
        [Required]
        [DataMember]
        public string UserName { get; set; }

        /// <summary>
        /// Уникальный идентификатор.
        /// </summary>
        [Required]
        [DataMember]
        public string Email { get; set; }

        public int CompareTo(User other)
        {
            return Email.CompareTo(other.Email);
        }
    }
}
