﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Fractal
{

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Point startPoint;

        private Action<int> fractalType;

        private BaseFractal baseFractal;

        private double[] fractalTreeExtraSet = new double[3];
        private double cantorSetExtra;


        /// <summary>
        /// Поля содержащие значения минимального и максимально
        /// значения цветов для фракталов.
        /// </summary>
        private Color minColorValue = Color.FromRgb(0, 0, 0);
        private Color maxColorValue = Color.FromRgb(0, 0, 0);

        //Поле, которое сигнализирует о том, надо ли красить фракталы или нет.
        private bool paintFractal;

        /// <summary>
        /// Инициализация параметров окна.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            double maxWidth = SystemParameters.PrimaryScreenWidth;
            double maxHeight = SystemParameters.PrimaryScreenHeight;

            this.MinHeight = maxHeight / 2;
            this.MaxHeight = maxHeight;

            this.MinWidth = maxWidth / 2 + 200;
            this.MaxWidth = maxWidth;

        }

        /// <summary>
        /// Обработчик изменения значения слайдера (переключатель глубины отрисовки).
        /// Отвечает за вызов метода по отрисовке фрактала.
        /// Срабатывает только тогда, когда ранее было уже что-то отрисовано.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Redraw(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (canvas.Children.Count != 0)
                StartOfFractalPrinting();
        }

        /// <summary>
        /// Обработчик нажатия кнопки для отрисовки фрактала.
        /// Отвечает за вызов метода по отрисовке фрактала.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void PrintFracButtClick(object sender, EventArgs e)
        {
            StartOfFractalPrinting();
        }

        /// <summary>
        /// Метод по отрисовке фрактала.
        /// Считывает количество итераций и вызывает делагат,
        /// сожержащий метод по отрисовке выбранно фрактала.
        /// </summary>
        private void StartOfFractalPrinting()
        {
            canvas.Children.Clear();
            baseFractal = null;

            int iterationsNumber = (int)slValue.Value;

            fractalType?.Invoke(iterationsNumber);
            if (fractalType == null)
                MessageBox.Show("Не выбран тип фрактала. Подтвердите выбор для продолжения.");

        }
        /// <summary>
        /// Обработчик для элементов RadioButton.
        /// Получает выбранный фрактал, и присвает делегату fractalType метод
        /// для отрисовки выбранного фрактала.
        /// Также устанавливает максимальные значения для слайдера,
        /// соответствующие максимальной глубине отрисовки выбранного фрактала.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton pressed = (RadioButton)sender;
            string fractalStr = pressed.Content.ToString();
            canvas.Children.Clear();

            slValue.IsEnabled = true;
            slTextBox.IsEnabled = true;
            SetSliderLimit(fractalStr);

            fractalType = fractalStr switch
            {
                "Фрактальное дерево" => SetFractalTree,
                "Кривая Коха" => SetKochCurve,
                "Ковёр Серпинского" => SetSerpCarpet,
                "Треугольник Серпинского" => SetSerpTriang,
                "Множество Кантора" => SetCantorSet,
                _ => SetFractalTree
            };
        }

        /// <summary>
        /// Выставляет максимальные значения для слайдера.
        /// </summary>
        /// <param name="type">Выбранный тип фрактала.</param>
        private void SetSliderLimit(string type)
        {
            int max = type switch
            {
                "Фрактальное дерево" => 9,
                "Кривая Коха" => 6,
                "Ковёр Серпинского" => 5,
                "Треугольник Серпинского" => 8,
                "Множество Кантора" => 9,
                _ => 1
            };

            slValue.Maximum = max;
        }

        /// <summary>
        /// Метод по отрисовке Фрактального дерева.
        /// Создаёт объект типа FractalTree, а после вызывает рекрсивный метод
        /// из класса FractalTree по отрисовке фрактала.
        /// 
        /// Также выставляет дополнительные настройки для объекта фрактала, если таковые были выбраны.
        /// </summary>
        /// <param name="depth">Глубина отрисовки.</param>
        private void SetFractalTree(int depth)
        {
            baseFractal = new FractalTree();
            startPoint = new Point(canvas.ActualWidth / 2, 0.83 * canvas.ActualHeight);

            if (Array.Exists(fractalTreeExtraSet, x => x != 0))
            {
                FractalTree.lengthScale = fractalTreeExtraSet[0];
                FractalTree.deltaLeft = fractalTreeExtraSet[1] * Math.PI / 180;
                FractalTree.deltaRight = fractalTreeExtraSet[2] * Math.PI / 180;
            }

            baseFractal.mustPaint = paintFractal;
            if (baseFractal.mustPaint)
                baseFractal.PaintFractal(minColorValue, maxColorValue, depth);

            baseFractal.PrintFractal(canvas, depth, startPoint, 180, -Math.PI / 2);
        }

        /// <summary>
        /// Метод по отрисовке Кривой Коха.
        /// Создаёт объект типа KochCurve, а после вызывает рекрсивный метод
        /// из класса KochCurve по отрисовке фрактала.
        /// 
        /// Также добавляет на canvas первую линию для отрисовки.
        /// </summary>
        /// <param name="depth">Глубина отрисовки.</param>
        private void SetKochCurve(int depth)
        {
            baseFractal = new KochCurve();
            Line line = new Line
            {
                X1 = 0,
                X2 = 1250,
                Y1 = 700,
                Y2 = 700
            };

            baseFractal.mustPaint = paintFractal;
            if (baseFractal.mustPaint)
                baseFractal.PaintFractal(minColorValue, maxColorValue, depth);


            line.Stroke = new SolidColorBrush(minColorValue);

            canvas.Children.Add(line);

            baseFractal.PrintFractal(canvas, depth, line);
        }

        /// <summary>
        /// Метод по отрисовке Ковра Серпинского.
        /// Создаёт объект типа SerpCarpet, а после вызывает рекрсивный метод
        /// из класса SerpCarpet по отрисовке фрактала.
        /// 
        /// Вызывате метод для отрисовки первого квадрата.
        /// </summary>
        /// <param name="depth">Глубина отрисовки.</param>
        private void SetSerpCarpet(int depth)
        {
            baseFractal = new SerpCarpet();

            double top, left;
            PrintFirstCarpet(out top, out left);

            baseFractal.mustPaint = paintFractal;
            if (baseFractal.mustPaint)
                baseFractal.PaintFractal(minColorValue, maxColorValue, depth);

            baseFractal.PrintFractal(canvas, depth, left, top, 700, 700);
        }

        /// <summary>
        /// Метод для отрисовки первого квадрата.
        /// Устанавливает верхнюю левую координату квадрата.
        /// </summary>
        /// <param name="top">Верхняя координата квадрата.</param>
        /// <param name="left">Левая координата квадрата.</param>
        private void PrintFirstCarpet(out double top, out double left)
        {
            Rectangle myRect = new Rectangle();
            myRect.HorizontalAlignment = HorizontalAlignment.Stretch;
            myRect.VerticalAlignment = VerticalAlignment.Stretch;
            myRect.Height = 700;
            myRect.Width = 700;

            top = (canvas.ActualHeight / 2) - (myRect.Height / 2);
            Canvas.SetTop(myRect, top);

            left = (canvas.ActualWidth / 2) - (myRect.Width / 2);
            Canvas.SetLeft(myRect, left);

            myRect.Fill = Brushes.Black;
            canvas.Children.Add(myRect);
        }

        /// <summary>
        /// Метод по отрисовке Треугольника Серпинсого.
        /// Создаёт объект типа SerpTriangle, а после вызывает рекрсивный метод
        /// из класса SerpTriangle по отрисовке фрактала.
        /// 
        /// Вызывате метод для отрисовки первого треугольника.
        /// </summary>
        /// <param name="depth">Глубина отрисовки.</param>
        private void SetSerpTriang(int depth)
        {

            baseFractal = new SerpTriangle();

            //Вершины треугольника.
            Point topPoint, leftPoint, rightPoint;
            (topPoint, leftPoint, rightPoint) = MakeBaseTraingle();

            baseFractal.mustPaint = paintFractal;
            if (baseFractal.mustPaint)
                baseFractal.PaintFractal(minColorValue, maxColorValue, depth);

            baseFractal.PrintFractal(canvas, depth, topPoint, leftPoint, rightPoint);
        }

        /// <summary>
        /// Метод по отрисовке первого треугольника.
        /// </summary>
        /// <returns>Кортеж из вершин координат треугольника.</returns>
        private (Point, Point, Point) MakeBaseTraingle()
        {
            double angle = Math.PI / 3.0;
            double xCoord = 300;
            double yCoord = 650;
            double yTop = yCoord - 700 * Math.Sin(angle);

            //Вершины треугольника.
            Point topPoint = new Point(xCoord + 350, yTop);
            Point leftPoint = new Point(xCoord, yCoord);
            Point rightPoint = new Point(xCoord + 700, yCoord);

            PointCollection polygonPoints = new PointCollection();
            polygonPoints.Add(topPoint);
            polygonPoints.Add(leftPoint);
            polygonPoints.Add(rightPoint);

            Polygon triangle = new Polygon();
            triangle.Points = polygonPoints;
            triangle.Fill = Brushes.Black;
            canvas.Children.Add(triangle);

            return (topPoint, leftPoint, rightPoint);
        }

        /// <summary>
        /// Метод по отрисовке Множества Кантора.
        /// Создаёт объект типа CantorSet, а после вызывает рекрсивный метод
        /// из класса CantorSet по отрисовке фрактала.
        /// </summary>
        /// <param name="depth">Глубина отрисовки.</param>
        private void SetCantorSet(int depth)
        {
            int indent = 30;

            if (cantorSetExtra != 0)
                indent = (int)cantorSetExtra;

            baseFractal = new CantorSet(canvas, indent);

            baseFractal.mustPaint = paintFractal;
            if (baseFractal.mustPaint)
                baseFractal.PaintFractal(minColorValue, maxColorValue, depth);

            baseFractal.PrintFractal(depth, 50, 1200, 100);
        }

        /// <summary>
        /// Обработчик нажатия кнопки по установке цветов для фракталов.
        /// 
        /// Делает видимым grid, который содержит элементы для выбора цветов.
        /// Устанавливает значение истины для переменной paintFractal.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void ColorPickerButtonClick(object sender, RoutedEventArgs e)
        {
            gridHidden.Visibility = Visibility.Visible;
            minColorValue = Color.FromRgb(0, 0, 0);
            maxColorValue = Color.FromRgb(0, 0, 0);
            paintFractal = true;
        }

        /// <summary>
        /// Обработчик нажатия кнопки по установки дополнительный настроек 
        /// для Фрактального Дерево.
        /// Вызывате новую форму и считывает с неё значения.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void FractalTreeSettingsClick(object sender, RoutedEventArgs e)
        {
            FractalTreeSettings newForm = new();
            newForm.Show();
            fractalTreeExtraSet = newForm.ReturnData();
        }

        /// <summary>
        /// Обработчик нажатия кнопки по установки дополнительный настроек 
        /// для Множества Кантора.
        /// Вызывает новую форму и считывает с неё значение.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void CantorSetSettingsClick(object sender, RoutedEventArgs e)
        {
            CantorSettings cantorSetForm = new();
            cantorSetForm.Ok += ReadData;

            cantorSetForm.Show();
        }

        /// <summary>
        /// Метод для считываения значений с формы дополнительных настроек
        /// для Множества Кантора.
        /// </summary>
        /// <param name="cantorSetForm"></param>
        public void ReadData(object cantorSetForm)
            => cantorSetExtra = ((CantorSettings)cantorSetForm).slValue.Value;

        /// <summary>
        /// Обработчик изменения значений минимального цвета,
        /// присваивает изменённое значения соответсвующей переменной.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void ColorPickerMinSelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
            => minColorValue = cp1.SelectedColor.Value;

        /// <summary>
        /// Обработчик изменения значений максимального цвета,
        /// присваивает изменённое значения соответсвующей переменной.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void ColorPickerMaxSelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
            => maxColorValue = cp2.SelectedColor.Value;

        private void ButtonSaveFractalClick(object sender, RoutedEventArgs e)
        {
            try
            {
                Transform transform = canvas.LayoutTransform;

                canvas.LayoutTransform = null;

                Size size = new Size(canvas.ActualWidth, canvas.ActualHeight);

                canvas.Measure(size);
                canvas.Arrange(new Rect(size));


                RenderTargetBitmap renderBitmap =
                  new RenderTargetBitmap(
                    (int)size.Width,
                    (int)size.Height,
                    96d,
                    96d,
                    PixelFormats.Pbgra32);
                renderBitmap.Render(canvas);

                string pathToFile = filePath.Text;
                filePath.Text = "";
                using (FileStream outStream = new FileStream(pathToFile, FileMode.CreateNew))
                {

                    PngBitmapEncoder encoder = new PngBitmapEncoder();

                    encoder.Frames.Add(BitmapFrame.Create(renderBitmap));

                    encoder.Save(outStream);
                }
            }
            catch
            {

                MessageBox.Show("Файл с таким названием уже существует или неправильное имя файла.");
            }
        }
    }

    /// <summary>
    /// Базовый класс для всех фракталов. Содержит перегрузки методов для рекурсивной 
    /// отрисовки определённого типа фрактала.
    /// 
    /// Также содержит общий для всех фракталов метод по определению градиента цвета.
    /// </summary>
    public abstract class BaseFractal
    {
        public static readonly int maxDepth;
        public bool mustPaint;
        protected Brush fillColor = new SolidColorBrush(Color.FromRgb(128, 160, 72));

        protected List<Color> colorList = new List<Color>();

        /// <summary>
        /// Рекурсивный метод для отрисовки Фрактального дерева.
        /// </summary>
        /// <param name="canvas"> Canvas, на котором происходит отрисовка фрактала.</param>
        /// <param name="depth">Глубина отрисовки.</param>
        /// <param name="pt">Начальная точка для отрисовки прямой.</param>
        /// <param name="length">Длина прямой.</param>
        /// <param name="theta">Угол наклона.</param>
        public virtual void PrintFractal(Canvas canvas, int depth, Point pt, double length, double theta) { }

        /// <summary>
        /// Рекурсивный метод для отрисовки Треугольника Серпинского.
        /// </summary>
        /// <param name="canvas"> Canvas, на котором происходит отрисовка фрактала.</param>
        /// <param name="depth">Глубина отрисовки.</param>
        /// <param name="topPoint">Верхняя координата треугольника.</param>
        /// <param name="leftPoint">Левая нижняя координата треугольника.</param>
        /// <param name="rightPoint">Правая нижняя координата треугольника.</param>
        public virtual void PrintFractal(Canvas canvas, int depth, Point topPoint, Point leftPoint, Point rightPoint) { }

        /// <summary>
        /// Метод для рекурсивной отрисовки Ковра Серпинского.
        /// </summary>
        /// <param name="canvas"> Canvas, на котором происходит отрисовка фрактала.</param>
        /// <param name="depth">Глубина отрисовки.</param>
        /// <param name="leftCoord">Первая координата левой верхней вершины.</param>
        /// <param name="topCoord">Вторая координата левой верхней вершины.</param>
        /// <param name="rectangleWidth">Ширина квадрата.</param>
        /// <param name="rectangleHeight">Высота квадрата.</param>
        public virtual void PrintFractal(Canvas canvas, int depth,
             double leftCoord, double topCoord, int rectangleWidth, int rectangleHeight)
        { }

        /// <summary>
        /// Метод для отрисовки Кривой Коха.
        /// </summary>
        /// <param name="canvas"> Canvas, на котором происходит отрисовка фрактала.</param>
        /// <param name="depth">Глубина отрисовки.</param>
        /// <param name="line">Линия для изменения на каждом шаге.</param>
        public virtual void PrintFractal(Canvas canvas, int depth, Line line) { }

        /// <summary>
        /// Метод для отрисовки Множества Кантора.
        /// </summary>
        /// <param name="depth">Глубина отрисовки.</param>
        /// <param name="x1">Левая Х координат прямой.</param>
        /// <param name="x2">Правая Х координата прямой.</param>
        /// <param name="y">Общаяя для всей прямой Y координата.</param>
        public virtual void PrintFractal(int depth, double x1, double x2, double y) { } // CantorSet

        /// <summary>
        /// Метод для определения градиента цвета.
        /// </summary>
        /// <param name="cMin">Начальный цвет.</param>
        /// <param name="cMax">Конечный цвет.</param>
        /// <param name="depth">Глубина отрисовки.</param>
        public void PaintFractal(Color cMin, Color cMax, int depth)
        {
            byte rMax = cMax.R;
            byte rMin = cMin.R;

            byte bMax = cMax.B;
            byte bMin = cMin.B;

            byte gMax = cMax.G;
            byte gMin = cMin.G;

            for (int i = 0; i < depth; i++)
            {
                if (depth != 0)
                {
                    byte rAverage = (byte)(rMin + ((rMax - rMin) * i / depth));
                    byte gAverage = (byte)(gMin + ((gMax - gMin) * i / depth));
                    byte bAverage = (byte)(bMin + ((bMax - bMin) * i / depth));
                    colorList.Add(Color.FromRgb(rAverage, gAverage, bAverage));
                }
                else
                {
                    colorList.Add(Color.FromRgb(0, 0, 0));
                }

            }
        }

    }

    /// <summary>
    /// Класс наследник от BaseFractal для фрактала типа - Множество Кантора
    /// </summary>
    public class CantorSet : BaseFractal
    {
        public static new readonly int maxDepth = 9;

        public int indent { get; init; }

        private Canvas canvas;

        /// <summary>
        /// Констркутор объекта CantorSet.
        /// </summary>
        /// <param name="canvas"></param>
        /// <param name="indent"></param>
        public CantorSet(Canvas canvas, int indent)
        {
            this.canvas = canvas;
            this.indent = indent;
        }

        public override void PrintFractal(int depth, double x1, double x2, double yCoord)
        {

            if (depth >= 0)
            {
                Line line = new Line();
                (line.X1, line.X2, line.Y1, line.Y2) = (x1, x2, yCoord, yCoord);


                double newX2Left = x1 + (x2 - x1) / 3;
                double newX1Rigth = x2 - (x2 - x1) / 3;

                if (mustPaint)
                {
                    int index = colorList.Count - depth;
                    if (index < 0 || index >= colorList.Count)
                        line.Stroke = Brushes.Black;
                    else
                        line.Stroke = new SolidColorBrush(colorList[index]);
                }
                else
                    line.Stroke = Brushes.Black;

                line.StrokeThickness = 10;

                canvas.Children.Add(line);

                PrintFractal(depth - 1, x1, newX2Left, yCoord + indent);
                PrintFractal(depth - 1, newX1Rigth, x2, yCoord + indent);
            }
        }
    }

    /// <summary>
    ///  Класс наследник от BaseFractal для фрактала типа - Треугольник Серпинского.
    /// </summary>
    public class SerpTriangle : BaseFractal
    {
        public static new readonly int maxDepth = 8;

        public override void PrintFractal(Canvas canvas, int depth, Point topPoint, Point leftPoint, Point rightPoint)
        {
            if (depth > 0)
            {
                // Находим средние точки на стронах треугольника.
                Point leftMiddle = GetMiddlePoint(topPoint, leftPoint);
                Point rightMiddle = GetMiddlePoint(topPoint, rightPoint);
                Point topMiddle = GetMiddlePoint(leftPoint, rightPoint);

                // Строим и выводим треугольник, образованный среднимим линиями.

                PointCollection polygonPoints = new PointCollection();
                polygonPoints.Add(leftMiddle);
                polygonPoints.Add(rightMiddle);
                polygonPoints.Add(topMiddle);


                Polygon triangle = new Polygon();
                triangle.Points = polygonPoints;


                if (mustPaint)
                {
                    int index = colorList.Count - depth;
                    triangle.Fill = new SolidColorBrush(colorList[index]);
                }
                else
                    triangle.Fill = fillColor;

                canvas.Children.Add(triangle);

                PrintFractal(canvas, depth - 1, topPoint, leftMiddle, rightMiddle);
                PrintFractal(canvas, depth - 1, leftMiddle, leftPoint, topMiddle);
                PrintFractal(canvas, depth - 1, rightMiddle, topMiddle, rightPoint);
            }


        }

        /// <summary>
        /// Находит координаты средней точки между двумя данными.
        /// </summary>
        /// <param name="p1">Первая точка.</param>
        /// <param name="p2">Вторая точка.</param>
        /// <returns>Координаты средней точки.</returns>
        private Point GetMiddlePoint(Point p1, Point p2)
            => new Point((p1.X + p2.X) / 2.0, (p1.Y + p2.Y) / 2.0);

    }


    /// <summary>
    ///  Класс наследник от BaseFractal для фрактала типа - Фрактальное Дерево.
    /// </summary>
    class FractalTree : BaseFractal
    {
        public static new readonly int maxDepth = 9;

        public static double lengthScale = 0.75;
        public static double deltaLeft = Math.PI / 4;
        public static double deltaRight = Math.PI / 4;


        public override void PrintFractal(Canvas canvas, int depth, Point pt, double length, double theta)
        {

            if (depth >= 0)
            {
                double x1 = pt.X + length * Math.Cos(theta);
                double y1 = pt.Y + length * Math.Sin(theta);
                Line line = new Line();

                if (mustPaint)
                {
                    int index = colorList.Count - depth;
                    if (index < 0 || index >= colorList.Count)
                        line.Stroke = Brushes.Black;
                    else
                        line.Stroke = new SolidColorBrush(colorList[index]);
                }
                else
                    line.Stroke = Brushes.Black;

                line.X1 = pt.X;
                line.Y1 = pt.Y;
                line.X2 = x1;
                line.Y2 = y1;
                canvas.Children.Add(line);


                PrintFractal(canvas, depth - 1, new Point(x1, y1), length * lengthScale, theta + deltaLeft);
                PrintFractal(canvas, depth - 1, new Point(x1, y1), length * lengthScale, theta - deltaRight);

            }




        }
    }

    /// <summary>
    ///  Класс наследник от BaseFractal для фрактала типа - Ковёр Серпинского.
    /// </summary>
    class SerpCarpet : BaseFractal
    {
        public static new readonly int maxDepth = 5;

        public override void PrintFractal(Canvas canvas, int depth,
             double leftCoord, double topCoord, int rectangleWidth, int rectangleHeight)
        {

            if (depth > 0)
            {

                // НЕТ делим прямоугольник на 9 частей
                var width = rectangleWidth / 3;
                var height = rectangleHeight / 3;

                // НЕТ (x1, y1) - координаты левой верхней вершины прямоугольника
                // от нее будем отсчитывать остальные вершины маленьких прямоугольников
                var x1 = leftCoord;
                var x2 = x1 + width;
                var x3 = x1 + 2.0 * width;

                var y1 = topCoord;
                var y2 = y1 + height;
                var y3 = y1 + 2.0 * height;

                Rectangle centreRectangle = NewRectangle(x2, y2, width, height);

                if (mustPaint)
                {
                    int index = colorList.Count - depth;
                    centreRectangle.Fill = new SolidColorBrush(colorList[index]);
                }
                else
                    centreRectangle.Fill = fillColor;

                //centreRectangle.Fill = fillColor;
                canvas.Children.Add(centreRectangle);


                PrintFractal(canvas, depth - 1, x1, y1, width, height); // левый 1(верхний)
                PrintFractal(canvas, depth - 1, x2, y1, width, height); // средний 1
                PrintFractal(canvas, depth - 1, x3, y1, width, height); // правый 1
                PrintFractal(canvas, depth - 1, x1, y2, width, height); // левый 2
                PrintFractal(canvas, depth - 1, x3, y2, width, height); // правый 2
                PrintFractal(canvas, depth - 1, x1, y3, width, height); // левый 3
                PrintFractal(canvas, depth - 1, x2, y3, width, height); // средний 3
                PrintFractal(canvas, depth - 1, x3, y3, width, height); // правый 3
            }
        }

        /// <summary>
        /// Формирует новый квадрат по координатам левой вершины, ширины и высоты.
        /// </summary>
        /// <param name="x">Х координата вершины.</param>
        /// <param name="y">Y координата вершины.</param>
        /// <param name="width">Ширина квадрата.</param>
        /// <param name="height">Высота квадрата.</param>
        /// <returns>Объект типа Rectangle - сформированный
        /// по заданным параметрам квадрат.</returns>
        private Rectangle NewRectangle(double x, double y, double width, double height)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.Width = width;
            rectangle.Height = height;
            Canvas.SetLeft(rectangle, x);
            Canvas.SetTop(rectangle, y);
            return rectangle;
        }
    }

    /// <summary>
    ///  Класс наследник от BaseFractal для фрактала типа - Кривая Коха.
    /// </summary>
    class KochCurve : BaseFractal
    {
        private Line[] lines = new Line[2];
        public static new readonly int maxDepth = 6;
        public override void PrintFractal(Canvas canvas, int depth, Line line)
        {
            if (depth >= 1)
            {
                Line lineLeft, lineCenter, lineRight, lineAng1, lineAng2;

                (lineLeft, lineCenter, lineRight) = MakeLines(line);

                lineLeft.Stroke = Brushes.Black;
                lineRight.Stroke = Brushes.Black;
                canvas.Children.Remove(line);

                (lineAng1, lineAng2) = MakeAngle(lineCenter);
                lines[0] = lineAng1;
                lines[1] = lineAng2;

                if (mustPaint)
                {
                    int index = colorList.Count - depth;
                    Brush brush = new SolidColorBrush(colorList[index]);
                    Array.ForEach(lines, l => l.Stroke = brush);
                }
                else
                    Array.ForEach(lines, l => l.Stroke = Brushes.Black);

                canvas.Children.Add(lineLeft);
                canvas.Children.Add(lineRight);
                canvas.Children.Add(lineAng1);
                canvas.Children.Add(lineAng2);

                PrintFractal(canvas, depth - 1, lineLeft);
                PrintFractal(canvas, depth - 1, lineRight);
                PrintFractal(canvas, depth - 1, lineAng1);
                PrintFractal(canvas, depth - 1, lineAng2);
            }
            else
                return;
        }

        /// <summary>
        /// Метод, который разбивает заданную линию на три равных части.
        /// </summary>
        /// <param name="lineMain">Линия для разбиения.</param>
        /// <returns>Кортеж из объектов типа Line - трёх равнях линий.</returns>
        private (Line, Line, Line) MakeLines(Line lineMain)
        {
            double segmentX = 1.0 / 3 * (lineMain.X2 - lineMain.X1);
            double segmentY = 1.0 / 3 * (lineMain.Y2 - lineMain.Y1);

            Line lineLeft = new Line();
            lineLeft.X1 = lineMain.X1;
            lineLeft.Y1 = lineMain.Y1;
            lineLeft.X2 = lineMain.X1 + segmentX;
            lineLeft.Y2 = lineMain.Y1 + segmentY;

            Line lineCenter = new Line();
            lineCenter.X1 = lineLeft.X2;
            lineCenter.Y1 = lineLeft.Y2;
            lineCenter.X2 = lineCenter.X1 + segmentX;
            lineCenter.Y2 = lineMain.Y2 - segmentY;

            Line lineRight = new Line();
            lineRight.X1 = lineCenter.X2;
            lineRight.Y1 = lineCenter.Y2;
            lineRight.X2 = lineRight.X1 + segmentX;
            lineRight.Y2 = lineMain.Y2;

            return (lineLeft, lineCenter, lineRight);
        }

        /// <summary>
        /// Метод, который решает уравнение по поиску X координаты для вершины
        /// ломанной.
        /// </summary>
        /// <param name="x1">Х координата первой точки.</param>
        /// <param name="x2">Х координата второй точки.</param>
        /// <param name="y1">Y координата первой точки.</param>
        /// <param name="y2">Y координата второй точки.</param>
        /// <param name="y">Y координата вершины ломанной.</param>
        /// <returns></returns>
        private double SolveEq(double x1, double x2, double y1, double y2, double y)
        {
            double a = x1 * x1 - x2 * x2 + (y - y1) * (y - y1) - (y - y2) * (y - y2);
            double b = 2 * x1 - 2 * x2;
            double ans = (int)(a / b);
            return ans;
        }

        /// <summary>
        /// ОБразует ломанную, состоящую из двух объектов типа Line.
        /// </summary>
        /// <param name="lineCenter">Вторая и центральная линия прямой, над которой образуется ломанная.</param>
        /// <returns>Кортеж из двух объектов типа Line.</returns>
        private (Line, Line) MakeAngle(Line lineCenter)
        {
            double X1 = lineCenter.X1;
            double X2 = lineCenter.X2;
            double Y1 = lineCenter.Y1;
            double Y2 = lineCenter.Y2;



            double length = Math.Sqrt(Math.Pow(X2 - X1, 2) + Math.Pow(Y2 - Y1, 2));

            Point p = new Point();

            if (X2 > X1)
            {

                p.Y = Math.Max(Y1, Y2) + length * Math.Sin(-Math.PI / 3);

            }
            else
            {

                p.Y = Math.Min(Y1, Y2) + length * Math.Sin(Math.PI / 3);
            }

            p.X = SolveEq(X1, X2, Y1, Y2, p.Y);

            Line leftAngelLine;
            Line rightAngelLine;
            (leftAngelLine, rightAngelLine) = MakeAngelLines(lineCenter, X1, X2, p);

            return (leftAngelLine, rightAngelLine);
        }

        private static (Line, Line) MakeAngelLines(Line lineCenter, double X1, double X2, Point p)
        {
            Line l1 = new Line();
            Line l2 = new Line();

            if (X2 > X1)
            {

                l1.X1 = lineCenter.X1;
                l1.Y1 = lineCenter.Y1;
                l1.X2 = p.X;
                l1.Y2 = p.Y;

                l2.X2 = lineCenter.X2;
                l2.Y2 = lineCenter.Y2;
                l2.X1 = p.X;
                l2.Y1 = p.Y;
            }
            else
            {
                l1.X1 = p.X;
                l1.Y1 = p.Y;
                l1.X2 = lineCenter.X1;
                l1.Y2 = lineCenter.Y1;

                l2.X2 = p.X;
                l2.Y2 = p.Y;
                l2.X1 = lineCenter.X2;
                l2.Y1 = lineCenter.Y2;
            }

            return (l1, l2);
        }
    }


}
