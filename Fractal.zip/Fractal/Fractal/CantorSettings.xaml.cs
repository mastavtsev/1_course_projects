﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Fractal
{
    /// <summary>
    /// Логика взаимодействия для CantorSettings.xaml
    /// </summary>
    public partial class CantorSettings : Window
    {
        private double data;
        public event Action<object> Ok;

        /// <summary>
        /// Инициализация элементов.
        /// </summary>
        public CantorSettings()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обработчик нажатия кнопки ОК.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        public void ButtonClick(object sender, RoutedEventArgs e)
        {
            
            data = slValue.Value;
            
            Ok?.Invoke(this);
            this.Close();

        }
    }
}
