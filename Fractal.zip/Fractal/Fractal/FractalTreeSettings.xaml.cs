﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Fractal
{
    /// <summary>
    /// Логика взаимодействия для FractalTreeSettings.xaml
    /// </summary>
    public partial class FractalTreeSettings : Window
    {
        private double[] data = new double[3];

        /// <summary>
        /// Инициализация элементов.
        /// </summary>
        public FractalTreeSettings()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обработчик нажатия кнопки ОК.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void ButtonClick(object sender, RoutedEventArgs e)
        {
            data[0] = slValue1.Value;
            data[1] = slValue2.Value;
            data[2] = slValue3.Value;
            this.Close();
        }

        /// <summary>
        /// Возвращает данные с формы.
        /// </summary>
        /// <returns>Данные с формы.</returns>
        public double[] ReturnData() => data;
        
    }
}
