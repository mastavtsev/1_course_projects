﻿using System;
    using System.Collections.Generic;
using System.IO;

/// <summary>
/// Реализация различных операция с матрицами.
/// </summary>
class V1
{
    /// <summary>
    /// Вывод в консоль доступных операций.
    /// </summary>
    private static void AvaibleOptions()
    {
        Console.WriteLine("Доступные операции:\n");
        Console.WriteLine(
                    "Нахождения следа матрицы (нажмите цифру 1).\n" +
                    "Транспонирования матрицы (нажмите цифру 2).\n" +
                    "Нахождения суммы матриц (нажмите цифру 3).\n" +
                    "Нахождения разности матриц (нажмите цифру 4).\n" +
                    "Нахождения произведения матриц (нажмите цифру 5).\n" +
                    "Умножение матрицы на число (нажмите цифру 6).\n" +
                    "Нахождения определите матрицы (нажмите цифру 7).\n" +
                    "Решение СЛАУ Методом Крамера (нажмите цифру 8).\n");
    }

    /// <summary>
    /// Подсчитывает и выводит в консоль след матрицы.
    /// </summary>
    static void Trace()
    {
        double[,] matrix;
        GetMatrix(out matrix);
        // Количество строк.
        int n = matrix.GetLength(0);

        // Количество столбцов.
        int m = matrix.GetLength(1);

        // След матрицы.
        double tr = 0;

        if (n == m)
        {
            for (int i = 0; i <= n - 1; i++)
                for (int j = 0; j <= m - 1; j++)
                    if (i == j)
                    {
                        tr += matrix[i, j];
                    }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"След матрицы: {tr}");
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка! След можно найти только у квадратной матрицы.");
            Console.ResetColor();
        }
    }

    /// <summary>
    /// Транспонирует матрицу и выводит её в консоль. 
    /// </summary>
    static void Transpose()
    {
        double[,] matrix;
        GetMatrix(out matrix);
        // Количество строк.
        int n = matrix.GetLength(0);

        // Количество столбцов.
        int m = matrix.GetLength(1);

        double[,] newMatrix = new double[m, n];
        for (var i = 0; i < matrix.GetLength(1); i++)
            for (var j = 0; j < matrix.GetLength(0); j++)
                newMatrix[i, j] = matrix[j, i];

        Console.WriteLine("Ваша транспонированная матрица:");
        Console.ForegroundColor = ConsoleColor.Green;
        for (var i = 0; i < newMatrix.GetLength(0); i++, Console.WriteLine())
            for (var j = 0; j < newMatrix.GetLength(1); j++)
                Console.Write("{0,13}", newMatrix[i, j]);
        Console.ResetColor();

    }

    /// <summary>
    /// Находит сумму двух матриц и выводит её в консоль.
    /// </summary>
    static void Sum()
    {
        Console.WriteLine("Формирование первой матрицы.");
        double[,] matrixA;
        GetMatrix(out matrixA);
        // Количество строк.
        int nA = matrixA.GetLength(0);
        // Количество столбцов.
        int mA = matrixA.GetLength(1);
        Console.WriteLine();
        Console.WriteLine("Формирование второй матрицы. \n");
        double[,] matrixB;
        GetMatrix(out matrixB);
        // Количество строк.
        int nB = matrixB.GetLength(0);
        // Количество столбцов.
        int mB = matrixB.GetLength(1);

        double[,] matrixSum = new double[nA, mA];

        if (nA == nB && mA == mB)
        {
            for (var i = 0; i < nA; i++)
                for (var j = 0; j < mA; j++)
                    matrixSum[i, j] = matrixA[i, j] + matrixB[i, j];
            Console.WriteLine("Сумма матриц:");
            Console.ForegroundColor = ConsoleColor.Green;
            for (var i = 0; i < matrixSum.GetLength(0); i++, Console.WriteLine())
                for (var j = 0; j < matrixSum.GetLength(1); j++)
                    Console.Write("{0,13}", matrixSum[i, j]);
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка! Недопустимо сложение матриц различных размеров.");
            Console.ResetColor();
        }
    }

    /// <summary>
    /// Находит разность двух матриц и выводит её в консоль.  
    /// Diff от difference - разность
    /// </summary>
    static void Diff()
    {
        Console.WriteLine("Формирование первой матрицы. \n");
        double[,] matrixA;
        GetMatrix(out matrixA);
        // Количество строк.
        int nA = matrixA.GetLength(0);
        // Количество столбцов.
        int mA = matrixA.GetLength(1);
        Console.WriteLine();
        Console.WriteLine("Формирование второй матрицы. \n");
        double[,] matrixB;
        GetMatrix(out matrixB);
        // Количество строк.
        int nB = matrixB.GetLength(0);
        // Количество столбцов.
        int mB = matrixB.GetLength(1);

        double[,] matrixDiff = new double[nA, mA];

        if (nA == nB && mA == mB)
        {
            for (var i = 0; i < nA; i++)
                for (var j = 0; j < mA; j++)
                    matrixDiff[i, j] = matrixA[i, j] - matrixB[i, j];
            Console.WriteLine("Разность матриц:");
            Console.ForegroundColor = ConsoleColor.Green;
            for (var i = 0; i < matrixDiff.GetLength(0); i++, Console.WriteLine())
                for (var j = 0; j < matrixDiff.GetLength(1); j++)
                    Console.Write("{0,13}", matrixDiff[i, j]);
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка! Недопустимо вычитание матриц различных размеров.");
            Console.ResetColor();
        }
    }

    /// <summary>
    /// Находит произведение двух матриц и выводит его в консоль.
    /// </summary>
    static void ProductMatrix()
    {
        Console.WriteLine("Формирование первой матрицы.");
        double[,] matrixA;
        GetMatrix(out matrixA);
        // Количество строк.
        int nA = matrixA.GetLength(0);
        // Количество столбцов.
        int mA = matrixA.GetLength(1);
        Console.WriteLine();
        Console.WriteLine("Формирование второй матрицы.");
        double[,] matrixB;
        GetMatrix(out matrixB);
        // Количество строк.
        int nB = matrixB.GetLength(0);
        // Количество столбцов.
        int mB = matrixB.GetLength(1);

        double[,] matrixProd = new double[nA, mB];
        if (mA == nB)
        {
            for (var i = 0; i < nA; i++)
                for (var j = 0; j < mB; j++)
                {
                    double s = 0;
                    for (int x = 0, y = 0; x < mA && y < nB; x++, y++)
                        s += matrixA[i, x] * matrixB[y, j];
                    matrixProd[i, j] = s;
                }
            Console.WriteLine("Произведение матриц:");
            Console.ForegroundColor = ConsoleColor.Green;
            for (var i = 0; i < matrixProd.GetLength(0); i++, Console.WriteLine())
                for (var j = 0; j < matrixProd.GetLength(1); j++)
                    Console.Write("{0,13}", matrixProd[i, j]);
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка! Недопустимо умножение матриц различных размеров.");
            Console.ResetColor();
        }


    }

    /// <summary>
    /// Находит произведение матрицы на число и выводит его в консоль.
    /// </summary>
    static void ProductNumber()
    {
        double[,] matrix;
        GetMatrix(out matrix);
        // Количество строк.
        int n = matrix.GetLength(0);
        // Количество столбцов.
        int m = matrix.GetLength(1);
        double delta;

        do
        {
            Console.Write("Введите число не равное 0:  ");
        } while (!double.TryParse(Console.ReadLine(), out delta) || delta == 0);

        for (var i = 0; i < matrix.GetLength(0); i++)
            for (var j = 0; j < matrix.GetLength(1); j++)
                matrix[i, j] = delta * matrix[i, j];

        Console.WriteLine("Результат умножения матрицы на число:");
        Console.ForegroundColor = ConsoleColor.Green;
        for (var i = 0; i < matrix.GetLength(0); i++, Console.WriteLine())
            for (var j = 0; j < matrix.GetLength(1); j++)
                Console.Write("{0, 13}", matrix[i, j]);
        Console.ResetColor();
    }

    /// <summary>
    /// ConvMatrix - matrix converted - матрица преобразованная.
    /// Этот метод нужен при нахождении определителя матрицы. 
    /// Он создаёт новую матрицу, без первой строки 
    /// и предыдущего столбца j оригинальной матрицы. 
    /// 
    /// pj - previous j.
    /// </summary>
    /// <param name="pj">Индекс предыдущего столбца.</param>
    /// <param name="matrix">Оригинальная матрица.</param>
    /// <returns>matrixConv - результат разложения матрицы</returns>
    static double[,] ConvMatrix(int pj, double[,] matrix)
    {
        double[,] matrixConv = new double[matrix.GetLength(0) - 1, matrix.GetLength(1) - 1];
        int x = 0, y = 0;
        for (var i = 0; i < matrix.GetLength(0); i++)
            for (var j = 0; j < matrix.GetLength(0); j++)
                if (i != 0 && j != pj)
                {
                    matrixConv[x, y] = matrix[i, j];
                    y++;
                    if (y == (matrix.GetLength(1) - 1))
                    {
                        y = 0;
                        x++;
                    }
                }
        return matrixConv;
    }

    /// <summary>
    /// Осуществляет рекурсивное разложение матрицы и поиск её определителя.
    /// </summary>
    /// <param name="matrix">Матрица, у которой ищется определитель.</param>
    /// <returns>det - значение определителя матрицы.</returns>
    static double DefRec(double[,] matrix)
    {
        if (matrix.Length == 1)
        {
            return matrix[0, 0];
        }

        if (matrix.GetLength(0) == 2 && matrix.GetLength(1) == 2)
        {
            return matrix[0, 0] * matrix[1, 1] - matrix[0, 1] * matrix[1, 0];
        }
        else
        {
            double det = 0;
            for (var j = 0; j < matrix.GetLength(1); j++)
            {
                det += Math.Pow(-1, j) * matrix[0, j] * DefRec(ConvMatrix(j, matrix));
            }
            return det;
        }
    }

    /// <summary>
    /// Осуществляет вызов метода DefRec() и вывод в консоль
    /// определителя матрицы.
    /// </summary>
    static void Def()
    {
        GetMatrix(out double[,] matrix);
        // Количество строк.
        int n = matrix.GetLength(0);
        // Количество столбцов.
        int m = matrix.GetLength(1);

        if (n == m)
        {
            Console.Write($"Определитель матрицы равен: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(DefRec(matrix));
            Console.ResetColor();
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка! Для нахождения определителя матрица должна быть квадратной.");
            Console.ResetColor();
        }
    }

    /// <summary>
    /// Осуществляет решение СЛАУ методом Крамера путём вызова дополнительных методов
    /// DefRec() и GetDets().
    /// Выводит значение неизвестных или другие дополнительные сообщения. 
    /// </summary>
    static void SolveSLE()
    {
        double[,] matrix;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("Важно отметить, вводимая матрица должна включать как неизвестные, так и свободные члены. \n" +
            "Например, при 4 неизвестных, размер матрица должен быть 4 на 5. \n" +
            "То есть 4 уравнения с 4 неизвестными, а также свободные члены. \n");
        Console.ResetColor();
        GetMatrix(out matrix);
        // Количество строк.
        int n = matrix.GetLength(0);
        // Количество столбцов.
        int m = matrix.GetLength(1);
        if (n == m - 1)
        {
            double[][,] determinants;
            GetDets(n, m, matrix, out determinants);

            double delta0 = DefRec(determinants[0]);
            Console.ForegroundColor = ConsoleColor.Green;
            if (delta0 != 0)
            {
                Console.WriteLine();
                for (int k = 1; k < determinants.Length; k++)
                {
                    double x = DefRec(determinants[k]) / delta0;
                    if (x == -0)
                        x = 0;
                    Console.WriteLine($"x{k} = { x:f5}");
                }
                Console.ResetColor();
            }
            else
            {

                for (int k = 1; k < determinants.Length; k++)
                {
                    double x = DefRec(determinants[k]) / delta0;
                    if (x != 0)
                    {

                        Console.WriteLine("Cистема не имеет решений");
                        Console.ResetColor();
                        return;
                    }
                    Console.WriteLine("Cистема имеет бесконечно много решений");
                    Console.ResetColor();
                }
            }
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ошибка! Для метода Крамера матрица должна быть квадратной.");
            Console.ResetColor();
        }
    }

    /// <summary>
    /// Осуществляет дробление полученой матрицы на матрицы меньшего размера для решения СЛАУ методом Крамера.
    /// То есть на место очередного j-ого столбца подставляется столбец свободных членов.
    /// </summary>
    /// <param name="n">Количество строк матрицы.</param>
    /// <param name="m">Количество столбцов матрицы.</param>
    /// <param name="matrix">Матрица неизвестных и свободных членов.</param>
    /// <param name="dets">Массив двумерных массивов. То есть в каждой ячейке хранится массив, для
    /// которого потом будет находиться определитель.</param>
    private static void GetDets(int n, int m, double[,] matrix, out double[][,] dets)
    {
        dets = new double[n + 1][,];
        double[,] mat = new double[n, m - 1];

        for (var i = 0; i < n; i++)
            for (var j = 0; j < m; j++)
            {
                if (j != m - 1)
                {
                    mat[i, j] = matrix[i, j];
                }
            }

        // Нулевым элементом массива является матрица неизвестных, без свободных членов.
        dets[0] = mat;

        // Далее в очердной ячейке хранится двумерный массив,
        // в котором j-ый столбец заменён на столбец свободных членов.
        for (int k = 1; k <= m - 1; k++)
        {
            double[,] matt = new double[n, m - 1];
            for (var i = 0; i < matrix.GetLength(0); i++)
                for (var j = 0; j < matrix.GetLength(0); j++)
                {
                    if (j == k - 1)
                        matt[i, j] = matrix[i, m - 1];
                    else
                        matt[i, j] = matrix[i, j];
                }
            dets[k] = matt;
        }
    }

    /// <summary>
    /// Получает от пользователя желаемый размер матрицы.
    /// </summary>
    /// <returns>Количество строк и столбцов матрицы.</returns>
    static (int, int) GetMatrixSize()
    {
        int m, n;
        Console.WriteLine("Максимально допустимая размерность 10х10. \n");
        do
        {
            Console.Write("Введите количество строк n: ");
        } while (!int.TryParse(Console.ReadLine(), out n) || n <= 0 || n > 10);
        do
        {
            Console.Write("Введите количество столбоц m: ");
        } while (!int.TryParse(Console.ReadLine(), out m) || m <= 0 || m > 10);

        Console.WriteLine();
        return (n, m);
    }

    /// <summary>
    /// Формирует матрицу со случайными элементами,
    /// причём все элементы - исключительно целые числа. 
    /// Заполняет матрицу.
    /// </summary>
    /// <param name="n">Количество строк матрицы.</param>
    /// <param name="m">Количество столбцов матрицы.</param>
    /// <param name="matrix">Матрица, в которую подставятся случайные элементы.</param>
    static void FormMatrixRandom(int n, int m, out double[,] matrix)
    {
        matrix = new double[n, m];
        // Левая и правая границы генерации.
        int leftNum;
        int rightNum;
        Console.WriteLine(
                          "Минимально и максимально допустимыми значениями являются \n" +
                          "-2147483648 и 2147483647 \n");
        do
        {
            Console.Write("Введите левую границу генерации: ");
        } while (!int.TryParse(Console.ReadLine(), out leftNum));
        do
        {
            Console.Write("Введите правую границу генерации: ");
        } while (!int.TryParse(Console.ReadLine(), out rightNum));

        if (leftNum<= rightNum)
        {
            for (var i = 0; i < n; i++)
                for (var j = 0; j < m; j++)
                    matrix[i, j] = new Random().Next(leftNum, rightNum);
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n Левая граница не может превышать правую. Повторите ввод матрицы.\n");
            Console.ResetColor();
            FormMatrixRandom(n, m, out matrix);
        }

        Console.WriteLine("Ваша матрица:");
        for (var i = 0; i < matrix.GetLength(0); i++, Console.WriteLine())
            for (var j = 0; j < matrix.GetLength(1); j++)
                Console.Write("{0,13}", matrix[i, j]);
    }

    /// <summary>
    /// Считывает матрицу из файла.
    /// Заполняет матрицу.
    /// </summary>
    /// <param name="n">Количество строк матрицы.</param>
    /// <param name="m">Количество столбцов матрицы.</param>
    /// <param name="matrix">Матрица, в которой будут считанные из файла элементы.</param>
    static void ReadMatrixFile(int n, int m, out double[,] matrix)
    {
        // Матрица.
        matrix = new double[n, m];
        Console.WriteLine("Максимально и минимально допустимыми значениями являются +-1,7E+308.");
        //Файл находится в bin/Debug/net5.0; Он пуст, для проверки нужно занести какие-то значения.
        Console.WriteLine(@"Путь файла MatrixRead для записи матрицы: Calculator_peergrade\bin\Debug\net5.0\MatrixRead.txt");
        if (File.Exists(@"MatrixRead.txt"))
        {
            using (var sr = new StreamReader(@"MatrixRead.txt"))
            {
                // Индекс.
                int i = 0;
                // Вспомогательный массив.
                string[] lineArr;
                string line;
                while (i + 1 <= n)
                {
                    line = sr.ReadLine();
                    if (line == null)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\nОшибка! Файл пуст! \n");
                        Console.ResetColor();
                        GetMatrix(out matrix);
                        return;
                    }
                    lineArr = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                    if (lineArr.Length != m)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\nОшибка! Размерность не совпадает с заданой. \n");
                        Console.ResetColor();
                        GetMatrix(out matrix);
                        return;
                    }

                    foreach (string x in lineArr)
                    {
                        if (!double.TryParse(x, out _))
                        {
                            string message = "Ошибка! Невозможно преобразовать в число или число " +
                                "выходить за границы допустимого диапазона.";
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"\n {message} \n");
                            Console.ResetColor();
                            GetMatrix(out matrix);
                            return;
                        }
                    }
                    for (var j = 0; j < m; j++)
                        matrix[i, j] = double.Parse(lineArr[j]);
                    i++;
                }
            }
        }
        else
        {
            ChangeColor("Файл не найден", 1);
            GetMatrix(out matrix);
        }
    }

    /// <summary>
    /// Осуществляет считывание строк матрицы, введёных пользователем.
    /// Заполняет матрицу.
    /// </summary>
    /// <param name="n">Количество строк матрицы.</param>
    /// <param name="m">Количество столбцов матрицы.</param>
    /// <param name="matrix">Матрица, в которой будут введёные пользователем числа.</param>
    static void FormMatrixUser(int n, int m, out double[,] matrix)
    {
        Console.WriteLine("Введите строки матрицы, каждый элемент вводится через пробел. ");
        Console.WriteLine("Максимально и минимально допустимыми значениями являются +- 1,7E+308");
        // Матрица.
        matrix = new double[n, m];
        List<double> arr = new();
        for (var i = 0; i <= n - 1; i++)
        {
            do
            {
                arr.Clear();
                string[] line = Console.ReadLine().Split(' ');
                for (var x = 0; x <= line.Length - 1; x++)
                    if (double.TryParse(line[x], out double q))
                        arr.Add(q);
                if (arr.Count != m)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Ошибка! Повторите ввод строки.");
                    Console.ResetColor();
                }

            } while (arr.Count != m);
            for (var j = 0; j <= m - 1; j++)
                matrix[i, j] = arr[j];
        }

    }

    /// <summary>
    /// Осуществляет вызов метода для формирования матрицы 
    /// в зависимости от способа заполнения матрицы, выбранного пользователем.
    /// </summary>
    /// <param name="matrix">Матрица, элементы которой следует заполнить.</param>
    static void GetMatrix(out double[,] matrix)
    {
        ConsoleKeyInfo info;
        (int, int) x = GetMatrixSize();
        // Количество строк матрицы.
        int n = x.Item1;
        // Количество столбцов матрицы.
        int m = x.Item2;
        Console.WriteLine(
            "Вы можете сами ввести содержимое матрицы или сгенерировать его случайным оборазом. \n" +
            "Случайно могут быть сгенерированы только целые числа. \n" +
            "При самостоятельном вводе могут использоваться нецелые числа. \n" +
            "Для самостоятельного ввода нажмите 1. \n" +
            "Для случайной генерации нажмите 2.\n" +
            "Для чтения из файла нажмите 3. \n");

        info = Console.ReadKey(true);
        switch (info.Key)
        {
            case ConsoleKey.D1:
            case ConsoleKey.NumPad1:
                FormMatrixUser(n, m, out matrix);
                return;
            case ConsoleKey.D2:
            case ConsoleKey.NumPad2:
                FormMatrixRandom(n, m, out matrix);
                return;
            case ConsoleKey.D3:
            case ConsoleKey.NumPad3:
                ReadMatrixFile(n, m, out matrix);
                return;
            default:
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ошибка, подтвердите выбор ещё раз!");
                Console.ResetColor();
                Console.WriteLine();
                GetMatrix(out matrix);
                return;
        }

    }

    /// <summary>
    /// Меняет цвет консоли.
    /// </summary>
    /// <param name="str">Текст, цвет которго следует изменить.</param>
    /// <param name="i">Параметр, при нулевом значении которого цвет консоли становится зелёным,
    /// а при другом значении - красным.</param>
    static void ChangeColor(string str, int i)
    {
        Console.Clear();
        Console.ForegroundColor = i == 0 ? ConsoleColor.Green : ConsoleColor.Red;
        Console.WriteLine($"{str} \n");
        Console.ResetColor();
    }

    /// <summary>
    /// Вызов метода для выполнения операции, выбранной пользователем.
    /// </summary>
    static void SelectOption()
    {
        ConsoleKeyInfo info;
        AvaibleOptions();
        info = Console.ReadKey(true);
        switch (info.Key)
        {
            case ConsoleKey.D1:
            case ConsoleKey.NumPad1:
                ChangeColor("Нахождение следа матрицы.", 0);
                Trace();
                return;
            case ConsoleKey.D2:
            case ConsoleKey.NumPad2:
                ChangeColor("Транспонирование матрицы.", 0);
                Transpose();
                return;
            case ConsoleKey.D3:
            case ConsoleKey.NumPad3:
                ChangeColor("Нахождение суммы матриц.", 0);
                Sum();
                return;
            case ConsoleKey.D4:
            case ConsoleKey.NumPad4:
                ChangeColor("Разность матриц.", 0);
                Diff();
                return;
            case ConsoleKey.D5:
            case ConsoleKey.NumPad5:
                ChangeColor("Произведение матриц.", 0);
                ProductMatrix();
                return;
            case ConsoleKey.D6:
            case ConsoleKey.NumPad6:
                ChangeColor("Умножение матрицы на число.", 0);
                ProductNumber();
                return;
            case ConsoleKey.D7:
            case ConsoleKey.NumPad7:
                ChangeColor("Определитель матрицы.", 0);
                Def();
                return;
            case ConsoleKey.D8:
            case ConsoleKey.NumPad8:
                ChangeColor("Решение СЛАУ методом Крамера.", 0);
                SolveSLE();
                return;
            default:
                ChangeColor("Ошибка, сделайте выбор ещё раз!", 1);
                SelectOption();
                return;
        }
    }

    /// <summary>
    /// Приветствие пользователя. Осуществления повторения решения.
    /// </summary>
    static void Main()
    {
        Console.Title = "Calculator";
        Console.WriteLine(
            "Здравствуйте, дорогой пользователь! \n" +
            "Перед тобой Calculator, программа, производящая \n" +
            "различные операции над матрицой. \n");


        ConsoleKeyInfo info;

        do
        {
            SelectOption();

            Console.WriteLine("Для продолжения нажмите Enter, для завершения любую другую клавишу.");
            info = Console.ReadKey(true);
            if (info.Key == ConsoleKey.Enter)
                Console.Clear();
        } while (info.Key == ConsoleKey.Enter);
    }

}
