﻿
namespace TextEditor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.создатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NewWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохраниToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьВсёToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отменитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.вырезатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.времяИДатаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.форматToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.шрифтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.подстветкаСинтаксисваCSФайлаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьЧастотуСохраненияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sec1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sec2 = new System.Windows.Forms.ToolStripMenuItem();
            this.sec5 = new System.Windows.Forms.ToolStripMenuItem();
            this.sec10 = new System.Windows.Forms.ToolStripMenuItem();
            this.sec55 = new System.Windows.Forms.ToolStripMenuItem();
            this.ColorTheme = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьВкладкуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cЙайлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.выбратьВесьТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вырезатьВыделенныйФрагментToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьФрагментToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вставитьФрагментToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.задатьФорматФраментаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(36, 36);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.форматToolStripMenuItem,
            this.настройкиToolStripMenuItem,
            this.добавитьВкладкуToolStripMenuItem,
            this.cЙайлToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьToolStripMenuItem,
            this.NewWindow,
            this.открытьToolStripMenuItem,
            this.сохраниToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem,
            this.сохранитьВсёToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.ShowShortcutKeys = false;
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // создатьToolStripMenuItem
            // 
            this.создатьToolStripMenuItem.Name = "создатьToolStripMenuItem";
            this.создатьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.создатьToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.создатьToolStripMenuItem.Text = "Создать";
            this.создатьToolStripMenuItem.Click += new System.EventHandler(this.CreateNewFile_Click);
            // 
            // NewWindow
            // 
            this.NewWindow.Name = "NewWindow";
            this.NewWindow.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.N)));
            this.NewWindow.Size = new System.Drawing.Size(318, 22);
            this.NewWindow.Text = "Новое окно";
            this.NewWindow.Click += new System.EventHandler(this.NewForm);
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.OpenFile_Click);
            // 
            // сохраниToolStripMenuItem
            // 
            this.сохраниToolStripMenuItem.Name = "сохраниToolStripMenuItem";
            this.сохраниToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.сохраниToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.сохраниToolStripMenuItem.Text = "Сохранить";
            this.сохраниToolStripMenuItem.Click += new System.EventHandler(this.SaveFile_Click);
            // 
            // сохранитьКакToolStripMenuItem
            // 
            this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
            this.сохранитьКакToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.сохранитьКакToolStripMenuItem.Text = "Сохранить как";
            this.сохранитьКакToolStripMenuItem.Click += new System.EventHandler(this.SaveFileAs_Click);
            // 
            // сохранитьВсёToolStripMenuItem
            // 
            this.сохранитьВсёToolStripMenuItem.Name = "сохранитьВсёToolStripMenuItem";
            this.сохранитьВсёToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt) 
            | System.Windows.Forms.Keys.S)));
            this.сохранитьВсёToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.сохранитьВсёToolStripMenuItem.Text = "Сохранить все открытые  файлы";
            this.сохранитьВсёToolStripMenuItem.Click += new System.EventHandler(this.SaveAllFiles_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.AppExit_Click);
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отменитьToolStripMenuItem,
            this.toolStripSeparator1,
            this.вырезатьToolStripMenuItem,
            this.копироватьToolStripMenuItem,
            this.вставитьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.toolStripSeparator2,
            this.времяИДатаToolStripMenuItem});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "Правка";
            // 
            // отменитьToolStripMenuItem
            // 
            this.отменитьToolStripMenuItem.Name = "отменитьToolStripMenuItem";
            this.отменитьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.отменитьToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.отменитьToolStripMenuItem.Text = "Отменить";
            this.отменитьToolStripMenuItem.Click += new System.EventHandler(this.Menu_Undo);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(178, 6);
            // 
            // вырезатьToolStripMenuItem
            // 
            this.вырезатьToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.вырезатьToolStripMenuItem.Name = "вырезатьToolStripMenuItem";
            this.вырезатьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.вырезатьToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.вырезатьToolStripMenuItem.Text = "Вырезать";
            this.вырезатьToolStripMenuItem.Click += new System.EventHandler(this.Menu_Cut);
            // 
            // копироватьToolStripMenuItem
            // 
            this.копироватьToolStripMenuItem.Name = "копироватьToolStripMenuItem";
            this.копироватьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.копироватьToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.копироватьToolStripMenuItem.Text = "Копировать";
            this.копироватьToolStripMenuItem.Click += new System.EventHandler(this.Menu_Copy);
            // 
            // вставитьToolStripMenuItem
            // 
            this.вставитьToolStripMenuItem.Name = "вставитьToolStripMenuItem";
            this.вставитьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.вставитьToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.вставитьToolStripMenuItem.Text = "Вставить";
            this.вставитьToolStripMenuItem.Click += new System.EventHandler(this.Menu_Paste);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.Menu_Delete);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(178, 6);
            // 
            // времяИДатаToolStripMenuItem
            // 
            this.времяИДатаToolStripMenuItem.Name = "времяИДатаToolStripMenuItem";
            this.времяИДатаToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.времяИДатаToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.времяИДатаToolStripMenuItem.Text = "Время и дата";
            this.времяИДатаToolStripMenuItem.Click += new System.EventHandler(this.Menu_DateTime);
            // 
            // форматToolStripMenuItem
            // 
            this.форматToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.шрифтToolStripMenuItem,
            this.подстветкаСинтаксисваCSФайлаToolStripMenuItem});
            this.форматToolStripMenuItem.Name = "форматToolStripMenuItem";
            this.форматToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.форматToolStripMenuItem.Text = "Формат";
            // 
            // шрифтToolStripMenuItem
            // 
            this.шрифтToolStripMenuItem.Name = "шрифтToolStripMenuItem";
            this.шрифтToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.шрифтToolStripMenuItem.Text = "Шрифт...";
            this.шрифтToolStripMenuItem.Click += new System.EventHandler(this.Text_Font);
            // 
            // подстветкаСинтаксисваCSФайлаToolStripMenuItem
            // 
            this.подстветкаСинтаксисваCSФайлаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.подстветкаСинтаксисваCSФайлаToolStripMenuItem.Name = "подстветкаСинтаксисваCSФайлаToolStripMenuItem";
            this.подстветкаСинтаксисваCSФайлаToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.подстветкаСинтаксисваCSФайлаToolStripMenuItem.Text = "Подстветка синтаксиса .CS файла";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(184, 22);
            this.toolStripMenuItem1.Text = "Имён классов";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(184, 22);
            this.toolStripMenuItem2.Text = "Имена переменных";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(184, 22);
            this.toolStripMenuItem3.Text = "Комментарии";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(184, 22);
            this.toolStripMenuItem4.Text = "Ключевые слова";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.задатьЧастотуСохраненияToolStripMenuItem,
            this.ColorTheme});
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.настройкиToolStripMenuItem.Text = "Настройки";
            // 
            // задатьЧастотуСохраненияToolStripMenuItem
            // 
            this.задатьЧастотуСохраненияToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sec1,
            this.sec2,
            this.sec5,
            this.sec10,
            this.sec55});
            this.задатьЧастотуСохраненияToolStripMenuItem.Name = "задатьЧастотуСохраненияToolStripMenuItem";
            this.задатьЧастотуСохраненияToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.задатьЧастотуСохраненияToolStripMenuItem.Text = "Задать частоту сохранения";
            // 
            // sec1
            // 
            this.sec1.Name = "sec1";
            this.sec1.Size = new System.Drawing.Size(135, 22);
            this.sec1.Text = "5 секунда";
            this.sec1.Click += new System.EventHandler(this.SetAutoSaveTimeSpanTab_Click);
            // 
            // sec2
            // 
            this.sec2.Name = "sec2";
            this.sec2.Size = new System.Drawing.Size(135, 22);
            this.sec2.Text = "10 секунды";
            this.sec2.Click += new System.EventHandler(this.SetAutoSaveTimeSpanTab_Click);
            // 
            // sec5
            // 
            this.sec5.Name = "sec5";
            this.sec5.Size = new System.Drawing.Size(135, 22);
            this.sec5.Text = "15 секунд";
            this.sec5.Click += new System.EventHandler(this.SetAutoSaveTimeSpanTab_Click);
            // 
            // sec10
            // 
            this.sec10.Name = "sec10";
            this.sec10.Size = new System.Drawing.Size(135, 22);
            this.sec10.Text = "30 секунд";
            this.sec10.Click += new System.EventHandler(this.SetAutoSaveTimeSpanTab_Click);
            // 
            // sec55
            // 
            this.sec55.Name = "sec55";
            this.sec55.Size = new System.Drawing.Size(135, 22);
            this.sec55.Text = "55 секунд";
            this.sec55.Click += new System.EventHandler(this.SetAutoSaveTimeSpanTab_Click);
            // 
            // ColorTheme
            // 
            this.ColorTheme.Name = "ColorTheme";
            this.ColorTheme.Size = new System.Drawing.Size(223, 22);
            this.ColorTheme.Text = "Сменить тему";
            this.ColorTheme.Click += new System.EventHandler(this.ColorTheme_Click);
            // 
            // добавитьВкладкуToolStripMenuItem
            // 
            this.добавитьВкладкуToolStripMenuItem.Name = "добавитьВкладкуToolStripMenuItem";
            this.добавитьВкладкуToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.добавитьВкладкуToolStripMenuItem.Size = new System.Drawing.Size(177, 20);
            this.добавитьВкладкуToolStripMenuItem.Text = "Добавить текстовую вкладку";
            this.добавитьВкладкуToolStripMenuItem.Click += new System.EventHandler(this.AddTab_Click);
            // 
            // cЙайлToolStripMenuItem
            // 
            this.cЙайлToolStripMenuItem.Name = "cЙайлToolStripMenuItem";
            this.cЙайлToolStripMenuItem.Size = new System.Drawing.Size(134, 20);
            this.cЙайлToolStripMenuItem.Text = "Добавить CS вкладку";
            this.cЙайлToolStripMenuItem.Click += new System.EventHandler(this.CSharpFileTab);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 406);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 378);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Безымянный_1";
            // 
            // richTextBox1
            // 
            this.richTextBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.richTextBox1.Location = new System.Drawing.Point(3, 3);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(786, 372);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(36, 36);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выбратьВесьТекстToolStripMenuItem,
            this.вырезатьВыделенныйФрагментToolStripMenuItem,
            this.копироватьФрагментToolStripMenuItem,
            this.вставитьФрагментToolStripMenuItem,
            this.задатьФорматФраментаToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(215, 114);
            // 
            // выбратьВесьТекстToolStripMenuItem
            // 
            this.выбратьВесьТекстToolStripMenuItem.Name = "выбратьВесьТекстToolStripMenuItem";
            this.выбратьВесьТекстToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.выбратьВесьТекстToolStripMenuItem.Text = "Выбрать весь текст";
            this.выбратьВесьТекстToolStripMenuItem.Click += new System.EventHandler(this.SelectAllText_Click);
            // 
            // вырезатьВыделенныйФрагментToolStripMenuItem
            // 
            this.вырезатьВыделенныйФрагментToolStripMenuItem.Name = "вырезатьВыделенныйФрагментToolStripMenuItem";
            this.вырезатьВыделенныйФрагментToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.вырезатьВыделенныйФрагментToolStripMenuItem.Text = "Вырезать фрагмент";
            this.вырезатьВыделенныйФрагментToolStripMenuItem.Click += new System.EventHandler(this.Menu_Cut);
            // 
            // копироватьФрагментToolStripMenuItem
            // 
            this.копироватьФрагментToolStripMenuItem.Name = "копироватьФрагментToolStripMenuItem";
            this.копироватьФрагментToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.копироватьФрагментToolStripMenuItem.Text = "Копировать фрагмент";
            this.копироватьФрагментToolStripMenuItem.Click += new System.EventHandler(this.Menu_Copy);
            // 
            // вставитьФрагментToolStripMenuItem
            // 
            this.вставитьФрагментToolStripMenuItem.Name = "вставитьФрагментToolStripMenuItem";
            this.вставитьФрагментToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.вставитьФрагментToolStripMenuItem.Text = "Вставить фрагмент";
            this.вставитьФрагментToolStripMenuItem.Click += new System.EventHandler(this.Menu_Paste);
            // 
            // задатьФорматФраментаToolStripMenuItem
            // 
            this.задатьФорматФраментаToolStripMenuItem.Name = "задатьФорматФраментаToolStripMenuItem";
            this.задатьФорматФраментаToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.задатьФорматФраментаToolStripMenuItem.Text = "Задать формат фрамента";
            this.задатьФорматФраментаToolStripMenuItem.Click += new System.EventHandler(this.Text_Font);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 430);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Notepad+";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форматToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem создатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохраниToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.ToolStripMenuItem добавитьВкладкуToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ToolStripMenuItem отменитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вырезатьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вставитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem времяИДатаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem шрифтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задатьЧастотуСохраненияToolStripMenuItem;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem sec2;
        private System.Windows.Forms.ToolStripMenuItem sec5;
        private System.Windows.Forms.ToolStripMenuItem sec10;
        private System.Windows.Forms.ToolStripMenuItem sec55;
        private System.Windows.Forms.ToolStripMenuItem sec1;
        private System.Windows.Forms.ToolStripMenuItem ColorTheme;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem выбратьВесьТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вырезатьВыделенныйФрагментToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьФрагментToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вставитьФрагментToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem задатьФорматФраментаToolStripMenuItem;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ToolStripMenuItem NewWindow;
        private System.Windows.Forms.ToolStripMenuItem сохранитьВсёToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cЙайлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem подстветкаСинтаксисваCSФайлаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

