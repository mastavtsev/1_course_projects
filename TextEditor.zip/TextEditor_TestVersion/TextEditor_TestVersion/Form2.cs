﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextEditor_TestVersion
{
    public partial class Form2 : Form
    {
        // Хранит текст, представляющий определённый текст.
        public string SelectedText { get; set; }

        /// <summary>
        /// Инициализация компонентов формы.
        /// </summary>
        public Form2()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton1.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton1.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton2.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton2.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton3.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton3.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton4.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton4.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton5.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton5.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton6.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton6.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton7.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton7.Text;
        }

        /// <summary>
        /// Обработчик события при нажатии radioButton7.
        /// Сохраняет в SelectedText значение цвета.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            SelectedText = radioButton8.Text;
        }

        
    }
}
