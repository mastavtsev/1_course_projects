﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.IO;
using System.Text.RegularExpressions;


namespace TextEditor
{
    /// <summary>
    /// Класс для работы с Form1.
    /// </summary>
    public partial class Form1 : Form
    {
        // Список, хранящий объекты RichTextBox или FastColoredTextBox, которые содержатся на вкладках.
        List<Object> boxList = new List<Object> { };     

        //Список хранящий информацию о наличии сохранения документа на каждой вкладке.
        List<bool> isChanged = new List<bool> { };

        //Список хранящий путь документа на каждой вкладке.
        List<string> fileNames = new List<string> { };

        // Массив, хранящий стили для элеметов .CS файла. 
        Style[] styleForCSFile = new Style[4];

        // Тема по умолчанию.
        string themeColor = "White";

        //Цвета заднего и переднего плана. 
        Color colorBack;
        Color colorFore;

        // Делегат, ждя обработки событий.
        public event EventHandler OpenNewForm;

        /// <summary>
        /// Инициализация компонентов Form1.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Инициализация необходимых полей, а так же выполнение 
        /// метода для подгрузки файлов.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Form1_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(Environment.CurrentDirectory);
            boxList.Add(richTextBox1);
            isChanged.Add(false);
            fileNames.Add("");
            fontDialog1.ShowColor = true;
            timer1.Interval = 5000;
            timer1.Enabled = true;
            if (File.Exists("ColorBase.txt"))
                themeColor = File.ReadAllText("ColorBase.txt");
            SetTheme();
            ReadColorForCSFile();

            // Путь к текстовому документу со списоком файлов для открытия.
            string path = $@"{Environment.CurrentDirectory}\FilesBase\{Name}.txt";
            if (File.Exists(path) && Path.GetFileName(path) == $"{Name}.txt")
                //MessageBox.Show(path);
                FilesReload(path);
        }

        /// <summary>
        /// Считывание из файла цветов для элементов .CS файла.
        /// </summary>
        private void ReadColorForCSFile()
        {
            try
            {
                string[] colors = File.ReadAllText("CSFileColorBase.txt").Split(Environment.NewLine,
                StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < styleForCSFile.Length; i++)
                {
                    styleForCSFile[i] = ConverColor(SwitchLanguage(colors[i]));
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        /// <summary>
        /// Загрузка файлов, при перезапуске приложения.
        /// </summary>
        /// <param name="path">Путь к файлу, содержащий пути для загрузки файлов.</param>
        private void FilesReload(string path)
        {
            try
            {
                string[] filesToReload = File.ReadAllText(path).Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < filesToReload.Length; i++)
                {
                    string file = filesToReload[i];
                    if (File.Exists(file))
                    {
                        using (var sr = new StreamReader(file))
                        {
                            if (Path.GetExtension(file) == ".rtf")
                                (boxList[i] as RichTextBox).Rtf = sr.ReadToEnd();
                            else if (Path.GetExtension(file) == ".cs")
                                (boxList[i] as FastColoredTextBox).Text = File.ReadAllText(file);
                            else
                                (boxList[i] as RichTextBox).Text = sr.ReadToEnd();

                            isChanged[i] = false;
                            fileNames[i] = file;
                            tabControl1.TabPages[i].Text = Path.GetFileName(file);
                        }
                    }
                    if (i != filesToReload.Length - 1 && (Path.GetExtension(filesToReload[i + 1]) == ".rtf"
                        || Path.GetExtension(filesToReload[i + 1]) == ".txt"))
                        AddTab();
                    else
                        AddCSharpTab();
                }
                File.Delete(path);
            }
            catch
            {
                MessageBox.Show("Ошибка при загрузке файлов.");
            }
        }

        /// <summary>
        /// Установка цветовой схемы приложения при 
        /// перезапуске приложения.
        /// </summary>
        private void SetTheme()
        {
            try
            {
                (colorBack, colorFore) = themeColor switch
                {
                    "White" => (Color.White, Color.Black),
                    "Black" => (Color.Black, Color.White),
                    _ => (Color.White, Color.Black)
                };

                ChangeTheme(tabControl1);
                ChangeThemeItem(menuStrip1);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        /// <summary>
        /// Реализует возможность смены цветовой схемы, путём установки
        /// значений для переднего и заднего плана приложения.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void ColorTheme_Click(object sender, EventArgs e)
        {
            try
            {
                switch (themeColor)
                {
                    case "Black":
                        (colorBack, colorFore) = (Color.White, Color.Black);
                        themeColor = "White";
                        File.WriteAllText("ColorBase.txt", "White");
                        break;
                    case "White":
                        (colorBack, colorFore) = (Color.Black, Color.White);
                        themeColor = "Black";
                        File.WriteAllText("ColorBase.txt", "Black");
                        break;
                    default:
                        (colorBack, colorFore) = (Color.White, Color.Black);
                        themeColor = "White";
                        File.WriteAllText("ColorBase.txt", "White");
                        break;
                }

                ChangeTheme(tabControl1);
                ChangeThemeItem(menuStrip1);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Установка цветовой схемы.
        /// </summary>
        /// <param name="control">Элемент, для которого устанавливается
        /// цветовая схема.</param>
        private void ChangeTheme(Control control)
        {
            try
            {
                control.BackColor = colorBack;
                control.ForeColor = colorFore;
                Control[] controls = control.Controls.Cast<Control>().ToArray();
                for (int i = 0; i < controls.Length; i++)
                {
                    if (controls[i].Controls.Count > 0)
                        ChangeTheme(controls[i]);
                    controls[i].BackColor = colorBack;
                    Color colorText = controls[i] is RichTextBox ? (controls[i] as RichTextBox).SelectionColor : default;
                    controls[i].ForeColor = colorText == Color.White ||
                        colorText == Color.Black ? colorFore : colorText;
                    isChanged[i] = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Установка цветовой схемы для элементов MenuStrip.
        /// </summary>
        /// <param name="menuStrip">Элемент MenuStrip, для элементов которого происходит 
        /// установка цветовой схемы.</param>
        private void ChangeThemeItem(MenuStrip menuStrip)
        {
            try
            {
                menuStrip.BackColor = colorBack;
                menuStrip.ForeColor = colorBack == Color.Black ? Color.CadetBlue : Color.Black;

                foreach (ToolStripMenuItem item in menuStrip.Items)
                {
                    var dropDownList = item.DropDownItems;
                    for (int i = 0; i < dropDownList.Count; i++)
                    {
                        ToolStripMenuItem subMenu = dropDownList[i] as ToolStripMenuItem;

                        if (subMenu != null && subMenu.HasDropDownItems)
                        {
                            for (int j = 0; j < subMenu.DropDownItems.Count; j++)
                            {
                                subMenu.DropDownItems[j].BackColor = colorBack;
                                subMenu.DropDownItems[j].ForeColor = colorFore;
                            }
                        }
                        dropDownList[i].BackColor = colorBack;
                        dropDownList[i].ForeColor = colorFore;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Копирование текста.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Menu_Copy(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    if (rtb.SelectionLength > 0)
                        // Copy the selected text to the Clipboard.
                        rtb.Copy();
                }
                else
                {
                    FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                    if (fcb.SelectionLength > 0)
                        // Copy the selected text to the Clipboard.
                        fcb.Copy();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Вырезвет текст.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Menu_Cut(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    if (rtb.SelectionLength > 0)
                        rtb.Cut();
                }
                else
                {
                    FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                    if (fcb.SelectionLength > 0)
                    {
                        fcb.Cut();
                        fcb.SelectedText = "";
                    }
                        
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Вставляет текст.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Menu_Paste(object sender, EventArgs e)
        {
            try
            {
                if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
                {
                    // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                    // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                    int index = tabControl1.SelectedIndex;
                    if (boxList[index] is RichTextBox)
                    {
                        RichTextBox rtb = (boxList[index] as RichTextBox);
                        if (rtb.SelectionLength > 0)
                        {
                            if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example", MessageBoxButtons.YesNo) == DialogResult.No)
                                rtb.SelectionStart = rtb.SelectionStart + rtb.SelectionLength;
                        }
                        rtb.Paste();
                    }
                    else
                    {
                        FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                        if (fcb.SelectionLength > 0)
                        {
                            if (MessageBox.Show("Do you want to paste over current selection?", "Cut Example",
                                MessageBoxButtons.YesNo) == DialogResult.No)
                                fcb.SelectionStart = fcb.SelectionStart + fcb.SelectionLength;
                        }
                        fcb.Paste();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        /// <summary>
        /// Удаляет текст.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Menu_Delete(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    if (rtb.SelectedText != "")
                        rtb.SelectedText = "";
                }
                else
                {
                    FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                    
                    if (fcb.SelectedText != "")
                        fcb.SelectedText = "";                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        /// <summary>
        /// Вставляет текущее время и дату.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Menu_DateTime(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    rtb.AppendText(DateTime.Now.ToString());
                }
                else
                {
                    FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                    fcb.AppendText(DateTime.Now.ToString());
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }

        }

        /// <summary>
        ///  Отмена действия.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Menu_Undo(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    if (rtb.CanUndo == true)
                    {
                        rtb.Undo();
                        rtb.ClearUndo();
                    }
                }
                else
                {
                    FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                    fcb.Undo();
                    fcb.ClearUndo();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Задаёт формат всего текста или выделенного элемента.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void Text_Font(object sender, EventArgs e)
        {
            try
            {
                if (fontDialog1.ShowDialog() == DialogResult.Cancel)
                    return;
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    if (rtb.SelectedText == "")
                    {
                        rtb.Font = fontDialog1.Font;
                        rtb.ForeColor = fontDialog1.Color;
                    }
                    else
                    {
                        rtb.SelectionFont = fontDialog1.Font;
                        rtb.SelectionColor = fontDialog1.Color;
                    }
                }
                else
                {
                    RichTextBox fcb = (boxList[index] as RichTextBox);
                    if (fcb.SelectedText == "")
                    {
                        fcb.Font = fontDialog1.Font;
                        fcb.ForeColor = fontDialog1.Color;
                    }
                    else
                    {
                        fcb.SelectionFont = fontDialog1.Font;
                        fcb.SelectionColor = fontDialog1.Color;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Создаёт новый файл, при это проверяет, что если в данной вкалдке
        /// уже был открыт файл и он не сохранён, то предлагает польззователю сохранить его.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void CreateNewFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                var index = tabControl1.SelectedIndex;

                if (isChanged[index] == true)
                {
                    DialogResult closeStatus = MessageBox.Show($"Вы хотите сохранить изменения в файле" +
                        $" {Path.GetFileName(tabControl1.SelectedTab.Text)}?",
                        "NotePad+", MessageBoxButtons.YesNoCancel);
                    if (closeStatus == DialogResult.Yes)
                    {
                        SaveFile(fileNames[index], boxList[tabControl1.SelectedIndex]);
                    }
                    else if (closeStatus == DialogResult.Cancel)
                    {
                        return;
                    }
                }

                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (RichTextBox)boxList[index];
                    rtb.Text = "";
                    tabControl1.SelectedTab.Text = $"Безымянный_{index + 1}";
                    fileNames[index] = "";
                    openFileDialog1.FileName = "";
                    saveFileDialog1.FileName = "";
                    isChanged[index] = false;
                }
                else
                {
                    FastColoredTextBox fcb = (FastColoredTextBox)boxList[index];
                    fcb.Text = "";
                    tabControl1.SelectedTab.Text = $"Безымянный_{index + 1}";
                    fileNames[index] = "";
                    openFileDialog1.FileName = "";
                    saveFileDialog1.FileName = "";
                    isChanged[index] = false;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        /// <summary>
        /// Осуществляет выбор файла и метод для его открытия.
        /// При этом, если у пользователя открыта Текстовая вкадка, то вызывается метод для
        /// открытия текстового файла. Если открыта вкладка для чтения CS файла, то вызывается 
        /// метод для открытия CS файла.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void OpenFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                var index = tabControl1.SelectedIndex;

                try
                {
                    if (boxList[index] is RichTextBox)
                        OpenTextFile(index);
                    else
                        OpenCSharptFile(index);
                }
                catch
                {
                    MessageBox.Show("Ошибка при открытии файла! Повторите позднее.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Метод для открытия текстового файла.
        /// </summary>
        /// <param name="index">Индекс вкладки в массиве boxList. </param>
        private void OpenTextFile(int index)
        {
            try
            {
                openFileDialog1.Filter = "Text Files|*.txt|RichTextFormate|*.rtf";
                openFileDialog1.FileName = "";

                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        if (isChanged[index] == true)
                        {
                            DialogResult closeStatus = MessageBox.Show($"Вы хотите сохранить изменения в файле" +
                                $" {Path.GetFileName(tabControl1.SelectedTab.Text)}?",
                                "NotePad+", MessageBoxButtons.YesNoCancel);
                            if (closeStatus == DialogResult.Yes)
                            {
                                SaveFile(fileNames[index], (RichTextBox)boxList[tabControl1.SelectedIndex]);
                            }
                            else if (closeStatus == DialogResult.Cancel)
                            {
                                return;
                            }
                        }

                        RichTextBox rtb = (RichTextBox)boxList[index];

                        using (var sr = new StreamReader(openFileDialog1.FileName))
                        {
                            string fileName = openFileDialog1.FileName;
                            fileNames[index] = openFileDialog1.FileName;
                            if (Path.GetExtension(fileName) == ".rtf")
                                rtb.Rtf = sr.ReadToEnd();
                            else
                                rtb.Text = sr.ReadToEnd();
                            isChanged[index] = false;
                            tabControl1.SelectedTab.Text = Path.GetFileName(fileName);
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Ошибка при открытии текстового файла.");
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Метод для открытия CS файла.
        /// </summary>
        /// <param name="index">Индекс вкладки в массиве boxList. </param>
        private void OpenCSharptFile(int index)
        {
            
            openFileDialog1.Filter = "CSharp Files|*.cs";
            openFileDialog1.FileName = "";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (isChanged[index] == true)
                    {
                        DialogResult closeStatus = MessageBox.Show($"Вы хотите сохранить изменения в файле" +
                            $" {Path.GetFileName(tabControl1.SelectedTab.Text)}?",
                            "NotePad+", MessageBoxButtons.YesNoCancel);
                        if (closeStatus == DialogResult.Yes)
                        {
                            File.WriteAllText(fileNames[index], (boxList[index] as FastColoredTextBox).Text);
                        }
                        else if (closeStatus == DialogResult.Cancel)
                        {
                            return;
                        }
                    }

                    (boxList[index] as FastColoredTextBox).Text = File.ReadAllText(openFileDialog1.FileName);
                    (boxList[index] as FastColoredTextBox).Language = Language.CSharp;
                    fileNames[index] = openFileDialog1.FileName;
                    isChanged[index] = false;
                }
                catch
                {
                    MessageBox.Show("Ошибка при открытии CS-файла.");
                }
            }
        }

        /// <summary>
        /// Обработчик события изменения CS файла во вкладке для
        /// просмотрв CS файла.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fastColoredTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                isChanged[tabControl1.SelectedIndex] = true;
                e.ChangedRange.ClearStyle();


                e.ChangedRange.SetStyle(styleForCSFile[0], @"\b(class|struct|enum)\s+(?<range>[\w_]+?)\b");

                e.ChangedRange.SetStyle(styleForCSFile[2], @"//.*$", RegexOptions.Multiline);

                e.ChangedRange.SetStyle(styleForCSFile[1], @"\b(int|str|double|byte|long|sbyte|
                                                                char|ulong|desimal|object)\s+(?<range>[\w_]+?)\b");

                e.ChangedRange.SetStyle(styleForCSFile[3], @"\b(abstract|as|base|bool|break
                            |byte|case|catch|char|checked|class|const|
                            continue|decimal|default|delegate|do|double|
                            else|enum|event|explicit|extern|false|finally|fixed|
                            float|for|foreach|goto|if|implicit|in|int|interface|
                            internal|is|lock|long||namespace|new|null|object|operator|
                            out|override|params|private|protected|public|readonly|ref|return|
                            sbyte|sealed|short|sizeof|stackalloc||static|string|struct|switch|
                            this|throw|true|try|typeof|uint|ulong|unchecked|unsafe|ushort|using|
                            virtual|void|volatile|while)\b");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Преобразует текстовое представление цвета в объект
        /// класса TextStyle, устанавливая соответсвующий текс для 
        /// элемента CS файла.
        /// </summary>
        /// <param name="color">Текстовое представление файла.</param>
        /// <returns>Объект класса Style.</returns>
        private Style ConverColor(string color)
        {
            try
            {
                return _ = color switch
                {
                    "Green" => new TextStyle(Brushes.Green, null, FontStyle.Italic),
                    "Blue" => new TextStyle(Brushes.Blue, null, FontStyle.Italic),
                    "Red" => new TextStyle(Brushes.Red, null, FontStyle.Italic),
                    "Yellow" => new TextStyle(Brushes.Yellow, null, FontStyle.Italic),
                    "Orange" => new TextStyle(Brushes.Orange, null, FontStyle.Italic),
                    "Purple" => new TextStyle(Brushes.Purple, null, FontStyle.Italic),
                    "Pink" => new TextStyle(Brushes.Pink, null, FontStyle.Italic),
                    "Turquoise" => new TextStyle(Brushes.Turquoise, null, FontStyle.Italic),
                    _ => new TextStyle(Brushes.Black, null, FontStyle.Italic),
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return new TextStyle(Brushes.Black, null, FontStyle.Italic);   
            }
        }

        /// <summary>
        /// Переводит соответсвующие текстовое представление цвета
        /// с русского языка на английский.
        /// </summary>
        /// <param name="colorEng">Цвет на английском языке.</param>
        /// <returns></returns>
        private string SwitchLanguage(string colorEng)
        {
            try
            {
                return _ = colorEng switch
                {
                    "Зелёный" => "Green",
                    "Голубой" => "Blue",
                    "Красный" => "Red",
                    "Жёлтый" => "Yellow",
                    "Оранжевый" => "Orange",
                    "Фиолетовый" => "Purple",
                    "Розовый" => "Pink",
                    "Бирюзовый" => "Turquoise",
                    _ => "Black",
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return "Black";    
            }

        }

        /// <summary>
        /// Обработчик нажатия для выбора цвета имён классов в 
        /// CS файле.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        public void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                using (TextEditor_TestVersion.Form2 form2 = new TextEditor_TestVersion.Form2())
                {
                    if (form2.ShowDialog() == DialogResult.OK)
                       styleForCSFile[0] = ConverColor(SwitchLanguage(form2.SelectedText));
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик нажатия для выбора цвета имён переменных в 
        /// CS файле.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            try
            {
                using (TextEditor_TestVersion.Form2 form2 = new TextEditor_TestVersion.Form2())
                {
                    if (form2.ShowDialog() == DialogResult.OK)
                        styleForCSFile[1] = ConverColor(SwitchLanguage(form2.SelectedText));
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
        /// <summary>
        /// Обработчик нажатия для выбора цвета комментариев в 
        /// CS файле.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            try
            {
                using (TextEditor_TestVersion.Form2 form2 = new TextEditor_TestVersion.Form2())
                {
                    if (form2.ShowDialog() == DialogResult.OK)
                        styleForCSFile[2] = ConverColor(SwitchLanguage(form2.SelectedText));
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик нажатия для выбора ключевых слов в 
        /// CS файле.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            try
            {
                using (TextEditor_TestVersion.Form2 form2 = new TextEditor_TestVersion.Form2())
                {
                    if (form2.ShowDialog() == DialogResult.OK)
                        styleForCSFile[3] = ConverColor(SwitchLanguage(form2.SelectedText));
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик события, для создания новой CS вкладки/
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void CSharpFileTab(object sender, EventArgs e)
        {
            try
            {
                AddCSharpTab();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// Создание новой вкладки для просмотра CS файла.
        /// На вкладку добавляются кнопка для закрытия вкладки, 
        /// элемент объект класса FastColoredTextBox(). Устанавливаются обработчики событий
        /// для элементов вкладки.
        /// Данные блок выделен в отдельный метод, чтобы создавать вкладку не только
        /// при нажатии на соответствующую кнопку, но и при загрузке файлов при перегрузке приложения.
        /// </summary>
        private void AddCSharpTab()
        {
            TabPage newTabPage = new TabPage();
            // Устанавливает название вкладки.
            newTabPage.Text = "Новая вкладка";
            tabControl1.TabPages.Add(newTabPage);

            var ftb = new FastColoredTextBox();

            ftb.Dock = DockStyle.Fill;
            ftb.Multiline = true;
            isChanged.Add(false);
            ftb.TextChanged += fastColoredTextBox_TextChanged;
            ftb.ContextMenuStrip = contextMenuStrip1;
            ftb.Font = new Font("Courier New", 12, FontStyle.Regular);
            boxList.Add(ftb);
            newTabPage.Text = $"Безымянный_{tabControl1.TabCount}";
            fileNames.Add("");

            var button = new Button();
            button.Dock = DockStyle.Top;
            button.Height = 40;
            button.Text = "Закрыть вкладку.";
            button.Click += new EventHandler(DeleteTab_Click);


            newTabPage.Controls.Add(ftb);
            newTabPage.Controls.Add(button);

            ChangeTheme(newTabPage);
        }



        /// <summary>
        /// Обработчик события, для создания новой текстовой вкладки.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void AddTab_Click(object sender, EventArgs e)
        {
            AddTab();
        }

        /// <summary>
        /// Метод для создания текстовой вкладки.
        /// На вкладку добавляется кнопка для закрытия вкладки,
        /// объект класса RichTextBox. Устанавливаются обработчики событий
        /// для элементов вкладки.
        /// 
        /// Данные блок выделен в отдельный метод, чтобы создавать вкладку не только
        /// при нажатии на соответствующую кнопку, но и при загрузке файлов при перегрузке приложения.
        /// </summary>
        private void AddTab()
        {
            try
            {
                TabPage newTabPage = new TabPage();
                newTabPage.Text = "Новая вкладка";
                tabControl1.TabPages.Add(newTabPage);

                var rtb = new RichTextBox();
                rtb.Dock = DockStyle.Fill;
                rtb.Multiline = true;
                isChanged.Add(false);
                rtb.TextChanged += new EventHandler(richTextBox_TextChanged);
                rtb.ContextMenuStrip = contextMenuStrip1;
                rtb.SelectionFont = new Font("Segoe UI", 12, FontStyle.Regular);
                boxList.Add(rtb);
                newTabPage.Text = $"Безымянный_{tabControl1.TabCount}";
                fileNames.Add("");

                var button = new Button();
                button.Dock = DockStyle.Top;
                button.Height = 40;
                button.Text = "Закрыть вкладку.";
                button.Click += new EventHandler(DeleteTab_Click);


                newTabPage.Controls.Add(rtb);
                newTabPage.Controls.Add(button);

                ChangeTheme(newTabPage);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик события для закрытия вкладки.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void DeleteTab_Click(object sender, EventArgs e)
        {
            try
            {
                int index = tabControl1.SelectedIndex;
                DeleteTab(index);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Удаление соответсвующей вкладки по индексу.
        /// </summary>
        /// <param name="index">Индекс вкладки в массиве boxList.</param>
        private void DeleteTab(int index)
        {
            try
            {
                DialogResult closeStatus = default;
                if (isChanged[index] == true)
                {
                    closeStatus = MessageBox.Show($"Вы хотите сохранить изменения в файле" +
                        $" {Path.GetFileName(tabControl1.SelectedTab.Text)}?",
                        "NotePad+", MessageBoxButtons.YesNoCancel);
                    if (closeStatus == DialogResult.Yes)
                    {


                        SaveFile(fileNames[index], (RichTextBox)boxList[index]);

                    }
                }

                if (closeStatus != DialogResult.Cancel)
                {
                    boxList.Remove(boxList[index]);
                    isChanged.Remove(isChanged[index]);
                    tabControl1.TabPages.Remove(tabControl1.SelectedTab);
                    fileNames.Remove(fileNames[index]);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик события для сохранения файла, при наличии имени файла.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void SaveFile_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                SaveFile(fileNames[index], boxList[index]);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        /// <summary>
        /// Обработчик для сохранения файла, при отсутсвии имени файла.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void SaveFileAs_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                SaveFile("", boxList[index]);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Метод для сохранения файла.
        /// </summary>
        /// <param name="fileName">Имя файла.</param>
        /// <param name="box">Вкладка, на которой содержится данный файл.</param>
        private void SaveFile(string fileName, object box)
        {
            try
            {

                saveFileDialog1.Filter = "RichTextFormate|*.rtf|Text Files|*.txt|CS Files|*.cs|All Files|*.*";
                if (fileName == "")
                {
                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        fileName = saveFileDialog1.FileName;
                    }
                }

                try
                {
                    if (Path.GetExtension(fileName) == ".rtf")
                    {
                        (box as RichTextBox).SaveFile(fileName, RichTextBoxStreamType.RichText);
                    }    
                    else if (Path.GetExtension(fileName) == ".cs")
                    {
                        if ((box as FastColoredTextBox).Text is not null)
                            File.WriteAllText(fileName, (box as FastColoredTextBox).Text);
                    }   
                    else if (Path.GetExtension(fileName) == ".txt")
                    {
                        if ((box as RichTextBox).Text is not null)
                            File.WriteAllText(fileName, (box as RichTextBox).Text);
                    }                       
                }
                catch (NullReferenceException)
                {
                    MessageBox.Show("Ошибка при сохранении файла! Повторите позднее.");
                }
                
                if (fileName != "")
                {
                    fileNames[tabControl1.SelectedIndex] = fileName;
                    tabControl1.SelectedTab.Text = Path.GetFileName(fileName);
                }
                isChanged[tabControl1.SelectedIndex] = false;
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка при сохранении файла! Повторите позднее.");
            }

        }

        /// <summary>
        /// Обработчик события для сохранения всех открытых файлов.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void SaveAllFiles_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (var box in boxList)
                {
                    int index = tabControl1.SelectedIndex;
                    SaveFile(fileNames[index], box);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        /// <summary>
        /// Обработчик события для тиков таймера.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < fileNames.Count; i++)
                {
                    if (File.Exists(fileNames[i]))
                    {
                        if (Path.GetExtension(fileNames[i]) == ".rtf")
                            (boxList[i] as RichTextBox).SaveFile(fileNames[i], RichTextBoxStreamType.RichText);
                        else if ((Path.GetExtension(fileNames[i]) == ".cs"))
                            File.WriteAllText(fileNames[i], (boxList[i] as FastColoredTextBox).Text);
                        else if ((Path.GetExtension(fileNames[i]) == ".txt"))
                            File.WriteAllText(fileNames[i], (boxList[i] as RichTextBox).Text);
                        isChanged[i] = false;
                    }

                }
            }
            catch
            {
                MessageBox.Show("Ошибка при автоматическом сохранении.");
            }
        }
    
        /// <summary>
        /// Обработчик события для установки интервала тиков таймера.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SetAutoSaveTimeSpanTab_Click(object sender, EventArgs e)
            => timer1.Interval = int.Parse(sender.ToString().Split(" ")[0]) * 1000;

        /// <summary>
        /// Обработчик события для выделения текста.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void SelectAllText_Click(object sender, EventArgs e)
        {
            try
            {
                // Получаем индекс выбранной вкладки, он совпадает с индексом выбранного RichTextBox.
                // Делаем это для того, чтобы работать с файлом в правильной вкладке.
                int index = tabControl1.SelectedIndex;
                if (boxList[index] is RichTextBox)
                {
                    RichTextBox rtb = (boxList[index] as RichTextBox);
                    rtb.SelectAll();
                }
                else
                {
                    FastColoredTextBox fcb = (boxList[index] as FastColoredTextBox);
                    fcb.SelectAll();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик события для создания новой формы.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void NewForm(object sender, EventArgs e)
        {
            try
            {
                if (OpenNewForm != null) OpenNewForm(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обрабочик события изменения содержимого текстового файла.
        /// </summary>
        /// <param name="sender">Издатель.</param>
        /// <param name="e">Информация о событии.</param>
        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                isChanged[tabControl1.SelectedIndex] = true;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        /// <summary>
        /// Обработчик события при выходе из приложения.
        /// Только при таком способе закрытия приложения возможна закрузка ранее открытых файлов при перезвгрузке приложения.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AppExit_Click(object sender, EventArgs e)
        {
            try
            {
                var sb = new StringBuilder("");
                foreach (var file in fileNames)
                {
                    MessageBox.Show(file);
                    if (file!="")
                        sb.Append(file + Environment.NewLine);
                }
                    
                // Name - поле класса Form.
                if (sb.Length>0)
                    File.WriteAllText($@"{Environment.CurrentDirectory}\FilesBase\{Name}.txt", sb.ToString());
                Application.Exit();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }


        /// <summary>
        /// Обработчик события закрытия формы.
        /// 
        /// При наличии несохранённых файлов, пользователю предлагается сохранить их.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (isChanged.Any(save => save == true))
                {
                    for (int i = 0; i < boxList.Count; i++)
                    {
                        if (isChanged[i] == true)
                        {
                            string name = fileNames[i] != "" ? fileNames[i] : $"Безымянный_{i + 1}";

                            var closeStatus = MessageBox.Show($"Вы хотите сохранить изменения в файле" +
                                $" {Path.GetFileName(name)}?",
                                "NotePad+", MessageBoxButtons.YesNoCancel);
                            if (closeStatus == DialogResult.Yes)
                            {
                                SaveFile(fileNames[tabControl1.SelectedIndex],
                                    boxList[tabControl1.SelectedIndex]);

                                return;
                            }
                            else if (closeStatus == DialogResult.Cancel)
                            {
                                // Отмена закрытия формы.
                                e.Cancel = true;
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
    }
}

