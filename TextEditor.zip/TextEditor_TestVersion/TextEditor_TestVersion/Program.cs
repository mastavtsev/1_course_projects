using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextEditor
{
    public class CustomContext : ApplicationContext
    {
        private readonly List<Form1> openForms = new List<Form1>();

        public CustomContext()
        {
            CreateForm();
        }

        private void CreateForm()
        {
            Form1 form = new Form1();
            form.Name = $"form{openForms.Count}";
            form.OpenNewForm += (sender, args) => CreateForm();
            form.Closed += (sender, args) => FormClosed(sender as Form1);
            openForms.Add(form);
            form.Show();
        }

        private void FormClosed(Form1 form)
        {
            openForms.Remove(form);
            if (openForms.Count == 0)
            {
                ExitThread();
            }
        }
    }

    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CustomContext());

        }
    }
}
