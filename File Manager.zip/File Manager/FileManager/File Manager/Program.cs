﻿using System;

/// <summary>
/// Класс для вывода текстовой информации в консоль.
/// </summary>
class TextMessage
{
    /// <summary>
    /// Содержит текстовую чать главного меню с 
    /// доступными операциями.
    /// </summary>
    /// <returns>Тектовая часть главного меню.</returns>
    public string[] SelectMenu()
    {
        string[] options =  { "Просмотр списка дисков компьютера и выбор диска.",
                                    "Переход в другую директорию (выбор папки).",
                                    "Просмотр списка файлов в директории.",
                                    "Вывод содержимого текстового файла в консоль.",
                                    "Копирование файла.",
                                    "Копирование файлов по заданной маске.",
                                    "Перемещение файла в другую директорию.",
                                    "Удаление файла.",
                                    "Создание текстового файла.",
                                    "Объединение и вывод текстовых файлов.",
                                    "Вывод всех файлов в директории по заданной маске.",
                                    "Автодополнение названия файла.",
                                    "Сброс значения диска и папки.", "Выход."};
        return options;
    }

    /// <summary>
    /// Создаёт текстовое сообщение о текущем расположении пользователя
    /// в файловой системе.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    /// <returns>Текствое сообщение о расположении.</returns>
    public string CurrentSpace(string disk, string folder)
    {
        string space = $"Вы сейчас находитесь на диске: {disk} В папке: {folder.Substring(3)}";

        return space;
    }
}

/// <summary>
/// Основной класс программы, вызывающий методы для осуществления операций.
/// </summary>
internal partial class Program
{
    /// <summary>
    /// Главное меню.
    /// В данном методе пользователь выбирает операцию для осуществления.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Имя текущей директории.</param>
    /// <returns>Логическое значение true или false, которое служит индикатором для
    /// повторения работы программы.</returns>
    static bool SelectOperation(ref string disk, ref string folder)
    {
        TextMessage tm = new();
        int optionNum;
        string message = tm.CurrentSpace(disk, folder) + Environment.NewLine;
        optionNum = SelectMenu(message + Environment.NewLine + "ВЫБОР ОПЕРАЦИИ", tm.SelectMenu()) + 1;
        bool f = false;

        switch (optionNum)
        {
            case 1:
                SelectDisk(ref disk, ref folder);
                break;
            case 2:
                SelectDirectory(ref disk, ref folder);
                break;
            case 3:
                CheckDirectoryFiles(ref disk, ref folder);
                break;
            case 4:
                PrintTextFile(ref disk, ref folder);
                break;
            case 5:
                CopyFile(ref disk, ref folder);
                break;
            case 6:
                CopyFilesPattern(ref disk, ref folder);
                break;
            case 7:
                MoveFile(ref disk, ref folder);
                break;
            case 8:
                DeleteFile(ref disk, ref folder);
                break;
            case 9:
                MakeFile(ref disk, ref folder);
                break;
            case 10:
                ConcatenationFiles(ref disk, ref folder);
                break;
            case 11:
                CheckFilesPattern(ref disk, ref folder);
                break;
            case 12:
                Autocompletion(ref disk, ref folder);
                break;
            case 13:
                disk = "None";
                folder = "   None";
                break;
            case 14:
                f = true;
                break;
            default:
                Console.WriteLine("Ошибка! Повторите выбор.");
                SelectOperation(ref disk, ref folder);
                break;
        }
        return f;
    }

    /// <summary>
    /// Осуществляет прекращение работы программы.
    /// </summary>
    static void Exit()
    {
        Console.WriteLine("До свидания! Нажмите любую клавишу для завершения работы программы.");
        Console.ReadKey();
        Environment.Exit(0);
    }

    /// <summary>
    /// Осуществляет вызов метода для выбора операции SelectOperation().
    /// Реализует повтор решения.
    /// </summary>
    static void Main()
    {
        string disk = "None";
        string folder = "   None";
        bool exit;
        do
        {
            exit = SelectOperation(ref disk, ref folder);
        } while (!exit);

        Exit();
    }
}
