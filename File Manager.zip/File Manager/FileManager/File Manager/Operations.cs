﻿using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

/// <summary>
/// Класс, содержащий методы для работы программы.
/// </summary>
internal partial class Program
{
    /// <summary>
    /// Осуществляет выбор диска, то есть присвает значение переменной disk.
    /// При этом приводит переменную folder в дефолтной значение.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void SelectDisk(ref string disk, ref string folder)
    {
        folder = "   None";
        DriveInfo[] allDrives = DriveInfo.GetDrives();
        //Строковый массив информации о дисках.
        var strInformDrivers = new string[allDrives.Length];
        for (int i = 0; i < allDrives.Length; i++)
        {
            strInformDrivers[i] = $"Имя диска {allDrives[i].Name}; Доступное пространство: {allDrives[i].TotalFreeSpace / (1024 * 1024)} Мб;" +
                Environment.NewLine +
                $"     Всего размер диска {allDrives[i].TotalSize / (1024 * 1024)} Мб";
        }

        disk = allDrives[SelectMenu("ВЫБОР ДИСКА:", strInformDrivers)].Name;
    }

    /// <summary>
    /// Метод, позволяющий как просто просмотреть файлы в директории, так и 
    /// выбрать одни из них. Режим работы зависит от параметра index. 
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    /// <param name="index">Режим работы метода.
    /// index = 0 - Первый режим работы ( просмотр файлов ).
    /// index = 1 - Второй режим работы ( просмотр файлов с дальнейшим выбором).
    /// index = 2 - Третий режим работы ( просмотр файлов с дальнейшим выбором и 
    /// подсчётом количества выбранных фалов).</param>
    /// <param name="pattern">Маска, для поиска файлов. Используется при
    /// втором режиме работы. Значением по умолчанию является пустая строка.</param>
    /// <param name="count">Счётчик, использующийся при третьем режиме работы. </param>
    /// <returns>Путь к файлу, если осуществляется 2 или 3 режим работы.
    /// Пустая строка, если 1 режим работы.</returns>
    private static string CheckDirectoryFiles(ref string disk, ref string folder, int index = 0, string pattern = "",
            int count = 0)
    {
        if (folder == "   None" && disk != "None")
            folder = disk;

        string filePath = "";
        string message = "";
        try
        {
            if (index == 0)
            {
                string allFiles = string.Join(Environment.NewLine, Directory.GetFiles(folder));
                Show("СПИСОК ФАЙЛОВ: ", allFiles);
            }
            else
            {
                if (index == 1)
                    if (pattern.Length > 0)
                        message = "Поддерживается чтение только файлов с расширением .txt"
                            + Environment.NewLine;

                if (index == 2)
                    message = $"Выбор файла №{count}" + Environment.NewLine;

                string[] allFiles = Directory.GetFiles(folder, pattern);
                filePath = allFiles[SelectMenu(message + "СПИСОК ФАЙЛОВ: ", allFiles)];
            }
        }
        catch (DirectoryNotFoundException)
        {
            string path;
            int intF = Continue("Ошибка! Не произведён ввод пути!", "папке с файлами", out path);
            switch (intF)
            {
                case 0:
                    disk = path.Substring(0, 3);
                    folder = path;
                    filePath = CheckDirectoryFiles(ref disk, ref folder, index, pattern);
                    break;
                case 1:
                    Exit();
                    break;
                case 2:
                    return "";
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        return filePath;
    }

    /// <summary>
    /// Осуществляет вывод в консоль текстового файла, с учётом кодировки.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void PrintTextFile(ref string disk, ref string folder)
    {
        string filePath = CheckDirectoryFiles(ref disk, ref folder, 1, "*.txt");
        if (filePath == "") { return; }
        try
        {
            var coding = Encoding.GetEncoding(СhooseEncoding("вывести"));
            StreamReader fileText = new StreamReader(filePath, coding, false);
            Show("ПРОСМОТР СОДЕРЖИМОГО ФАЙЛА", fileText.ReadToEnd());
        }
        catch (ArgumentException)
        {

            Console.WriteLine("Не указан путь к файлу. Повторите выбор директории." +
                Environment.NewLine +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (DirectoryNotFoundException)
        {
            Console.WriteLine("Директория с файлами не найдена. " +
                Environment.NewLine +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Осуществляет выбор кодировки.
    /// </summary>
    /// <param name="message">Информационное сообщение.</param>
    /// <returns>Номер кодировки</returns>
    private static int СhooseEncoding(string message)
    {
        //Номер, соответствующий кодировке UTF-8;
        var coding = 65001;
        ConsoleKeyInfo info;
        var codingsStringArr = new string[] { "Западноевропейская (ISO)", "ASCII (США)",
                                        "Юникод (UTF-32)", "Юникод(UTF-16)" };
        var codePage = new int[] { 28591, 20127, 12000, 1200 };

        Console.WriteLine("Кодировкой по умолчанию является UTF-8.");
        do
        {
            Console.WriteLine($"Если вы хотите {message} файл в другой кодировке, нажмите Enter." +
                Environment.NewLine +
                "Если вы не хотите менять кодировку, нажмите пробел");
            info = Console.ReadKey(true);
        } while (info.Key != ConsoleKey.Enter && info.Key != ConsoleKey.Spacebar);
        Console.Clear();
        if (info.Key == ConsoleKey.Enter)
        {
            Console.Clear();
            coding = codePage[SelectMenu("ВЫБОР КОДИРОВКИ", codingsStringArr)];
        }

        return coding;
    }

    /// <summary>
    /// Осуществляет копирование файла.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void CopyFile(ref string disk, ref string folder)
    {
        string filePath = CheckDirectoryFiles(ref disk, ref folder, 1, "");

        if (filePath == "") { return; }
        try
        {
            FileInfo fi1 = new FileInfo(filePath);
            string fileName = Regex.Match(filePath, @"\\.[^\\]*(?=\.)").Value;
            string fileExtension = Path.GetExtension(filePath);
            string[] options = { "Копировать в текущую директорию", "Выбрать другую директорию для копирования" };
            int tupeOfInput = SelectMenu("Выберите способ ввода нового расположения файла.", options);
            Console.Clear();
            switch (tupeOfInput)
            {
                case 0:
                    fi1.CopyTo(folder + fileName + $"({FilesCount(folder, fileName, fileExtension)})" + fileExtension);
                    break;
                case 1:
                    Console.WriteLine("Введите абсолютный путь новой директории, включая название файла и " +
                                      "его расширение:");
                    string newPath = "";
                    newPath = Console.ReadLine();
                    fi1.CopyTo(newPath + fileName + $"({FilesCount(newPath, fileName, fileExtension)})" + fileExtension);
                    Console.Clear();
                    break;
            }
        }
        catch (DirectoryNotFoundException)
        {
            Console.WriteLine("Директория, в которую вы хотите скопировать файл, не найдена! " +
                Environment.NewLine +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (ArgumentException)
        {
            Console.WriteLine("Не введён абсолютный путь к файлу! " +
                Environment.NewLine +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (IOException)
        {
            Console.WriteLine("Синтаксическая ошибка в имени файла или имени папки. Повторите попытку. " +
                Environment.NewLine +
                "Нажмите Enter для повторного выбора файла.");
            Console.ReadLine();
            Console.Clear();
            CopyFile(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Подсчитывает количество файлов в директории со схожим именем. 
    /// </summary>
    /// <param name="folder">Директория для подсчёта схожих файлов.</param>
    /// <param name="fileName">Имя файла.</param>
    /// <param name="pattern">Расширение файла.</param>
    /// <returns>Количество файлов в директории со схожим именем</returns>
    private static int FilesCount(string folder, string fileName, string pattern)
    {
        string files = string.Join(Environment.NewLine, Directory.GetFiles(folder));
        string bkt = @"\(\d\)";
        MatchCollection result;
        var sb = new StringBuilder();
        foreach (char x in fileName)
        {
            // Экранирует все вхлждения скобок в имя файла.
            if (x == '(' || x == ')')
                sb.Append(@"\");
            // Заменяет все вхождения цифр в имя файла на \d .
            if ('0' <= x && x <= '9')
                sb.Append(@"\d");
            else
                sb.Append(x);
        }
        fileName = sb.ToString();
        Regex re = new Regex(".*" + fileName.Substring(1) + bkt + pattern);
        result = re.Matches(files);
        return result.Count + 1;
    }

    /// <summary>
    /// Перемещяет файл в указанную директорию.
    /// Если файл в указанной директории уже существует, то метод отлавливает эту ошибку
    /// и возвращает пользователя в главное меню.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void MoveFile(ref string disk, ref string folder)
    {
        string oldPath = CheckDirectoryFiles(ref disk, ref folder, 1, "");
        if (oldPath == "") { return; }
        try
        {
            string[] options = { "Выбрать расположение вручную", "Ввести абсолютный путь к директории" };
            int tupeOfInput = SelectMenu("Выберите способ ввода нового расположения файла.", options);
            switch (tupeOfInput)
            {
                case 0:
                    string newDisk = "";
                    string newFolder = "";
                    string fileName = Regex.Match(oldPath, @"\\.[^\\]*(?=\.)").Value;
                    string fileExtension = Regex.Match(oldPath, @"\..*").Value;
                    SelectDisk(ref newDisk, ref newFolder);
                    SelectDirectory(ref newDisk, ref newFolder);
                    if (newFolder == oldPath)
                    {
                        Console.WriteLine("Вы не можете переместить файл в ту же директорию. " + Environment.NewLine +
                            "Нажмите Enter для повторного выбора файла.");
                        MoveFile(ref disk, ref folder);
                    }
                    newFolder = fileName + $"({FilesCount(newFolder, fileName, fileExtension)})" + fileExtension;
                    File.Move(oldPath, newFolder);
                    break;
                case 1:
                    string newPath;
                    do
                    {
                        Console.WriteLine("Введите абсолютный путь новой директории, включая название файла и " +
                                              "его расширение: ");
                        newPath = Console.ReadLine();
                    } while (!Directory.Exists(newPath));
                    File.Move(oldPath, newPath);
                    break;
            }
        }
        catch (DirectoryNotFoundException)
        {
            Console.WriteLine("Директория, в которую вы хотите перенести файл, не найдена!" +
                Environment.NewLine +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (IOException)
        {
            Console.WriteLine("Невозможно создать файл, так как он уже существует!" +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Удаляет файл из выбранной директории.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void DeleteFile(ref string disk, ref string folder)
    {
        try
        {
            string deleteFilePath = CheckDirectoryFiles(ref disk, ref folder, 1, "");
            if (deleteFilePath == "") { return; }
            File.Delete(deleteFilePath);
            if (!File.Exists(deleteFilePath))
                Console.WriteLine("Файл успешно удалён.");
            else
                Console.WriteLine("Файл не найден. Повторите попытку.");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
        }
        catch (UnauthorizedAccessException)
        {

            Console.WriteLine("Доступ к файлу запрещён." + Environment.NewLine +
                "Для возвращения в главное меню нажмите любую кнопку.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Создаёт текстовый файл в выбранной директории.
    /// Если файл со схожим именем уже существует, то метод даёт возможность переписать
    /// этот файл или создать новый.
    /// Также вызывает вспомогательный метод для записи текста в файл в выбранной кодировке.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void MakeFile(ref string disk, ref string folder)
    {
        string fileName = "";
        string path = "";
        MatchCollection fileNameMistakes;
        try
        {
            string[] options = { "Создать файл в текущей директории", "Ввести абсолютный путь к директории" };
            int tupeOfInput = SelectMenu("Выберите способ получения расположения нового файла.", options);
            switch (tupeOfInput)
            {
                case 0:
                    if (!Directory.Exists(folder))
                    {
                        SelectDisk(ref disk, ref folder);
                        SelectDirectory(ref disk, ref folder);
                    }
                    do
                    {
                        Console.WriteLine("Введите имя файла: ");
                        fileName = Console.ReadLine();
                        fileNameMistakes = Regex.Matches(fileName, @"[/\\:*?<>|]");
                    } while (fileNameMistakes.Count != 0);
                    Console.Clear();
                    path = folder + "\\" + fileName + ".txt";
                    break;
                case 1:
                    path = "";
                    break;
            }
            if (File.Exists(path))
            {
                ConsoleKeyInfo info;
                do
                {
                    Console.WriteLine("Файл с таким именем уже существует!" + Environment.NewLine +
                    "Если вы хотите его переписать, нажмите пробел." + Environment.NewLine +
                    "Если бы хотите создать новый файл, нажмите Enter.");
                    info = Console.ReadKey(true);
                } while (info.Key != ConsoleKey.Enter && info.Key != ConsoleKey.Spacebar);
                if (info.Key == ConsoleKey.Enter)
                {
                    string fileNameNew = Regex.Match(path, @"(?<=\\).[^\\]*(?=\.)").Value + $"({FilesCount(folder, fileName, ".txt")})";
                    var sb = new StringBuilder(path);
                    sb.Replace(fileName, fileNameNew);
                    path = sb.ToString();
                }
                Console.Clear();
            }
            FileReadWriteText(path);
        }
        catch (DirectoryNotFoundException)
        {
            Console.WriteLine("Директория, в которой вы хотите создать файл не найдена!" +
                "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (IOException)
        {
            Console.WriteLine("Невозможно создать файл с таким названием, так как он уже существует!" +
                               Environment.NewLine +
                              "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Считывает и запысывает в файл текст, с учётом выбранной кодировки.
    /// </summary>
    /// <param name="path">Путь к файлу на запись.</param>
    private static void FileReadWriteText(string path)
    {
        Console.WriteLine("Введите текст, который вы хотите записать в файл." +
                    Environment.NewLine + "Окончание получения текста происходит при вводе пустой строки.");
        string fileInput = "";
        string input;
        Console.WriteLine();
        while ((input = Console.ReadLine()) != "")
        {
            fileInput += input + Environment.NewLine;
        }
        var coding = Encoding.GetEncoding(СhooseEncoding("ввести"));
        File.WriteAllText(path, fileInput, coding);
        Console.Clear();
    }


    /// <summary>
    /// Считывает желаемое количество файлов для объединения. 
    /// Создаёт массив с путями к выбранным файлам и 
    /// вызывает вспомогательный метод WriteConcatText() 
    /// для вывода содержимого данных файлов.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void ConcatenationFiles(ref string disk, ref string folder)
    {
        int numOfFiles;
        var filesPaths = new List<string>();
        do
        {
            Console.WriteLine("Введите количество файлов для объединения, допустимо от 2 до 10: ");
        } while (!int.TryParse(Console.ReadLine(), out numOfFiles) || numOfFiles < 2 || numOfFiles > 10);
        Console.Clear();
        string[] options = { "Выбрать файлы из текущей директории", "Ввести абсолютный пути к файлам" };
        int tupeOfInput = SelectMenu("Выберите способ получения расположения файла.", options);
        switch (tupeOfInput)
        {
            case 0:
                if (!Directory.Exists(folder))
                {
                    SelectDisk(ref disk, ref folder);
                    SelectDirectory(ref disk, ref folder);
                }
                for (int i = 1; i <= numOfFiles; i++)
                    filesPaths.Add(CheckDirectoryFiles(ref disk, ref folder, 2, "*.txt", i));
                break;
            case 1:
                string path;
                for (int i = 1; i <= numOfFiles; i++)
                {
                    do
                    {
                        Console.WriteLine($"Введите путь к файлу № {i}");
                    } while (!File.Exists(path = Console.ReadLine()));
                    filesPaths.Add(path);
                }
                break;
            default: break;
        }
        string text = WriteConcatText(filesPaths);
        WriteConcatTextToFile(filesPaths[0], text);
    }

    private static void WriteConcatTextToFile(string firstFilePath, string Text)
    {
        string folderNew = Path.GetDirectoryName(firstFilePath);
        string pathNew = folderNew + "\\concatResult" + $"({FilesCount(folderNew, "\\concatResult", ".txt")})" + ".txt";
        Console.WriteLine("Результат объединения также записан в кодировке UTF-8 в файл, который находится"
            + Environment.NewLine + "в той же папке, что и первый из объединяемых.");
        File.WriteAllText(pathNew, Text);
        Console.WriteLine("Нажмите любую клавишу для продолжения.");
        Console.ReadKey(true);
        Console.Clear();
    }

    /// <summary>
    /// Объединяет файлы в одну строку, делая отсуп после окончания очередного файла.
    /// Выводит содержимое файлов в консоль.
    /// </summary>
    /// <param name="paths"></param>
    /// <returns>Строковое представление результата объединения.</returns>
    private static string WriteConcatText(List<string> paths)
    {
        var concatResult = new StringBuilder();
        foreach (string path in paths)
            concatResult.Append(File.ReadAllText(path) + Environment.NewLine + Environment.NewLine);
        Show("РЕЗУЛЬТАТ ОБЪЕДИНЕНИЯ ФАЙЛОВ: ", concatResult.ToString());
        return concatResult.ToString();
    }

    /// <summary>
    /// Выполняет вывод всех файлов по заданной маске. 
    /// Поиск файлов осуществляется либо только в текущей директории, либо
    /// в текущей директории и её поддиректориях, в зависимости от выбора пользователя.
    /// Вызываются вспомогательный методы для парметра поиска pattern - SelectPattern,
    /// для определения необходимости поиска в поддиректориях info - SelectSubdirectory().
    /// </summary>
    /// <param name="disk"></param>
    /// <param name="folder"></param>
    private static void CheckFilesPattern(ref string disk, ref string folder)
    {
        ConsoleKeyInfo info;
        try
        {
            if (!Directory.Exists(folder))
                throw new DirectoryNotFoundException();
            string files;
            string pattern;
            pattern = SelectPattern(ref disk, ref folder);
            Console.WriteLine();
            info = SelectSubdirectory();
            if (info.Key == ConsoleKey.Enter)
                files = String.Join(Environment.NewLine, Directory.GetFiles(folder, pattern));
            else
                files = String.Join(Environment.NewLine, Directory.GetFiles(folder, pattern, SearchOption.AllDirectories));
            Console.Clear();
            if (files.Length > 0)
                Show("СПИСОК ФАЙЛОВ: ", files);
            else
                Show("ОШИБКА!", "Файлов по заданной маске не найдено.");
        }
        catch (DirectoryNotFoundException)
        {
            string path;
            int intF = Continue("Ошибка! Не произведён ввод пути!", "папке с файлами", out path);
            switch (intF)
            {
                case 0:
                    disk = path.Substring(0, 3);
                    folder = path;
                    CheckFilesPattern(ref disk, ref folder);
                    break;
                case 1:
                    Exit();
                    break;
                case 2:
                    return;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Уточняет у пользователя необходимость поиска файлов
    /// в поддиректориях.
    /// </summary>
    /// <returns>Переменную типа ConsoleKeyInfo соответвующую типу поиска в методе CheckFilesPattern. </returns>
    private static ConsoleKeyInfo SelectSubdirectory()
    {
        ConsoleKeyInfo info;
        do
        {
            Console.WriteLine("Для вывода файлов в текущей директории нажмите - Enter."
                + Environment.NewLine +
                "Для вывода всех файлов в текущей директории и всех её поддиректориях нажмите - пробел.");
            info = Console.ReadKey(true);
        } while (info.Key != ConsoleKey.Enter && info.Key != ConsoleKey.Spacebar);
        return info;
    }

    /// <summary>
    /// Осуществляет получение параметра для поиска файла.
    /// Параметры disk и folder передаются в данный метод, для того чтобы 
    /// в случае, если возникает исключение при вводе парметра поиска, пользователь
    /// мог вернуться в главное меню.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    /// <returns>Значение параметра поиска файла.</returns>
    private static string SelectPattern(ref string disk, ref string folder)
    {
        string pattern = "";
        try
        {
            MatchCollection patternNameMistakes;
            do
            {
                Console.WriteLine("Маска может содержать сочетания допустимого литерального пути" +
                    Environment.NewLine +
                    "и подстановочного символа (* и ?), но не поддерживает регулярные выражения." + Environment.NewLine +
                    @"В маске недопустимо наличие символов:  /\:<>| ");
                Console.WriteLine("Введите маску для поиска файла.");
                pattern = Console.ReadLine();
                patternNameMistakes = Regex.Matches(pattern, @"[/\\:<>|]");
            } while (pattern.Length == 0 || patternNameMistakes.Count != 0);

        }
        catch (RegexParseException)
        {
            Console.WriteLine("Недопустимая маска для поиска!" + Environment.NewLine +
                              "Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        return pattern;
    }

    /// <summary>
    /// Копирует все файлы из директории и всех её поддиректорий по маске
    /// в другую директорию, причём, если директория, в которую происходит
    /// копирование, не существует – она создаётся.
    /// При наличии файла с таким же названием в директории пользователю
    /// даётся возможность замены файла или оставление старого, при помощи метода ReplaceOrLeaveFile().
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void CopyFilesPattern(ref string disk, ref string folder)
    {
        string pattern;
        string fileName;

        try
        {
            if (!Directory.Exists(folder))
                throw new DirectoryNotFoundException();
            pattern = SelectPattern(ref disk, ref folder);
            Console.Clear();
            string[] filesPaths = Directory.GetFiles(folder, pattern, SearchOption.AllDirectories);
            FileInfo fi1;
            string newPath = ChooseTypePathInput();
            if (!Directory.Exists(newPath))
                Directory.CreateDirectory(newPath);
            foreach (string file in filesPaths)
            {
                fileName = Path.GetFileName(file);
                fi1 = new FileInfo(file);
                if (File.Exists(newPath + "\\" + fileName))
                    if (ReplaceOrLeaveFile(fileName))
                        continue;
                    else
                        File.Delete(newPath + "\\" + fileName);
                fi1.CopyTo(newPath + "\\" + fileName);
            }
            Console.WriteLine("Файлы успешно скопированы. Нажмите Enter для продолжения.");
            Console.ReadLine();
            Console.Clear();
        }
        catch (DirectoryNotFoundException)
        {
            string path;
            int intF = Continue("Ошибка! Не произведён ввод пути!", "папке с файлами", out path);
            switch (intF)
            {
                case 0:
                    disk = path.Substring(0, 3);
                    folder = path;
                    CopyFilesPattern(ref disk, ref folder);
                    break;
                case 1:
                    Exit();
                    break;
                case 2:
                    return;
            }
            Console.Clear();
        }
        catch (ArgumentException)
        {
            Console.WriteLine("Некорректный путь к папке!" + Environment.NewLine +
                "Для возвращения в главное меню нажмите Enter.");
            Console.ReadLine();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("Доступ к папке запрещён." + Environment.NewLine +
                "Для возвращения в главное меню нажмите Enter.");
            Console.ReadLine();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (IOException)
        {
            Console.WriteLine("Синтаксическая ошибка в имени папки!" + Environment.NewLine +
                "Для возвращения в главное меню нажмите Enter.");
            Console.ReadLine();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Предоставляет пользователю способ выбора пути к папке и осуществляет его.
    /// </summary>
    /// <returns>Выбранный пользователем путь.</returns>
    private static string ChooseTypePathInput()
    {
        string[] options = { "Выбрать директорию для копирования вручную.", "Ввести абсолютный путь к директории." };
        int tupeOfInput = SelectMenu("Выберите способ ввода нового расположения файла.", options);
        Console.Clear();
        string newDisk = "", newFolder = "";
        switch (tupeOfInput)
        {
            case 0:

                SelectDisk(ref newDisk, ref newFolder);
                SelectDirectory(ref newDisk, ref newFolder);
                break;
            case 1:
                Console.WriteLine("Примечание, если введённая директория не существует и в её имени" +
                Environment.NewLine +
                @"не содержится название диска, то она будет создаваться в ...\FileManager\bin\Debug\net5.0");
                do
                {
                    Console.WriteLine("Введите абсолютный путь новой директории: ");
                    newFolder = Console.ReadLine();
                } while (newFolder.Length == 0);
                Console.Clear();
                break;
        }
        return newFolder;
    }

    /// <summary>
    /// Даёт возможность замены файла или оставление старого, при помощи метода.
    /// </summary>
    /// <param name="fileName">Файл для земены или оставления.</param>
    /// <returns>Логическое значение: true или false, которое служит индекатором для
    /// замены или оставления файла.</returns>
    private static bool ReplaceOrLeaveFile(string fileName)
    {
        ConsoleKey[] keys = { ConsoleKey.D1, ConsoleKey.NumPad1, ConsoleKey.D2, ConsoleKey.NumPad2 };
        ConsoleKeyInfo info;
        bool f = true;
        do
        {
            Console.WriteLine($"Файл {fileName} уже существует в данной директории!" +
            Environment.NewLine +
            "Оставить старую версию файла (нажмите 1)" +
            Environment.NewLine +
            "Заменить на новый файл (нажмите 2)");
            info = Console.ReadKey(true);
            Console.Clear();
        } while (!Array.Exists(keys, key => key == info.Key));
        switch (info.Key)
        {
            case ConsoleKey.D1:
            case ConsoleKey.NumPad1:
                f = true;
                break;
            case ConsoleKey.D2:
            case ConsoleKey.NumPad2:
                f = false;
                break;
        }
        return f;
    }

    /// <summary>
    /// Выводить в консоль заголовок и текст, которые являются параметрами метода.
    /// </summary>
    /// <param name="title">Заголовок.</param>
    /// <param name="text">Текст.</param>
    private static void Show(string title, string text)
    {
        Console.WriteLine(title + Environment.NewLine);
        Console.WriteLine(text);
        Console.WriteLine();
        Console.WriteLine("Для завершения просмотра нажмите Enter");
        Console.ReadLine();
        Console.Clear();
    }

    /// <summary>
    /// Осуществляет автодополнение названия файла, путём вызова метода FindCommonParts().
    /// Выводит реультата в консоль.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void Autocompletion(ref string disk, ref string folder)
    {
        string fileName;
        string input;
        try
        {
            string[] files = Directory.GetFiles(folder);
            Console.WriteLine("Нажмите Enter для окончания ввода части названия файла.");
            input = Console.ReadLine();
            fileName = input;
            Console.WriteLine("Нажмите Tab для автодополнения или любую другую клавишу для продолжения.");
            if (Console.ReadKey(true).Key == ConsoleKey.Tab)
            {
                fileName = FindCommonParts(input, files);
                Console.Clear();
                Show("РЕЗУЛЬТАТ АВТОДОПОЛНЕНИЯ", folder + @"\" + fileName);
            }
            else
            {
                Console.Clear();
                Show("РЕЗУЛЬТАТ БЕЗ АВТОДОПОЛНЕНИЯ", folder + @"\" + fileName);
            }
        }
        catch (DirectoryNotFoundException)
        {
            string path;
            int intF = Continue("Ошибка! Не произведён ввод пути!", "папке с файлами", out path);
            switch (intF)
            {
                case 0:
                    disk = path.Substring(0, 3);
                    folder = path;
                    Autocompletion(ref disk, ref folder);
                    break;
                case 1:
                    Exit();
                    break;
                case 2:
                    return;
            }
            Console.Clear();
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Дполняет имя файла. Если возможный вариант
    /// дополнения один, имя дополняется полностью. Если же вариантов дополнения
    /// несколько, путь дополняется до общей части
    /// </summary>
    /// <param name="input">Часть названия файла</param>
    /// <param name="files">Массив путей к файлам.</param>
    /// <returns>Автодополненное имя файла.</returns>
    private static string FindCommonParts(string input, string[] files)
    {
        string fileName;
        //Список совпадающих частей.
        var array = new List<string> { };
        foreach (string file in files)
        {
            fileName = Path.GetFileName(file);
            string common = string.Concat(input.TakeWhile((c, i) => c == fileName[i]));
            if (common.Length == input.Length)
            {
                array.Add(fileName);
            }
        }
        if (array.Count == 0)
            fileName = "";
        if (array.Count == 1)
            fileName = array[0];
        else
        {
            string common = "";
            for (int i = 0; i < array.Count - 1; i++)
            {
                common = string.Concat(array[i].TakeWhile((c, j) => c == array[i + 1][j]));
            }
            fileName = common;
        }
        return fileName;
    }

    /// <summary>
    /// Метод, вызываемый после появления исключения. Он даёт пользователю ввести
    /// абсолютный путь к папке, вернуться в главное меню или
    /// полностью прекратить выполнение программы. 
    /// </summary>
    /// <param name="exception">Текст ошибки, который выводится в консоль.</param>
    /// <param name="item">Элемент к которому можно ввести абсолютный путь.</param>
    /// <param name="path">Абсолютный путь к элементу.</param>
    /// <returns>Целочисленное значение, которое потом используется в вызываемом методу. Могут
    /// быть возвращены только три числа: 0, 1, 2.
    /// Значение 0 => продолжить выполнение программы с введённым абсолютным путём (параметр метода path с 
    /// модификаторм out).
    /// Значение 1 => выход из программы .
    /// Значение 2 => передача управления в другой метод.</returns>
    private static int Continue(string exception, string item, out string path)
    {
        Console.WriteLine(exception);
        Console.WriteLine();
        ConsoleKeyInfo info;
        Console.WriteLine($"Для ввода абсолютного пути к {item} нажмите - ENTER." + Environment.NewLine +
                              $"Для возвращения в главное меню нажмите пробел." + Environment.NewLine +
                              "Для выхода - ESCAPE.");
        do
        {
            info = Console.ReadKey(true);
        } while (info.Key != ConsoleKey.Enter && info.Key != ConsoleKey.Escape && info.Key != ConsoleKey.Spacebar);
        Console.Clear();
        if (info.Key == ConsoleKey.Enter)
        {
            Console.WriteLine("Значения диска и папки, выбранных вами заранее, также изменятся.");
            bool f;
            do
            {
                Console.WriteLine($"Введите абсолютный путь к {item}: ");
                path = Console.ReadLine();
                f = Directory.Exists(path);
            } while (!f);
            Console.Clear();
            return 0;
        }
        else
        {
            if (info.Key == ConsoleKey.Spacebar)
            {
                path = "";
                Console.Clear();
                return 2;
            }
            else
            {
                path = "";
                Console.Clear();
                return 1;
            }
        }
    }
}
