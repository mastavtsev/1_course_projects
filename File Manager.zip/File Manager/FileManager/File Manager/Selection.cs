﻿using System;
using System.IO;

/// <summary>
/// Класс для осуществления выбора в консоли.
/// </summary>
internal partial class Program
{
    /// <summary>
    /// Осуществляет переключение между выбираемыми элементами.
    /// </summary>
    /// <param name="message">Заголовок при выборе элементов.</param>
    /// <param name="options">Массив элементов для выбора.</param>
    /// <returns>Индекс выбранного элемента в массиве.</returns>
    private static int SelectMenu(string message, params string[] options)
    {
        int len = options.Length;
        int selectedOption = 0;
        ConsoleKeyInfo info;
        Console.CursorVisible = false;
        do
        {
            //Console.WriteLine(tm.CurrentSpace(disk, folder) + "\n");
            Console.WriteLine(message);
            for (int i = 0; i < len; i++)
            {
                if (selectedOption == i) Console.Write("> ");
                else Console.Write("  ");
                Console.WriteLine(options[i]);
            }
            do
            {
                info = Console.ReadKey(true);
            } while (info.Key != ConsoleKey.Enter && info.Key != ConsoleKey.UpArrow && info.Key != ConsoleKey.DownArrow);

            if (info.Key == ConsoleKey.UpArrow)
            {
                if (selectedOption == 0) selectedOption = len - 1;
                else selectedOption--;
            }
            if (info.Key == ConsoleKey.DownArrow)
            {
                if (selectedOption == len - 1) selectedOption = 0;
                else selectedOption++;
            }
            Console.Clear();
        } while (info.Key != ConsoleKey.Enter);
        Console.Clear();
        Console.CursorVisible = true;
        return selectedOption;
    }


    /// <summary>
    /// Осуществляет выбор директории, а также вызывает вспомогательный метод SelectDirectRec
    /// для выбора поддиректорий.
    /// При вводе диска по умолчанию метод просматривает папки в нём, если диск не указан, пользователю
    /// предлагается выбрать путь к папке, при этом происходит определение диска по умолчанию.
    /// Пользователь также может изменить значение диска по умолчанию при выборе папки.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    private static void SelectDirectory(ref string disk, ref string folder)
    {
        bool f = true;
        TextMessage tm = new();
        string message = tm.CurrentSpace(disk, folder) + "\n";
        try
        {
            string[] allFolders = Directory.GetDirectories(disk);
            folder = allFolders[SelectMenu(message + "\nВЫБОР ПАПКИ:", allFolders)];
            // Метод SelectDirectRec() вызывается пока у директории folder есть поддиректории.
            while (Directory.GetDirectories(folder).Length > 0 && f)
            {
                (disk, folder, f) = SelectDirectRec(ref disk, ref folder, tm);
            }
        }
        catch (DirectoryNotFoundException)
        {
            string path;
            int intF = Continue("Ошибка! Не произведён ввод пути!", "папке", out path);
            if (0 == intF)
            {
                disk = path.Substring(0, 3);
                folder = path;
            }
            else
            {
                if (intF == 2)
                    return;
                else
                    Exit();
            }
        }
        catch (UnauthorizedAccessException)
        {
            Console.WriteLine("Доступ к папке запрещён." +
                Environment.NewLine +
                "Для продолжения нажмите Enter.");
            folder = "   None";
            Console.ReadLine();
            Console.Clear();
        }
        catch (Exception e)
        {
            Console.WriteLine($"Ошибка: {e}");
            Console.WriteLine("Нажмите любую клавишу для возвращения в главное меню.");
            Console.ReadKey();
            Console.Clear();
            SelectOperation(ref disk, ref folder);
        }
    }

    /// <summary>
    /// Осуществляет выбор поддиректории. При этом меняет значение изначальной директории на 
    /// путь к поддиректории.
    /// Пользовательь может остановиться на выборе директории, без дальнейшего выбора поддиректории.
    /// </summary>
    /// <param name="disk">Имя текущего диска.</param>
    /// <param name="folder">Путь к текущей директории.</param>
    /// <param name="tm">Объект класса TextMessage.</param>
    /// <returns>Кортеж значений: disk и folder - изменённые значения диска и папки;
    /// f - логическая переменная, являющаяся индекатором того, что пользователь
    /// остановился на выборе директории или решил продолжить выбор поддиректорий.</returns>
    private static (string, string, bool) SelectDirectRec(ref string disk, ref string folder, TextMessage tm)
    {
        bool f = true;
        ConsoleKeyInfo info;
        Console.WriteLine("В данной папке есть вложенные, хотите выбрать одну из них?");
        Console.WriteLine("Выбрать для работы данную папку (нажмите 1)" +
            Environment.NewLine +
            "Продолжить для выбора вложенной папки (нажмите 2)");
        ConsoleKey[] availableKeys = { ConsoleKey.D1, ConsoleKey.NumPad1, ConsoleKey.D2, ConsoleKey.NumPad2 };
        do
        {
            info = Console.ReadKey(true);
        } while (!Array.Exists(availableKeys, element => element == info.Key));

        Console.Clear();
        switch (info.Key)
        {
            case ConsoleKey.D1:
            case ConsoleKey.NumPad1:
                f = false;
                break;
            case ConsoleKey.D2:
            case ConsoleKey.NumPad2:
                string message = tm.CurrentSpace(disk, folder) + Environment.NewLine;
                string[] allFolders = Directory.GetDirectories(folder);
                folder = allFolders[SelectMenu(message + Environment.NewLine + "ВЫБОР ПАПКИ:", allFolders)];
                break;
        }
        return (disk, folder, f);
    }
}
