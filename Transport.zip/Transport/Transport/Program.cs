﻿using System;
using EKRLib;
using System.IO;
using System.Text;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Переменная для определения нажатой клавиши на клавиатуре.
            ConsoleKeyInfo info;

            var rnd = new Random();

            // Количество объектов в массиве объектов типа Transoprt,
            // генерируется случайным образом.
            int transNumber = rnd.Next(6, 10);

            // Массив объетов типа Transport.
            Transport[] transArr = new Transport[transNumber];

            // Булевая переменная, хранящая информацию о том, создан ли объект
            // типа Сar или MotorBoat.
            bool transportCreated;

            
            do
            {
                for (int i = 0; i < transNumber; i++)
                {
                    Transport newItem = default;
                    transportCreated = false;
                    do
                    {
                        try
                        {
                            newItem = rnd.Next(0, 2) == 0 ? GetCar() : GetMotorBoat();
                            transportCreated = true;
                        }
                        catch (TransportException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    } while (!transportCreated);

                    Console.WriteLine(newItem.StartEngine());
                    transArr[i] = newItem;
                }
                WriteInfo(transArr);

                Console.WriteLine("Для повтора решения нажмите Enter," +
                    " для выхода - любую другую клавишу.");
                info = Console.ReadKey();
                Console.Clear();

            } while (info.Key == ConsoleKey.Enter);
        }

        /// <summary>
        /// Метод для получния объекта типа Car.
        /// </summary>
        /// <returns>Объект типа Car.</returns>
        private static Car GetCar()
        {
            var rnd = new Random();
            uint power = (uint)rnd.Next(10, 100);
            string model = GetModelName();

            return new Car(model, power);
        }

        /// <summary>
        /// Метод для получния объекта типа MotorBoat.
        /// </summary>
        /// <returns>Объект типа MotorBoat.</returns>
        private static MotorBoat GetMotorBoat()
        {
            var rnd = new Random();
            uint power = (uint)rnd.Next(10, 100);
            string model = GetModelName();

            return new MotorBoat(model, power);
        }

        /// <summary>
        /// Метод для получения наименования транспорта.
        /// </summary>
        /// <returns>Строка - наименование транспорта.</returns>
        private static string GetModelName()
        {
            var rnd = new Random();

            // Используется целочисленное значение сиволов - char.
            // Используется генератор случайного числа - 0 или 1, 
            // для определения очередного символа в наименовании -
            // латинская заглавная буква или цифра.
            // A = 65,  Z = 90, '0' = 48, '9' = 57
            var sb = new StringBuilder();
            for (int i = 0; i < 5; i++)
            {
                if (rnd.Next(0, 2) == 0)
                    sb.Append((char)(rnd.Next(65, 91)));
                else
                    sb.Append((char)(rnd.Next(48, 58)));
            }

            return sb.ToString();
        }

        /// <summary>
        /// Метод для записи информации об объектах 
        /// </summary>
        /// <param name="transports">Массив объектов типа Transport.</param>
        private static void WriteInfo(Transport[] transports)
        {
            // Пути к файлам на запись.
            string pathCar = "../../../../Cars.txt";
            string pathBoat = "../../../../Boat.txt";

            // Создание файловых потоков.
            FileStream fsCar = new FileStream(pathCar, FileMode.Create, FileAccess.Write);
            FileStream fsBoat = new FileStream(pathBoat, FileMode.Create, FileAccess.Write);

            // Создание объектов StreamWriter при помощик конструтора,
            // содержащего файловый поток и кодировку - UTF16.
            StreamWriter swCar = new(fsCar, Encoding.Unicode);
            StreamWriter swBoat = new(fsBoat, Encoding.Unicode);

            try
            {
                var sbCar = new StringBuilder();
                var sbBoat = new StringBuilder();

                foreach (var transport in transports)
                {
                    if (transport is Car)
                        sbCar.Append(transport + Environment.NewLine);
                    else if (transport is MotorBoat)
                        sbBoat.Append(transport + Environment.NewLine);
                }

                swCar.Write(sbCar.ToString());
                swBoat.Write(sbBoat.ToString());

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                // Закрытие файловых потоков.
                swCar.Close();
                swBoat.Close();
            }
        }
    }
}

