﻿namespace EKRLib
{
    public class Car : Transport
    {
        /// <summary>
        /// Конструктор объекта типа Car. Использует конструктор
        /// базового типа.
        /// </summary>
        /// <param name="model">Наименование модели.</param>
        /// <param name="power">Мощность.</param>
        public Car(string model, uint power) : base(model, power) { }

        /// <summary>
        /// Переопределённый метод для строкового представления объекта 
        /// типа Car.
        /// </summary>
        /// <returns>Строковое представление объекта типа Car.</returns>
        public override string ToString()
        {
            return "Car. " + base.ToString();
        }

        /// <summary>
        /// Переопределённый метод для получения звука Авто.
        /// </summary>
        /// <returns></returns>
        public override string StartEngine()
            => $"{Model}: Vroom";
    }
}
