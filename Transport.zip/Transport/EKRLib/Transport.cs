﻿using System;

namespace EKRLib
{
    /// <summary>
    /// Базовый абстрактный класс, реализующий логику работы для 
    /// всех объектов наследников данного типа.
    /// </summary>
    public abstract class Transport
    {

        private uint power;
        private string model;

        /// <summary>
        /// Конструктор объектов типа Transport.
        /// Так как класс является абстрактным, то конструктор может
        /// использоваться только в типах-наследниках.
        /// </summary>
        /// <param name="modelVal">Именование модели.</param>
        /// <param name="powerVal">Значение мощности.</param>
        public Transport(string modelVal, uint powerVal)
            => (Model, Power) = (modelVal, powerVal);

        /// <summary>
        /// Свойство, для получения и выставления значения Именования модели.
        /// При установке значения вызывается метод CheckModelsName,
        /// для проверки корректности наименования.
        /// </summary>
        public string Model
        {
            get => model;

            set
            {
                model = CheckModelsName(value) ?
                    throw new TransportException($"Недопустимая модель {value}") : value;
            }
        }

        /// <summary>
        /// Свойство, для получения и выставления значения Мощности.
        /// Мощность не может быть меньше 20, присутствует соответствующая проверка
        /// при установке значения.
        /// </summary>
        public uint Power
        {
            get => power;

            set
            {
                power = value < 20 ?
                    throw new TransportException("Мощность не может быть меньше 20 л.с.") : value;
            }
        }

        /// <summary>
        /// Метод, для преобразования объекта типа Transport
        /// к строковому представлению.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Model: {Model}, Power {Power}";
        }

        /// <summary>
        /// Метод для проверки корректности значения - наименования модели.
        /// Ограничения для имени модели: Модель должна состоять только из
        ///  заглавных латинских символов и цифр и длину ровно 5 символов.
        /// </summary>
        /// <param name="value">Значение наименования модели, поданное в конструктор.</param>
        /// <returns>True - если значение корректно, false - если не корректно.</returns>
        private bool CheckModelsName(string value)
        {
            bool f = false;

            if (value.Length != 5)
            {
                foreach (var symbol in value)
                    if (('A' > symbol && symbol > 'Z')
                        || int.TryParse(symbol.ToString(), out _))
                        return false;
                f = true;
            }
            return f;
        }

        /// <summary>
        /// Абстрактный метод для получения звука издаваемого транспортным
        /// средством. Должен быть переопределён в классах наследниках.
        /// </summary>
        /// <returns>Строку - Звук транспротного средства.</returns>
        public abstract string StartEngine();


    }
}
