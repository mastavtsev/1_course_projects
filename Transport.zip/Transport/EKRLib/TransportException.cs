﻿using System;


namespace EKRLib
{
    /// <summary>
    /// Пользоваетльское исключение для типа Transport
    /// и его наследников.
    /// </summary>
    [Serializable]
    public class TransportException : Exception
    {
        /// <summary>
        /// Безмараметрический конструктор исключения.
        /// </summary>
        public TransportException() { }
        
        /// <summary>
        /// Конструктор исключения с сообщением об ошибке.
        /// </summary>
        /// <param name="message">Сообщение об ошибке.</param>
        public TransportException(string message) : base(message) { }

        /// <summary>
        /// Конструктор исключения с сообщением об ошибке и ссылкой на внутреннее исключение.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="inner"></param>
        public TransportException(string message, Exception inner) : base(message, inner) { }

        /// <summary>
        /// Конструктор с объектом объектом SerializationInfo, хранящим сериализованные данные
        /// и объектом StreamingContext, содержащим контекстные сведения об источнике или назначении.
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected TransportException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
