﻿namespace EKRLib
{
    public class MotorBoat : Transport
    {
        /// <summary>
        /// Конструктор объекта типа Car. Использует конструктор
        /// базового типа.
        /// </summary>
        /// <param name="model">Наименование модели.</param>
        /// <param name="power">Мощность.</param>
        public MotorBoat(string model, uint power) : base(model, power) { }

        /// <summary>
        /// Переопределённый метод для строкового представления объекта 
        /// типа Car.
        /// </summary>
        /// <returns>Строковое представление объекта типа Car.</returns>
        public override string ToString()
        {
            return "MotorBoat. " + base.ToString();
        }

        /// <summary>
        /// Переопределённый метод для получения звука Моторной лодки.
        /// </summary>
        /// <returns></returns>
        public override string StartEngine()
            => $"{Model}: Brrrbrr";
    }
}
