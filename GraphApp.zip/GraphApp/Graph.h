#ifndef GRAPHAPP__GRAPH_H_
#define GRAPHAPP__GRAPH_H_
#pragma once

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <tuple>
#include <queue>
#include <map>
#include <set>
#include <stack>

/**
 * Структура Graph - для хранения матрицы смежности графа и также
 * индикаторо о симметричности этой матрицы.
 */
struct Graph {
  std::vector<std::vector<int>> adjacency_matrix;
  bool is_symmetrical;
};

/**
 * @param graph Объект типа Graph для которого происходит
 * поиск в ширину.
 */
void BreadthFirstSearch(Graph& graph);

/**
 * @param graph Объект типа Graph для которого происходит
 * не рекурсивный поиск в глубину.
 */
void DepthFirstSearchNotRec(Graph& graph);

/**
 * @param graph Объект типа Graph для которого происходит
 * рекурсивный поиск в глубину.
 */
void DepthFirstSearchRec(Graph& graph);

/**
 *
 * @param type_of_matrix Тип матрицы - её название.
 * @return Тип получения матрицы - консоль (1) или файл (2).
 */
int GetTypeOfGraphInput(const std::string &type_of_matrix);

/**
 *
 * @tparam T Тип потока - файл (fstream) или консоль (iostream - cin).
 * @param my_stream Поток для считывания матрицы.
 * @param get_input Индикатор необходимости о запрашивании размера
 * матрицы.
 * @param iter_num Количество строк при считывании матрицы.
 * @return Матрица полученная от пользователя.
 *
 * Шаблонная функция для считывания матрицы из потока.
 */
template<typename T>
std::vector<std::vector<int>> GetMatrixFromStream(T &my_stream, bool get_input, int iter_num);

/**
 *
 * @param type_of_matrix Тип матрицы - её название.
 * @return Файловый поток для считывания матрицы.
 *
 * Функци получает путь к .txt файлу с матрицей и формирует файловый поток.
 */
std::ifstream GetStreamFromFile(const std::string &type_of_matrix);

/**
 *
 * @param type_of_input Тип ввода матрицы - консоль или файл.
 * @param cin_text Текст, отображающийся при вводе матрицы.
 * @param type_of_matrix Тип вводимой матрицы - её название.
 * @param get_input Индикатор необходимости о запрашивании размера
 * матрицы.
 * @param iter_num Количество строк при считывании матрицы.
 * @return Матрица полученная от пользователя.
 *
 * В зависимости от типа ввода функция вызывает шаблонную функцию для считывания матрицы
 * из соответсвующего потока.
 */
std::vector<std::vector<int>> SwitchStreamsAndGetMatrix(int type_of_input,
                                                        std::string &cin_text,
                                                        std::string &type_of_matrix,
                                                        bool get_input,
                                                        int iter_num);

/**
 *
 * @param matrix Матрица для проверки.
 * @param type_of_matrix Тип представления для которго формировалась
 * матрица смежности.
 * @return Объект типа Graph.
 *
 * Функция для проверки матрицы на смежности, то есть она должна состоять только
 * из 0 или 1, а также быть квадратной. Также матрицы проверяется на симметричность для
 * определения типа графа - ориентированный или неориентированный. Если все проверки
 * проходят успешно, то формироуется новый объект типа Graph, в противном случае функция
 * возвращает пустой объект.
 */
Graph CheckMatrix(std::vector<std::vector<int>> &matrix,
                  std::string &type_of_matrix);

/**
 * @return Объект типа Graph.
 *
 * Функция считывает матрицу смежности графа и формирует объект типа Graph.
 */
Graph GetByAdjMatrix();

/**
 *
 * @param inc_matrix Матрица инцидентности графа.
 * @return Матрица смежности графа.
 *
 * Функция для преобразования матрицы инцидентности в матрицу смежности графа.
 */
std::vector<std::vector<int>> FromIncMatrixToAdjMatrix(std::vector<std::vector<int>> &inc_matrix);

/**
 *
 * @return Объект типа Graph.
 *
 * Функция считывает матрицу инцидентности графа, вызывает функцию для преобразования
 * этой матрицы в матрицу смежности и после формирует объект типа Graph.
 */
Graph GetByIncMatrix();

/**
 *
 * @param adj_list Список смежности графа.
 * @return Матрица смежности графа.
 *
 * Функция для преобразования списка смежности графа в матрицу смежности.
 */
std::vector<std::vector<int>> FromAdjListToAdjMatrix(std::vector<std::vector<int>> &adj_list);

/**
 *
 * @return Объект типа Graph.
 *
 * Функция считывает список смежности графа, вызывает функцию для преобразования
 * этого спика в матрицу смежности и после формирует объект типа Graph.
 */
Graph GetByAdjList();

/**
 *
 * @param edj_list Список рёбер графа.
 * @param num_of_vertices Количество вершин графа.
 * @return Матрица смежности графа.
 *
 * Функция для преоборазования списка рёбер в матрицу смежности графа.
 */
std::vector<std::vector<int>> FromEdjListToAdjMatrix(std::vector<std::vector<int>> &edj_list, int num_of_vertices);

/**
 *
 * @return Объект типа Graph.
 *
 * Функция считывает список рёбер графа, вызывает функцию для преобразования
 * этого спика в матрицу смежности и после формирует объект типа Graph.
 */
Graph GetByEdgList();

/**
 *
 * @param type_of_matrix Тип представление - FO, FI или BFO
 * @return FO, FI или BFO представление графа
 *
 * Функция для считывание представления графа.
 */
std::vector<int> ReadFOorFI(std::string &&type_of_matrix);
/**
 * @return Объект типа граф.
 *
 * Функция считывает FO представление графа, по нему создаёт матрицу смежности и после
 * формирует объект типа Graph.
 */
Graph GetByFO();

/**
 * @return Объект типа граф.
 *
 * Функция считывает FI представление графа, по нему создаёт матрицу смежности и после
 * формирует объект типа Graph.
 */
Graph GetByFI();

/**
 *
 * @return Объект типа граф.
 *
 * Функция получает от пользователя тип графа - ориентированный или нет, и после вызывает соответствующую функцию.
 * Если был выбран ориентированный граф, то функция получает от пользователя тип представления (FO или FI), для
 * ориентированного графа возможно только FO представление.
 */
Graph GetByFOOrFIForms();


/**
 *
 * @param type_of_matrix Тип матрицы - её название (MFI, MFO или BMFO).
 * @return Объект типа pair - количество вершин графа и его матрица его представления (MFI, MFO или BMFO).
 */
std::pair<int, std::vector<std::vector<int>>> ReadMFOOrMFIOrBMFOForm(std::string &&type_of_matrix);

/**
 * @return Объект типа граф.
 *
 * Функция считывает BMFO представление графа, создаёт матрицу смежности и после
 * формирует объект типа Graph.
 */
Graph GetByBMFO();

/**
 * @return Объект типа граф.
 *
 * Функция считывает MFO представление графа, создаёт матрицу смежности и после
 * формирует объект типа Graph.
 */
Graph GetByMFO();

/**
 * @return Объект типа граф.
 *
 * Функция считывает MFI представление графа, создаёт матрицу смежности и после
 * формирует объект типа Graph.
 */
Graph GetByMFI();

/**
 * @return Объект типа граф.
 *
 * Функция получает от пользователя тип графа - ориентированный или нет, и после вызывает
 * соответствующую функцию.
 */
Graph GetByMFOOrMFIForms();

/**
 * @return Объект типа граф.
 *
 * Функция считывает BFO представление графа, по нему создаёт матрицу смежности и после
 * формирует объект типа Graph.
 */
Graph GetByBFO();

/**
 * @return Объект типа Graph, полученный одним из 8 возможных представлений.
 *
 * Эта функция получает тип ввода для данных графа, затем вызывает требуемую функцию и получает объект типа Graph.
 */
Graph GetNewGraph();


/**
 *
 * @param graph Неориентированный граф, в котором подсчитывается степень вершин.
 * @param show_result Индикатор, говорящий о необходимости вывода в консоль
 * суммы степеней рёбер.
 * @return Сумма степеней рёбер.
 */
int CountDegreesForUndirectedGraph(const Graph &graph, bool show_result);

/**
 *
 * @param graph Ориентированный граф, в котором для вершин подсчитываются
 * полустепени захода и исхода.
 * @param show_result Индикатор, говорящий о необходимости вывода в консоль
 * суммы степеней рёбер.
 * @return Сумма степеней рёбер.
 */
int CountDegreesForDirectedGraph(const Graph &graph, bool show_result);

/**
 *
 * @param graph Граф в котором подсчитывается степень вершин.
 * @param show_result Индикатор, говорящий о необходимости вывода в консоль
 * суммы степеней рёбер.
 * @return Сумма степеней рёбер.
 *
 * Для неориентированного графа вызывается функция подсчёта обычной степени вершины,
 * для ориентированного графа - для подсчёта полустепени захода и исхода вершины.
 */
int CountDegreesOfVertices(const Graph &graph, bool show_result);

/**
 *
 * @param graph Граф, для которого подсчитывается количество рёбер.
 * @param show_result Индикатор, говорящий о необходимости вывода в консоль
 * количества рёбер.
 * @return Количество рёбер графа.
 */
int CountNumberOfEdges(const Graph &graph, bool show_result);

/**
 * @param type_of_matrix Тип - название матрицы для сохранения в файл.
 * @param matrix Матрица для сохранения в файл.
 * @param print_size Индикатор, говорящий о необходимости дополнительно вывести в файл размер матрицы.
 * Например, размер необходимо записывать при сохранении матрицы смежности, но это не требуется при
 * сохранении матрицы MFO(BFO) или MFI.
 *
 * Функция получает от пользователя путь для сохранения .txt файла с матрицей и осуществляет запись туда.
 */
void SaveMatrix(const std::string &type_of_matrix, const std::vector<std::vector<int>> &matrix,
                bool print_size);

/**
 * @param incidence_matrix Матрица инцидентности графа, которая выводится в консоль.
 */
void OutputIncidenceMatrix(const std::vector<std::vector<int>> &incidence_matrix);


/**
 * @param graph Объект типа граф, для который формируется матрица инцидентности.
 *
 * Функция строит матрицу инцидентности для неориентированного графа.
 */
void MakeIncidenceMatrixForUndirectedGraph(const Graph &graph);


/**
 * @param graph Объект типа граф, для который формируется матрица инцидентности.
 *
 * Функция строит матрицу инцидентности для ориентированного графа.
 */
void MakeIncidenceMatrixForDirectedGraph(const Graph &graph);

/**
 * @param graph Объект типа граф, для который формируется матрица инцидентности.
 *
 * Функция проверяет, если полученный граф является неориентированным, то вызывается функция для
 * постороения матрицы инцидентности для неориентированного графа - MakeIncidenceMatrixForUndirectedGraph(),
 * в противном случае для ориентированного - MakeIncidenceMatrixForDirectedGraph().
 */
void MakeIncidenceMatrix(const Graph &graph);

/**
 * @param graph Объект типа граф, который отображается в виде списка смежности.
 * @param show_result Индикатор, говорящий о необходимости вывода
 * списка смежности в консоль.
 * @return Вектор из векторов типа int - строки списка смежности.
 */
std::vector<std::vector<int>> MakeAdjacencyList(const Graph &graph, bool show_result);

/**
 * @param graph Объект типа граф, который отображается в виде списка рёбер.
 * @param show_result Индикатор, говорящий о необходимости вывода
 * списка рёбер в консоль.
 * @return Вектор из векторов типа int - строки списка рёбер.
 */
void MakeListOfEdges(const Graph &graph);

/**
 * @param graph Объект типа граф, который отображается в FO или FI форме,
 * в зависимости от типа графа и выбора пользователя.
 * @param show_result Индикатор, говорящий о необходимости вывода
 * FO илм FI формы в консоль.
 * @return Вектор из векторов типа int - FO и FI (если есть) пердставления графа.
 */
std::vector<std::vector<int>> MakeFOandFIForm(const Graph &graph, bool show_result);

/**
 * @param graph  Объект типа граф, который отображается в MFO или MFI форме, в зависимости
 * от типа графа.
 *
 * Функция формирует MFO представление, если граф неориентированный,
 * и MFI форму, если граф ориентированный.
 * Функция вызывает функцию MakeFOandFIForm() для получения
 * FO и FI представлений графа.
 */
void MakeMFOorMFIForm(const Graph &graph);

/**
 * @param graph Объект типа граф, для которого формируется представление BFO.
 * @param show_result Индикатор, говорящий о необходимости вывода
 * BFO формы в консоль.
 * @return BFO форма графа, которая является вектором от int.
 */
std::vector<int> MakeBFOForm(const Graph &graph, bool show_result);

/**
 * @param graph Объект типа граф, который выводится в форме BMFO.
 *
 * Функция вызывает функцию MakeBFOForm() для получения BFO представления
 * графа, которое является вектором от int. После конструирует BMFO
 * представление, используя вектор BFO.
 */
void MakeBMFOForm(const Graph &graph);

/**
 * @param graph Объект типа Graph, который представляется форме BFO или BMFO.
 *
 * Функция получает от пользователя тип представления BFO или BMFO, вызывает
 * соответствующую функцию. Так же функция проверяет, что данные представления
 * могут быть получены только для неориентированного графа.
 */
void MakeBFOorBMFOForm(const Graph &graph);

/**
 * @param graph Объект типа Graph, который представляется в виде матрицы смежности.
 *
 * Так как каждый объект типа Graph содержит поле - матрицу, которое является
 * матрице смежности, то эта функция просто выводит каждую строку данной матрицы
 */
void OutputAdjacencyMatrix(const Graph &graph);

/**
 * @param graph Объект типа Graph, который будет выведен в другом представлении.
 *
 * Функция получает требуемый тип представления от пользователся, после вызывает соответствующую функцию.
 * Каждая вызываемая функция содержит вызов функции для сохранения графа в .txt файл.
 */
void OutputInAnotherForm(const Graph &graph);

#endif //GRAPHAPP__GRAPH_H_
