#include "Graph.h"

auto print = [](const auto &v) {
  for (const auto &i : v) std::cout << i << ' ';
};

void BreadthFirstSearch(Graph& graph) {
  int num_of_vert = static_cast<int>(graph.adjacency_matrix.size());
  std::vector<int> vertices_black(num_of_vert, 0);

  std::queue<int> my_queue;
  my_queue.push(0);

  std::cout << "Breadth First Search:" << std::endl;
  /// 1 как признак посещения вершины.
  /// -1 как признак обнаружения
  while (!my_queue.empty()) {
    int vertex = my_queue.front();
    my_queue.pop();
    vertices_black[vertex] = 1;
    for (int i = 0; i < num_of_vert; ++i) {
      if (graph.adjacency_matrix[vertex][i] == 1 && vertices_black[i] == 0) {
        my_queue.push(i);
        vertices_black[i] = -1;
      }
    }

    std::cout << vertex + 1 << std::endl;
  }
}

void DepthFirstSearchNotRec(Graph& graph) {
  int num_of_vert = static_cast<int>(graph.adjacency_matrix.size());
  std::vector<int> vertices_black(num_of_vert, 0);

  std::stack<int> my_stack;
  my_stack.push(0);

  std::cout << "Depth First Search Not Recursively:" << std::endl;

  while (!my_stack.empty()) {
    int vertex = my_stack.top();
    my_stack.pop();
    /// 1 как признак посещения вершины.
    /// -1 как признак обнаружения
    if (vertices_black[vertex] == 1)
      continue;

    vertices_black[vertex] = 1;

    for (int i = 0; i < num_of_vert; ++i) {
      if (graph.adjacency_matrix[vertex][i] && vertices_black[i] != 1) {
        my_stack.push(i);
        vertices_black[i] = -1;
      }
    }

    std::cout << vertex + 1 << std::endl;
  }
}

void RecFuncForSearch(int vertex, int num, std::vector<int>& vb, Graph& graph) {
  std::cout << vertex + 1 << std::endl;
  /// 1 как признак посещения вершины.
  vb[vertex] = 1;
  for (int i = 0; i < num; ++i) {
    if (graph.adjacency_matrix[vertex][i] == 1 && vb[i] != 1)
      RecFuncForSearch(i, num, vb, graph);
  }
}

void DepthFirstSearchRec(Graph& graph) {
  int num_of_vert = static_cast<int>(graph.adjacency_matrix.size());
  std::vector<int> vertices_black(num_of_vert, 0);

  std::cout << "Depth First Search Not Recursively:" << std::endl;
  RecFuncForSearch(0, num_of_vert, vertices_black, graph);
}

int GetTypeOfGraphInput(const std::string &type_of_matrix) {
  int type_of_input;
  std::cout << std::endl;
  std::cout << "Please, select one option and input its number in console." << std::endl;
  std::cout << "1. Input " << type_of_matrix << " of the graph in console. \n"
            << "2. Get " << type_of_matrix << " from .txt file on your computer. \n";

  std::cout << "Your choice : ";
  do {
    std::cin >> type_of_input;
    if (type_of_input != 1 && type_of_input != 2)
      std::cout << "Wrong number!" << std::endl;
  } while (type_of_input != 1 && type_of_input != 2);



  return type_of_input;
}

template<typename T>
std::vector<std::vector<int>> GetMatrixFromStream(T &my_stream, bool get_input, int iter_num) {
  std::vector<std::vector<int>> matrix;
  int number_of_lines;

  if (get_input)
    my_stream >> number_of_lines;
  else
    number_of_lines = iter_num;

  for (int i = 0; i < number_of_lines; i++) {
    std::string data;
    std::getline(my_stream >> std::ws, data);
    int num;
    std::vector<int> matrix_line;
    std::stringstream ss(data);
    while (ss >> num)
      matrix_line.push_back(num);
    matrix.push_back(matrix_line);
  }
  return matrix;
}

std::ifstream GetStreamFromFile(const std::string &type_of_matrix) {
  std::string path_to_graph;
  std::ifstream fin;

  std::cout << std::endl;
  std::cout << "Please, input the path to file with graph data." << std::endl;
  if (type_of_matrix == "FI form" || type_of_matrix == "FO form" || type_of_matrix == "BFO form")
    std::cout << "The file you specify the path to must contain"
                 "the " << type_of_matrix << " of the graph. \n"
                                             "it should be one line with positive numbers, divided by 0 (zero)."
              << std::endl;
  else if (type_of_matrix == "list of edges")
    std::cout << "The file you specify the path to must contain \n"
                 "the amount of edges in graph, it should be one positive number, and \n"
                 "the " << type_of_matrix << " of the graph. \n" << std::endl;
  else
    std::cout << "The file you specify the path to must contain \n"
                 "the amount of vertices in graph, it should be one positive number, and \n"
                 "the " << type_of_matrix << " of the graph." << std::endl;

  do {
    std::cout << "Path to file : ";
    std::cin >> path_to_graph;
    std::cout << std::endl;
    fin.open(path_to_graph);
    if (!fin.is_open())
      std::cout << "Sorry but the path you gave is wrong. Please, input it once again." << std::endl;
  } while (!fin.is_open());

  return fin;
}

std::vector<std::vector<int>> SwitchStreamsAndGetMatrix(int type_of_input,
                                                        std::string &cin_text,
                                                        std::string &type_of_matrix,
                                                        bool get_input = true,
                                                        int iter_num = 0) {
  std::vector<std::vector<int>> matrix;
  switch (type_of_input) {
    case 1: {
      std::cout << std::endl;
      std::cout << cin_text << std::endl;
      matrix = GetMatrixFromStream(std::cin, get_input, iter_num);
      break;
    }
    case 2: {
      std::ifstream fin = GetStreamFromFile(type_of_matrix);
      matrix = GetMatrixFromStream(fin, get_input, iter_num);
      fin.close();
      break;
    }
    default:break;
  }

  return matrix;
}

Graph CheckMatrix(std::vector<std::vector<int>> &matrix,
                  std::string &type_of_matrix) {
  Graph graph;
  size_t n = matrix.size();
  size_t k = matrix[0].size();

  bool is_symmetrical = true;
  bool is_adjacency_matrix = true;

  /// Означает, что матрица не квадратная.
  /// Поэтому она не может быть матрицой смежности.
  if (n != k)
    return graph;

  for (size_t i = 0; i < n; ++i) {
    if (!is_adjacency_matrix)
      break;

    for (size_t j = 0; j < n; ++j) {
      if (matrix[i][j] != 1 && matrix[i][j] != 0) {
        is_adjacency_matrix = false;
        break;
      }
      if (matrix[i][j] != matrix[j][i])
        is_symmetrical = false;
    }
  }

  if (!is_adjacency_matrix) {
    std::string warn_message = "Sorry, but the " + type_of_matrix + " you gave cannot be converted to "
                                                                    "adjacency matrix of a graph. \n"
                                                                    "Please check that matrix or input.";
    std::cout << warn_message << std::endl;
    matrix.clear();
  } else {
    graph = Graph{matrix, is_symmetrical};
    std::cout << "Matrix Accepted" << std::endl;
  }

  return graph;
}

Graph GetByAdjMatrix() {
  std::vector<std::vector<int>> graph_adjacency_matrix;
  int type_of_input = GetTypeOfGraphInput("adjacency matrix");
  std::string cin_text = "Please, input the amount of vertices in graph, it should be one positive number. \n"
                         "This number shows the amount of rows and columns in the adjacency matrix. \n"
                         "After that input in console, line by line, matrix elements"
                         " separated by spaces.";
  std::string type_of_matrix = "adjacency matrix";
  graph_adjacency_matrix = SwitchStreamsAndGetMatrix(type_of_input, cin_text, type_of_matrix);
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

std::vector<std::vector<int>> FromIncMatrixToAdjMatrix(std::vector<std::vector<int>> &inc_matrix) {
  int num_of_vertices = static_cast<int>(inc_matrix.size());
  int num_of_edges = static_cast<int>(inc_matrix[0].size());
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  // Номера вершин.
  int v1, v2;
  int v1_index, v2_index;
  for (int i = 0; i < num_of_edges; ++i) {
    v1 = -2;
    v2 = -2;
    for (int j = 0; j < num_of_vertices; ++j) {
      if (v1 != -2 && v2 != -2)
        break;
      if (inc_matrix[j][i] != 0) {
        if (v1 == -2) {
          v1 = inc_matrix[j][i];
          v1_index = j;
        } else {
          v2 = inc_matrix[j][i];
          v2_index = j;
        }
      }
    }
    if (v1 == 1 && v2 == 1) {
      graph_adjacency_matrix[v1_index][v2_index] = 1;
      graph_adjacency_matrix[v2_index][v1_index] = 1;
    } else if (v1 == 1) {
      graph_adjacency_matrix[v1_index][v2_index] = 1;
    } else if (v2 == 1) {
      graph_adjacency_matrix[v2_index][v1_index] = 1;
    }
  }
  return graph_adjacency_matrix;
}

Graph GetByIncMatrix() {
  std::vector<std::vector<int>> graph_incidence_matrix;
  int type_of_input = GetTypeOfGraphInput("incidence matrix");
  std::string cin_text =
      "Please, note that in a directed graph, if an edge EXITS from a vertex, then the incidence matrix should contain 1.\n"
      "Otherwise, if the edge ENTERS the vertex, then it should be -1. \n"
      "If the orientation is wrong, then the adjacency matrix of\n"
      "directed graph will be transposed and all the functionality of the application will not work correctly. \n\n"
      "Please, input the amount of vertices in graph, it should be one positive number. \n"
      "This number shows the amount of rows in the incidence matrix. \n"
      "After that input in console, line by line, matrix elements"
      " separated by spaces. \n";

  std::string type_of_matrix = "incidence matrix";
  graph_incidence_matrix = SwitchStreamsAndGetMatrix(type_of_input, cin_text, type_of_matrix);
  std::vector<std::vector<int>> graph_adjacency_matrix = FromIncMatrixToAdjMatrix(graph_incidence_matrix);
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

std::vector<std::vector<int>> FromAdjListToAdjMatrix(std::vector<std::vector<int>> &adj_list) {
  int num_of_vertices = static_cast<int>(adj_list.size());
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));

  for (int i = 0; i < num_of_vertices; ++i) {
    for (auto &v : adj_list[i]) {
      graph_adjacency_matrix[i][v - 1] = 1;
    }
  }

  return graph_adjacency_matrix;
}

Graph GetByAdjList() {
  std::vector<std::vector<int>> adj_list;
  std::string type_of_matrix = "adjacency list";
  int type_of_input = GetTypeOfGraphInput(type_of_matrix);
  std::string cin_text = "Please, input the amount of vertices in graph, it should be one positive number. \n"
                         "This number shows the amount of rows in the adjacency list. \n"
                         "After that input in console, line by line, list elements"
                         " separated by spaces. \n"
                         "For example, if vertex v1 is connected with v2, v3 you should "
                         "input only numbers 2 3.";
  adj_list = SwitchStreamsAndGetMatrix(type_of_input, cin_text, type_of_matrix);
  std::vector<std::vector<int>> graph_adjacency_matrix = FromAdjListToAdjMatrix(adj_list);
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

std::vector<std::vector<int>> FromEdjListToAdjMatrix(std::vector<std::vector<int>> &edj_list, int num_of_vertices) {
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));

  for (auto &edj : edj_list) {
    int v1 = edj[0] - 1;
    int v2 = edj[1] - 1;
    graph_adjacency_matrix[v1][v2] = 1;
  }

  return graph_adjacency_matrix;
}

Graph GetByEdgList() {
  int num_of_vertices;
  std::cout << "Please, input number of vertices in graph : ";
  std::cin >> num_of_vertices;
  std::vector<std::vector<int>> edj_list;
  std::string type_of_matrix = "list of edges";
  int type_of_input = GetTypeOfGraphInput(type_of_matrix);
  std::string cin_text = "Please, input the amount of edges in graph, it should be one positive number. \n"
                         "This number shows the amount of rows in the list of edges. \n"
                         "After that input in console, line by line, list elements"
                         " separated by spaces. \n"
                         "For example, if edge number 1 connects vertex 1 and vertex 2 "
                         "input only numbers 1 2.";
  edj_list = SwitchStreamsAndGetMatrix(type_of_input, cin_text, type_of_matrix);
  std::vector<std::vector<int>> graph_adjacency_matrix = FromEdjListToAdjMatrix(edj_list, num_of_vertices);
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

std::vector<int> ReadFOorFI(std::string &&type_of_matrix) {
  std::vector<int> line_of_data;
  int type_of_input = GetTypeOfGraphInput(type_of_matrix);
  std::string cin_text = "Please input " + type_of_matrix + " of matrix";
  line_of_data = (SwitchStreamsAndGetMatrix(type_of_input, cin_text, type_of_matrix, false, 1))[0];
  return line_of_data;
}

Graph GetByFO() {
  auto FO = ReadFOorFI("FO form");
  int num_of_vertices = FO[0];
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  int index = 0;
  for (size_t i = 1; i < FO.size(); ++i) {
    if (FO[i] != 0)
      graph_adjacency_matrix[index][FO[i] - 1] = 1;
    else
      index++;
  }
  std::cout << std::endl;
  std::string type_of_matrix = "FO form";
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

Graph GetByFI() {
  auto FI = ReadFOorFI("FI form");
  int num_of_vertices = FI[0];
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  int index = 0;
  for (size_t i = 1; i < FI.size(); ++i) {
    if (FI[i] != 0)
      graph_adjacency_matrix[FI[i] - 1][index] = 1;
    else
      index++;
  }
  std::string type_of_matrix = "FI form";
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

Graph GetByFOOrFIForms() {
  std::cout << std::endl;
  Graph graph;
  std::cout << "Please, select which type of graph you have and input its number in console" << std::endl;
  std::string types_of_graph = "1. Directed graph. \n"
                               "2. Undirected graph. ";
  std::cout << types_of_graph << std::endl;
  int type;
  std::cout << "Your choice : ";
  std::cin >> type;
  if (type == 2) {
    graph = GetByFO();
  } else if (type == 1) {
    std::cout << "Please, select which form of graph you would use and input its number in console" << std::endl;
    std::string forms = "1. FO form. \n"
                        "2. FI form. ";
    std::cout << forms << std::endl;
    int form;
    std::cout << "Your choice : ";
    std::cin >> form;
    if (form == 1)
      graph = GetByFO();
    else if (form == 2)
      graph = GetByFI();
  }
  return graph;
}

std::pair<int, std::vector<std::vector<int>>> ReadMFOOrMFIOrBMFOForm(std::string &&type_of_matrix) {
  std::cout << "Please, input number of vertices : ";
  int num_of_vertices;
  std::cin >> num_of_vertices;
  std::vector<std::vector<int>> ME_and_MV;
  int type_of_input = GetTypeOfGraphInput(type_of_matrix);
  std::string cin_text = "Please input " + type_of_matrix + " of matrix. \n"
                                                            "Your input should contain 2 lines."
                                                            " First line is ME array, second is MV array.";
  ME_and_MV = SwitchStreamsAndGetMatrix(type_of_input, cin_text, type_of_matrix, false, 2);
  return std::pair{num_of_vertices, ME_and_MV};
}

Graph GetByMFO() {
  auto[num_of_vertices, ME_and_MV] = ReadMFOOrMFIOrBMFOForm("MFO form");
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  int last_index = 0;
  int index_of_row = 0;
  for (auto &ind : ME_and_MV[1]) {
    for (int i = last_index; i < ind; ++i) {
      graph_adjacency_matrix[index_of_row][ME_and_MV[0][i] - 1] = 1;
    }
    last_index = ind;
    index_of_row++;
  }
  std::string type_of_matrix = "MFO form";
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

Graph GetByBMFO() {
  auto[num_of_vertices, ME_and_MV] = ReadMFOOrMFIOrBMFOForm("BMFO form");
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  int last_index = 0;
  int index_of_row = 0;
  for (auto &ind : ME_and_MV[1]) {
    for (int i = last_index; i < ind; ++i) {
      graph_adjacency_matrix[index_of_row][ME_and_MV[0][i] - 1] = 1;
      graph_adjacency_matrix[ME_and_MV[0][i] - 1][index_of_row] = 1;
    }
    last_index = ind;
    index_of_row++;
  }
  std::string type_of_matrix = "BMFO form";
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);
  return graph;
}

Graph GetByMFI() {
  auto[num_of_vertices, ME_and_MV] = ReadMFOOrMFIOrBMFOForm("MFI form");
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  int last_index = 0;
  int index_of_column = 0;
  for (auto &ind : ME_and_MV[1]) {
    for (int i = last_index; i < ind; ++i) {
      graph_adjacency_matrix[ME_and_MV[0][i] - 1][index_of_column] = 1;
    }
    last_index = ind;
    index_of_column++;
  }

  std::string type_of_matrix = "MFI form";
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);

  return graph;
}

Graph GetByMFOOrMFIForms() {
  std::cout << std::endl;
  Graph graph;
  std::cout << "Please, select which type of graph you have and input its number in console" << std::endl;
  std::string types_of_graph = "1. Directed graph. \n"
                               "2. Undirected graph. ";
  std::cout << types_of_graph << std::endl;
  int type;
  std::cout << "Your choice : ";
  std::cin >> type;
  if (type == 1)
    graph = GetByMFI();
  else if (type == 2)
    graph = GetByMFO();

  return graph;
}

Graph GetByBFO() {
  std::cout << std::endl;
  std::string info = "Please, note that for each vertex in graph BFO form should contain "
                     "only greater vertices. \n"
                     "For example, if vertex 3 is connected with vertices 1, 2, 4, 5. \n"
                     "BFO form should contain ... 0 4 5 0 ..., zero as a delimiter.";
  std::cout << info << std::endl;

  auto BFO = ReadFOorFI("BFO form");
  int num_of_vertices = BFO[0];
  std::vector<std::vector<int>> graph_adjacency_matrix(num_of_vertices,
                                                       std::vector<int>(num_of_vertices, 0));
  int index = 0;
  for (size_t i = 1; i < BFO.size(); ++i) {
    if (BFO[i] != 0) {
      graph_adjacency_matrix[index][BFO[i] - 1] = 1;
      graph_adjacency_matrix[BFO[i] - 1][index] = 1;
    } else {
      index++;
    }
  }
  std::string type_of_matrix = "BFO form";
  auto graph = CheckMatrix(graph_adjacency_matrix, type_of_matrix);
  return graph;
}

Graph GetNewGraph() {
  std::cout << "Please, select one option of graph input and input its number in console" << std::endl;
  std::cout << "Note, numbering of vertices from 1." << std::endl;
  std::string types_of_graph_input = "1. Adjacency matrix. \n"
                                     "2. Incidence matrix. \n"
                                     "3. Adjacency list. \n"
                                     "4. List of edges. \n"
                                     "5. FO- and FI- form \n"
                                     "6. MFO- and MFI- form \n"
                                     "7. BFO form \n"
                                     "8. BMFO form";
  std::cout << types_of_graph_input << std::endl;
  int type;
  std::cout << "Your choice : ";
  std::cin >> type;
  std::cout << std::endl;
  Graph graph;
  switch (type) {
    case 1:graph = GetByAdjMatrix();
      break;
    case 2:graph = GetByIncMatrix();
      break;
    case 3:graph = GetByAdjList();
      break;
    case 4:graph = GetByEdgList();
      break;
    case 5:graph = GetByFOOrFIForms();
      break;
    case 6:graph = GetByMFOOrMFIForms();
      break;
    case 7:graph = GetByBFO();
      break;
    case 8:graph = GetByBMFO();
      break;
    default:break;
  }
  return graph;
}

int CountDegreesForUndirectedGraph(const Graph &graph, bool show_result = true) {
  if (show_result)
    std::cout << "Vertex number: \t\t Degree:" << std::endl;
  int sum = 0;
  for (size_t i = 0; i < graph.adjacency_matrix.size(); ++i) {
    int degree = 0;
    for (size_t j = 0; j < graph.adjacency_matrix.size(); ++j) {
      degree += graph.adjacency_matrix[i][j];
    }
    sum += degree;
    if (show_result)
      std::cout << i + 1 << " \t\t\t " << degree << std::endl;
  }
  return sum;
}

int CountDegreesForDirectedGraph(const Graph &graph, bool show_result = true) {
  if (show_result)
    std::cout << "Vertex number: \t\t Outdegree: \t\t Indegree:" << std::endl;
  int sum = 0;
  for (size_t i = 0; i < graph.adjacency_matrix.size(); ++i) {
    int outdegree = 0;
    int indegree = 0;
    for (size_t j = 0; j < graph.adjacency_matrix.size(); ++j) {
      outdegree += graph.adjacency_matrix[i][j];
      indegree += graph.adjacency_matrix[j][i];
    }
    sum += outdegree + indegree;
    if (show_result)
      std::cout << i + 1 << " \t\t\t " << outdegree << " \t\t\t " << indegree << std::endl;
  }
  return sum;
}

int CountDegreesOfVertices(const Graph &graph, bool show_result = true) {
  int sum;
  if (graph.is_symmetrical)
    sum = CountDegreesForUndirectedGraph(graph, show_result);
  else
    sum = CountDegreesForDirectedGraph(graph, show_result);
  return sum;
}

int CountNumberOfEdges(const Graph &graph, bool show_result = true) {
  int sum = CountDegreesOfVertices(graph, false);
  int num_of_edges = sum / 2;
  std::cout << std::endl;
  std::string graph_type = graph.is_symmetrical ? "undirected" : "directed";
  if (show_result)
    std::cout << "Number of edges in " << graph_type << " graph is " << num_of_edges << std::endl;
  return num_of_edges;
}

void SaveMatrix(const std::string &type_of_matrix, const std::vector<std::vector<int>> &matrix,
                bool print_size) {
  std::cout << std::endl;
  std::cout << "Do you want to save " << type_of_matrix << " to .txt file?" << std::endl;
  int to_save_or_not_to_save;
  std::cout << "Please, select an option and input its number in console. \n"
               "1. Save to .txt file. \n"
               "2. Not to save." << std::endl;
  std::cout << "Your choice : ";
  std::cin >> to_save_or_not_to_save;
  if (to_save_or_not_to_save == 1) {
    std::cout << std::endl;
    std::cout << "Please, input the path to the file for saving " << type_of_matrix << ",\n" <<
              "it must be the full path with the filename and extension." << std::endl;

    /// Написать в ReadMe.txt про ../output_matrix.txt
    std::string path;
    std::cout << "Path: ";
    std::cin >> path;
    std::ofstream fout(path);
    size_t n = matrix.size();

    if (print_size)
      fout << matrix.size() << std::endl;
    for (size_t i = 0; i < n; ++i) {
      size_t k = matrix[i].size();
      for (size_t j = 0; j < k; ++j) {
        std::string indent = matrix[i][j] == -1 ? "" : " ";
        fout << indent << matrix[i][j] << " ";
      }
      fout << std::endl;
    }
    fout.close();
  }
}

void OutputIncidenceMatrix(const std::vector<std::vector<int>> &incidence_matrix) {
  size_t n = incidence_matrix.size();
  size_t num_of_edges = incidence_matrix[0].size();

  std::cout << "Incidence Matrix:  " << std::endl;
  /// Написать об этом в ReadMe
  std::cout << "Note that the order of edges (order of columns) could be different." << std::endl;
  std::cout << std::endl;

  std::cout << "   ";
  for (size_t i = 0; i < num_of_edges; ++i) {
    std::cout << "u" << i + 1 << "  ";
  }
  std::cout << std::endl;

  for (size_t i = 0; i < n; ++i) {
    std::cout << "v" << i + 1 << " ";
    for (size_t j = 0; j < num_of_edges; ++j) {
      std::string indent = incidence_matrix[i][j] == -1 ? "" : " ";
      std::cout << indent << incidence_matrix[i][j] << "  ";
    }
    std::cout << std::endl;
  }

  SaveMatrix("incidence matrix", incidence_matrix, true);
}

void MakeIncidenceMatrix(const Graph &graph) {
  if (graph.is_symmetrical)
    MakeIncidenceMatrixForUndirectedGraph(graph);
  else
    MakeIncidenceMatrixForDirectedGraph(graph);
}

void MakeIncidenceMatrixForDirectedGraph(const Graph &graph) {
  size_t n = graph.adjacency_matrix.size();
  int num_of_edges = CountNumberOfEdges(graph, false);
  std::vector<std::vector<int>> incidence_matrix(n, std::vector<int>(num_of_edges, 0));
  int edge = 0;
  for (size_t i = 0; i < n; ++i) {
    for (size_t j = 0; j < n; ++j) {
      if (graph.adjacency_matrix[i][j]) {
        incidence_matrix[i][edge] = 1;
        incidence_matrix[j][edge] = -1;
        ++edge;
      }
    }
  }
  OutputIncidenceMatrix(incidence_matrix);
}

void MakeIncidenceMatrixForUndirectedGraph(const Graph &graph) {
  size_t n = graph.adjacency_matrix.size();
  int num_of_edges = CountNumberOfEdges(graph, false);
  std::vector<std::vector<int>> incidence_matrix(n, std::vector<int>(num_of_edges, 0));
  int edge = 0;
  for (size_t i = 0; i < n; ++i) {
    for (size_t j = i; j < n; ++j) {
      if (graph.adjacency_matrix[i][j]) {
        incidence_matrix[j][edge] = incidence_matrix[i][edge] = 1;
        ++edge;
      }
    }
  }
  OutputIncidenceMatrix(incidence_matrix);
}

std::vector<std::vector<int>> MakeAdjacencyList(const Graph &graph, bool show_result = true) {
  std::vector<std::vector<int>> adj_list;
  size_t n = graph.adjacency_matrix.size();
  for (size_t i = 0; i < n; ++i) {
    std::vector<int> neighbours;
    for (size_t j = 0; j < n; ++j) {
      if (graph.adjacency_matrix[i][j])
        neighbours.push_back(static_cast<int>(j) + 1);
    }
    adj_list.push_back(neighbours);
  }

  if (show_result) {
    for (size_t i = 0; i < adj_list.size(); ++i) {
      std::cout << i + 1 << ":  ";
      for (auto v : adj_list[i])
        std::cout << v << "; ";
      std::cout << std::endl;
    }
    SaveMatrix("adjacency list", adj_list, true);
  }

  return adj_list;
}

void MakeListOfEdges(const Graph &graph) {
  std::vector<std::vector<int>> list_of_edges;
  size_t n = graph.adjacency_matrix.size();
  for (size_t i = 0; i < n; ++i) {
    for (size_t j = 0; j < n; ++j) {
      if (graph.adjacency_matrix[i][j]) {
        std::vector<int> edge;
        edge.push_back(static_cast<int>(i) + 1);
        edge.push_back(static_cast<int>(j) + 1);
        list_of_edges.push_back(edge);
      }
    }
  }

  size_t k = list_of_edges.size();
  std::cout << "    Begin:   End: " << std::endl;
  for (size_t i = 0; i < k; ++i) {
    std::cout << i + 1 << "   " << list_of_edges[i][0] << "\t    " << list_of_edges[i][1] << std::endl;
  }

  SaveMatrix("list of edges", list_of_edges, true);
}

std::vector<std::vector<int>> MakeFOandFIForm(const Graph &graph, bool show_result = true) {
  int p = static_cast<int>(graph.adjacency_matrix.size());
  std::vector<std::vector<int>> FO_FI_forms;
  std::vector<int> FO_form;
  FO_form.push_back(p);
  std::vector<int> FI_form;
  if (!graph.is_symmetrical)
    FI_form.push_back(p);

  for (int i = 0; i < p; ++i) {
    for (int j = 0; j < p; ++j) {
      if (graph.adjacency_matrix[i][j])
        FO_form.push_back(j + 1);

      if (graph.adjacency_matrix[j][i])
        if (!graph.is_symmetrical)
          FI_form.push_back(j + 1);
    }
    FO_form.push_back(0);
    if (!graph.is_symmetrical)
      FI_form.push_back(0);
  }
  FO_FI_forms.push_back(FO_form);
  FO_FI_forms.push_back(FI_form);
  if (show_result) {
    std::cout << "FO: ";
    print(FO_form);
    if (!graph.is_symmetrical) {
      std::cout << std::endl;
      std::cout << "FI: ";
      print(FI_form);
    }
    std::cout << std::endl;
    SaveMatrix("FO-, FI- presentation", FO_FI_forms, false);
  }
  return FO_FI_forms;
}

void MakeMFOorMFIForm(const Graph &graph) {
  std::vector<std::vector<int>> matrix;
  int p = static_cast<int>(graph.adjacency_matrix.size());
  //matrix.push_back(std::vector<int>{p});
  std::vector<int> ME;
  std::vector<int> MV;
  auto FO_FI_forms = MakeFOandFIForm(graph, false);
  std::set<int> vect;
  int index = graph.is_symmetrical ? 0 : 1;
  for (size_t i = 1; i < FO_FI_forms[index].size(); ++i) {
    auto v = FO_FI_forms[index][i];
    if (v != 0) {
      vect.insert(v);
    } else {
      for (auto &s : vect)
        ME.push_back(s);
      MV.push_back(static_cast<int>(ME.size()));
      vect.clear();
    }
  }
  std::cout << "p: ";
  std::cout << p << std::endl;
  std::cout << "ME: ";
  print(ME);
  std::cout << std::endl;
  std::cout << "MV: ";
  print(MV);
  std::cout << std::endl;
  matrix.push_back(ME);
  matrix.push_back(MV);

  std::string type_of_matrix = graph.is_symmetrical ? "MFO matrix" : "MFI matrix";
  SaveMatrix(type_of_matrix, matrix, false);
}

std::vector<int> MakeBFOForm(const Graph &graph, bool show_result = true) {
  int p = static_cast<int>(graph.adjacency_matrix.size());
  std::vector<std::vector<int>> matrix;
  std::vector<int> BFO;
  BFO.push_back(p);
  for (int i = 0; i < p; ++i) {
    for (int j = 0; j < p; ++j) {
      if (graph.adjacency_matrix[i][j] && j >= (i + 1))
        BFO.push_back(j + 1);
    }
    BFO.push_back(0);
  }
  if (show_result) {
    std::cout << std::endl;
    std::cout << "BFO: ";
    print(BFO);
    std::cout << std::endl;
    matrix.push_back(BFO);
    SaveMatrix("BFO form", matrix, false);
  }
  return BFO;
}

void MakeBMFOForm(const Graph &graph) {
  std::vector<std::vector<int>> matrix;
  int p = static_cast<int>(graph.adjacency_matrix.size());
  //matrix.push_back(std::vector<int>{p});
  std::vector<int> ME;
  std::vector<int> MV;
  auto BFO = MakeBFOForm(graph, false);
  std::set<int> vect;
  for (size_t i = 1; i < BFO.size(); ++i) {
    if (BFO[i] != 0) {
      ME.push_back(BFO[i]);
    } else {
      int ind = static_cast<int>(ME.size());
      MV.push_back(ind);
    }
  }
  std::cout << std::endl;
  std::cout << "p: " << p << std::endl;
  std::cout << "ME: ";
  print(ME);
  std::cout << std::endl;
  std::cout << "MV: ";
  print(MV);
  std::cout << std::endl;
  matrix.push_back(ME);
  matrix.push_back(MV);

  SaveMatrix("BMFO matrix", matrix, false);
}

void MakeBFOorBMFOForm(const Graph &graph) {
  if (!graph.is_symmetrical) {
    std::cout << "Sorry, but graph you gave is directed. \n"
                 "The forms BFO and BMFO do not exist for this type of graph." << std::endl;
  } else {
    std::cout << "Please, select which form you want to get. \n"
                 "1. BFO form. \n"
                 "2. BMFO form." << std::endl;
    std::cout << "Your choice : ";
    int num_of_option;
    std::cin >> num_of_option;
    if (num_of_option == 1)
      MakeBFOForm(graph);
    else if (num_of_option == 2)
      MakeBMFOForm(graph);
  }
}

void OutputAdjacencyMatrix(const Graph &graph) {
  std::cout << "Adjacency Matrix: " << std::endl;
  for (auto &v : graph.adjacency_matrix) {
    print(v);
    std::cout << std::endl;
  }
  SaveMatrix("Adjacency matrix", graph.adjacency_matrix, true);
}

void OutputInAnotherForm(const Graph &graph) {
  std::string form_types = "Please, select a form and input its number in console. \n"
                           "1. Adjacency matrix \n"
                           "2. Incidence matrix. \n"
                           "3. Adjacency list. \n"
                           "4. List of edges. \n"
                           "5. FO- and FI- form \n"
                           "6. MFO- and MFI- form \n"
                           "7. BFO and BMFO form";
  std::cout << form_types << std::endl;
  int num_of_type;
  std::cout << "Your choice : ";
  std::cin >> num_of_type;
  std::cout << std::endl;
  switch (num_of_type) {
    case 1: OutputAdjacencyMatrix(graph);
      break;
    case 2:MakeIncidenceMatrix(graph);
      break;
    case 3:MakeAdjacencyList(graph);
      break;
    case 4:MakeListOfEdges(graph);
      break;
    case 5:MakeFOandFIForm(graph);
      break;
    case 6: MakeMFOorMFIForm(graph);
      break;
    case 7: MakeBFOorBMFOForm(graph);
      break;
    default:std::cout << "Incorrect number!" << std::endl;
      break;
  }
}

