#include <iostream>
#include "Graph.h"

int main() {
  int command_from_console;
  Graph graph;
  std::string path_to_graph;
  std::string switch_options_str = "1. Change your graph choice. \n"
                                   "2. Vertex Degree. \n"
                                   "3. Number of Edges. \n"
                                   "4. Output in another form. \n"
                                   "5. Breadth First Search \n"
                                   "6. Depth First Search Not Recursively \n"
                                   "7. Depth First Search Recursively \n"
                                   "0. Exit.";
  do {
    std::cout << std::endl;
    std::cout << "Please, select one option and input its number in console" << std::endl;
    std::cout << switch_options_str << std::endl;
    std::cout << "Your choice : ";
    std::cin >> command_from_console;
    std::cout << std::endl;

    switch (command_from_console) {
      case 1: {
        graph = GetNewGraph();
        break;
      }
      case 2: {
        if (!graph.adjacency_matrix.empty())
          CountDegreesOfVertices(graph, true);
        else
          std::cout << "Sorry, no matrix is in run." << std::endl;
        break;
      }
      case 3: {
        if (!graph.adjacency_matrix.empty())
          CountNumberOfEdges(graph, true);
        else
          std::cout << "Sorry, no matrix is in run." << std::endl;
        break;
      }
      case 4: {
        if (!graph.adjacency_matrix.empty())
          OutputInAnotherForm(graph);
        else
          std::cout << "Sorry, no matrix is in run." << std::endl;
        break;
      }
      case 5: {
        if (!graph.adjacency_matrix.empty())
          BreadthFirstSearch(graph);
        else
          std::cout << "Sorry, no matrix is in run." << std::endl;
        break;
      }
      case 6: {
        if (!graph.adjacency_matrix.empty())
          DepthFirstSearchNotRec(graph);
        else
          std::cout << "Sorry, no matrix is in run." << std::endl;
        break;
      }
      case 7: {
        if (!graph.adjacency_matrix.empty())
          DepthFirstSearchRec(graph);
        else
          std::cout << "Sorry, no matrix is in run." << std::endl;
        break;
      }
        /// При выходе, если матрица введена через консоль, дать возможность сохранить матрицу.
      case 0:std::cout << "Good bye!";
        return 0;
      default:std::cout << "Incorrect number." << std::endl;
    }
  } while (true);
}
